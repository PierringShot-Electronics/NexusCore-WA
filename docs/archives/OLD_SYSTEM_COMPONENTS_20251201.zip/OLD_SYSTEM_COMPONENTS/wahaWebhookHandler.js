const fs = require("fs-extra");
const path = require("path");
const mime = require("mime-types");
const { getAIResponse } = require("./ai");
const { saveHistory } = require("./historyManager");
const waha = require("./waha");
const { logWithTimestamp } = require("../utils/logger");
const { getGateStatus } = require("./orchestrator/automationState");

const TMP_DIR = path.join(process.cwd(), "tmp", "waha-webhooks");
fs.ensureDirSync(TMP_DIR);

function resolveChatId(payload = {}) {
  return payload.chatId || payload.from || payload.to || payload.id || null;
}

function describeLocation(location = {}) {
  if (!location || typeof location !== "object") return "";
  const { latitude, longitude, description, name } = location;
  const parts = [];
  if (latitude !== undefined && longitude !== undefined) {
    parts.push(`Lat:${latitude}, Lon:${longitude}`);
  }
  if (name) parts.push(`Ad: ${name}`);
  if (description) parts.push(description);
  return parts.length ? `İstifadəçi məkan göndərdi (${parts.join(" | ")}).` : "";
}

async function downloadMediaAttachment({ session, messageId, payload }) {
  if (!messageId) return null;
  try {
    const result = await waha.downloadMessageMedia({ session, messageId });
    if (!result?.ok || !result.data) {
      logWithTimestamp(
        `⚠️ WAHA media yüklənmədi [${messageId}] status ${result?.status || "?"}`,
      );
      return null;
    }
    const inferredMime =
      payload?.media?.mimetype ||
      (typeof result.headers?.get === "function"
        ? result.headers.get("content-type")
        : null) ||
      "application/octet-stream";
    const extension = mime.extension(inferredMime) || "bin";
    const filePath = path.join(
      TMP_DIR,
      `${messageId.replace(/[^a-zA-Z0-9_-]/g, "") || Date.now()}.${extension}`,
    );
    const buffer = Buffer.isBuffer(result.data)
      ? result.data
      : Buffer.from(result.data);
    await fs.writeFile(filePath, buffer);
    return {
      path: filePath,
      mimeType: inferredMime,
      cleanup: () =>
        fs.remove(filePath).catch((error) =>
          logWithTimestamp(`⚠️ Media faylını silmək olmadı (${filePath})`, error.message),
        ),
    };
  } catch (error) {
    logWithTimestamp("⚠️ WAHA media yükləmə xətası:", error.message);
    return null;
  }
}

async function processMessageEvent(event) {
  const payload = event.payload || {};
  if (payload.fromMe) {
    return;
  }

  const session = event.session || process.env.WAHA_SESSION;
  const chatId = resolveChatId(payload);
  if (!chatId) {
    logWithTimestamp("⚠️ WAHA mesajında chatId tapılmadı.");
    return;
  }

  const messageId = payload.id || `${chatId}-${Date.now()}`;
  const textSegments = [];
  if (payload.body) {
    textSegments.push(payload.body);
  }
  if (payload.type === "location" && payload.location) {
    const desc = describeLocation(payload.location);
    if (desc) textSegments.push(desc);
  }

  const userMedia = [];
  const cleanupTasks = [];

  const gateStatus = getGateStatus();
  if (gateStatus.blocked) {
    logWithTimestamp(
      `ℹ️ Orchestrator avtomat cavabları blokladı (${gateStatus.source}: ${gateStatus.message}). ChatID=${chatId}`,
    );
    await saveHistory(
      chatId,
      {
        type: "system",
        content: `[AUTOMATION BLOKLANDI] ${gateStatus.message}`,
        sender: "system",
      },
      `system-${Date.now()}`,
    );

    const fallbackReply =
      process.env.AUTOMATION_PAUSED_REPLY && process.env.AUTOMATION_PAUSED_REPLY.trim();
    if (fallbackReply) {
      try {
        await waha.sendText({
          session,
          chatId,
          message: fallbackReply,
          quotedMsgId: payload.id,
        });
        await saveHistory(
          chatId,
          {
            type: "text",
            content: fallbackReply,
            sender: "assistant",
            quotedMsgId: payload.id,
          },
          `assistant-${Date.now()}`,
        );
      } catch (error) {
        logWithTimestamp(
          "⚠️ Pausə edilmiş rejimdə avtomatik xəbərdarlıq göndərmək mümkün olmadı:",
          error.message,
        );
      }
    }
    return;
  }

  if (payload.hasMedia) {
    const download = await downloadMediaAttachment({ session, messageId, payload });
    if (download) {
      userMedia.push({ path: download.path, mimeType: download.mimeType });
      cleanupTasks.push(download.cleanup);
      if (!payload.body) {
        textSegments.push(`İstifadəçi ${payload.type || "media"} faylı göndərdi.`);
      }
    }
  }

  const userText = textSegments.join("\n").trim() || "[Media mesajı]";

  await saveHistory(
    chatId,
    {
      type: payload.type || "text",
      content: userText,
      sender: "user",
      mediaMeta: payload.media ? { mimetype: payload.media.mimetype, filename: payload.media.filename } : undefined,
    },
    messageId,
  );

  try {
    const aiResponse = await getAIResponse(chatId, { text: userText, media: userMedia });
    if (aiResponse && aiResponse.trim()) {
      await waha.sendText({
        session,
        chatId,
        message: aiResponse,
        quotedMsgId: payload.id,
      });
      await saveHistory(
        chatId,
        {
          type: "text",
          content: aiResponse,
          sender: "assistant",
          quotedMsgId: payload.id,
        },
        `assistant-${Date.now()}`,
      );
    }
  } catch (error) {
    logWithTimestamp(`❌ WAHA webhook AI cavabı uğursuz oldu [${chatId}]:`, error.message);
  } finally {
    await Promise.all(
      cleanupTasks.map((fn) =>
        Promise.resolve()
          .then(() => fn())
          .catch(() => {}),
      ),
    );
  }
}

async function processEvent(event) {
  if (!event || typeof event !== "object") return;
  switch (event.event) {
    case "message":
    case "message.any":
      await processMessageEvent(event);
      break;
    case "session.status":
      logWithTimestamp(
        `ℹ️ WAHA sessiya statusu dəyişdi: ${event.payload?.status || "bilinmir"}`,
      );
      break;
    default:
      logWithTimestamp(`ℹ️ WAHA webhook hadisəsi qəbul edildi: ${event.event}`);
  }
}

async function processBatch(events = []) {
  for (const event of events) {
    try {
      await processEvent(event);
    } catch (error) {
      logWithTimestamp("❌ WAHA webhook hadisəsi xətası:", error.message);
    }
  }
}

function dispatchEvents(events = []) {
  const batch = Array.isArray(events) ? events : [events];
  setImmediate(() => {
    processBatch(batch).catch((error) =>
      logWithTimestamp("❌ WAHA webhook batch xətası:", error.message),
    );
  });
}

module.exports = {
  dispatchEvents,
};
