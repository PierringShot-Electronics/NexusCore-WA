const { getGroqProvider } = require("../models/groqProvider");
const { summarizeTools } = require("./toolRegistry");
const { logWithTimestamp } = require("../../utils/logger");

const MAX_TOOL_CALLS = Number(process.env.ANALYSIS_MAX_TOOL_CALLS || 4);

function buildPromptPayload({
  userText,
  intent,
  catalogSummary,
  requiresWebSearch,
  memorySummary,
  contactProfile,
  historyPreview,
}) {
  return [
    `ISTIFADEÇI MESAJI: ${userText || "(boş)"}`,
    `AKTIV INTENT: ${intent}`,
    catalogSummary ? `KATALOQ XÜLASƏSİ: ${catalogSummary}` : null,
    memorySummary ? `SOHBƏT XÜLASƏSİ: ${memorySummary}` : null,
    contactProfile
      ? `KONTAKT MƏLUMATI: ${JSON.stringify(contactProfile)}`
      : null,
    historyPreview ? `SON MESAJLAR: ${historyPreview}` : null,
    `WEB AXTARIŞI TÖVSİYƏSİ: ${requiresWebSearch ? "bəli" : "xeyr"}`,
  ]
    .filter(Boolean)
    .join("\n\n");
}

function cleanJson(raw) {
  return raw
    .replace(/```json/gi, "")
    .replace(/```/g, "")
    .replace(/\u0000/g, "")
    .trim();
}

function defaultAnalysis() {
  return {
    toolCalls: [],
    clarifications: [],
    knowledge: {
      useCatalog: true,
      refreshProducts: false,
      refreshServices: false,
      requestWebSearch: false,
      webQueries: [],
    },
    allowDestructive: false,
    notes: [],
  };
}

async function runAnalysisExpert(context) {
  const provider = getGroqProvider();
  const toolDigest = summarizeTools(5);
  const payloadText = buildPromptPayload(context);
  const model =
    process.env.GROQ_ANALYSIS_MODEL ||
    "llama-3.1-8b-instant";

  const systemInstruction = `Sən WhatsCore.AI üçün WAHA tool planlayıcısan. Cavabı yalnız JSON formatında qaytar. Schema: {"toolCalls":Array<{name, reason, args?, body?, query?, allowWrite?}>,"clarifications":Array<string>,"knowledge":{useCatalog:boolean, refreshProducts:boolean, refreshServices:boolean, requestWebSearch:boolean, webQueries:Array<string>},"allowDestructive":boolean,"notes":Array<string>}. Qaydalar: (1) Maksimum ${MAX_TOOL_CALLS} toolCalls. (2) Yalnız mövcud WAHA alətlərinin adlarından istifadə et (summarized list aşağıdadır). (3) allowWrite yalnız yazma metodlarına icazə ver. (4) Destruktiv əmrlər üçün allowDestructive true olmalıdır və səbəbi notes daxil et. (5) JSON-dan kənar heç nə göndərmə.`;

  const messages = [
    {
      role: "system",
      content: systemInstruction,
    },
    {
      role: "system",
      content: `WAHA TOOL KATALOQU (qısa):\n${toolDigest}`,
    },
    {
      role: "user",
      content: payloadText,
    },
  ];

  try {
    const response = await provider.chatCompletion({
      model,
      messages,
      max_tokens: Number(process.env.ANALYSIS_MAX_TOKENS || 480),
      temperature: Number(process.env.ANALYSIS_TEMPERATURE || 0.1),
    });

    const raw = response.choices?.[0]?.message?.content;
    if (!raw) {
      logWithTimestamp("⚠️ AnalysisExpert boş cavab qaytardı.");
      return defaultAnalysis();
    }
    const cleaned = cleanJson(raw);
    try {
      const parsed = JSON.parse(cleaned);
      if (!Array.isArray(parsed.toolCalls)) {
        parsed.toolCalls = [];
      }
      parsed.toolCalls = parsed.toolCalls.slice(0, MAX_TOOL_CALLS);
      parsed.clarifications = Array.isArray(parsed.clarifications)
        ? parsed.clarifications
        : [];
      if (!parsed.knowledge) {
        parsed.knowledge = defaultAnalysis().knowledge;
      }
      return {
        ...defaultAnalysis(),
        ...parsed,
        toolCalls: parsed.toolCalls,
      };
    } catch (parseError) {
      logWithTimestamp("⚠️ AnalysisExpert JSON parse xətası:", parseError.message);
      logWithTimestamp("Raw AnalysisExpert cavabı:", cleaned);
      return defaultAnalysis();
    }
  } catch (error) {
    logWithTimestamp("❌ AnalysisExpert çağırışı uğursuz oldu:", error.message || error);
    return defaultAnalysis();
  }
}

module.exports = {
  runAnalysisExpert,
};
