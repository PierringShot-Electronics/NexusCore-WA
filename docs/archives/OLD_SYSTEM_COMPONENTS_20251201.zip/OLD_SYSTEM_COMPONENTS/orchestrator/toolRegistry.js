const { logWithTimestamp } = require("../../utils/logger");
const customToolHandlers = require("./customTools");

const rawTools = [
  // Sessions
  { name: "sessions.list", category: "sessions", method: "GET", path: "/api/sessions", summary: "List all sessions", scope: "read" },
  { name: "sessions.create", category: "sessions", method: "POST", path: "/api/sessions", summary: "Create a session", scope: "write" },
  { name: "sessions.get", category: "sessions", method: "GET", path: "/api/sessions/{session}", summary: "Get session information", scope: "read", pathParams: ["session"] },
  { name: "sessions.update", category: "sessions", method: "PUT", path: "/api/sessions/{session}", summary: "Update a session", scope: "write", pathParams: ["session"] },
  { name: "sessions.delete", category: "sessions", method: "DELETE", path: "/api/sessions/{session}", summary: "Delete a session", scope: "write", pathParams: ["session"], destructive: true },
  { name: "sessions.me", category: "sessions", method: "GET", path: "/api/sessions/{session}/me", summary: "Get info about authenticated account", scope: "read", pathParams: ["session"] },
  { name: "sessions.start", category: "sessions", method: "POST", path: "/api/sessions/{session}/start", summary: "Start the session", scope: "write", pathParams: ["session"] },
  { name: "sessions.stop", category: "sessions", method: "POST", path: "/api/sessions/{session}/stop", summary: "Stop the session", scope: "write", pathParams: ["session"] },
  { name: "sessions.logout", category: "sessions", method: "POST", path: "/api/sessions/{session}/logout", summary: "Logout from the session", scope: "write", pathParams: ["session"] },
  { name: "sessions.restart", category: "sessions", method: "POST", path: "/api/sessions/{session}/restart", summary: "Restart the session", scope: "write", pathParams: ["session"] },
  { name: "sessions.upsertStart", category: "sessions", method: "POST", path: "/api/sessions/start", summary: "Upsert and start session", scope: "write" },
  { name: "sessions.stopGlobal", category: "sessions", method: "POST", path: "/api/sessions/stop", summary: "Stop and optionally logout session", scope: "write" },
  { name: "sessions.logoutGlobal", category: "sessions", method: "POST", path: "/api/sessions/logout", summary: "Logout and delete session", scope: "write", destructive: true },

  // Apps
  { name: "apps.list", category: "apps", method: "GET", path: "/api/apps", summary: "List apps", scope: "read" },
  { name: "apps.create", category: "apps", method: "POST", path: "/api/apps", summary: "Create app", scope: "write" },
  { name: "apps.get", category: "apps", method: "GET", path: "/api/apps/{id}", summary: "Get app by id", scope: "read", pathParams: ["id"] },
  { name: "apps.update", category: "apps", method: "PUT", path: "/api/apps/{id}", summary: "Update app", scope: "write", pathParams: ["id"] },
  { name: "apps.delete", category: "apps", method: "DELETE", path: "/api/apps/{id}", summary: "Delete app", scope: "write", pathParams: ["id"], destructive: true },
  { name: "apps.chatwootLocales", category: "apps", method: "GET", path: "/api/apps/chatwoot/locales", summary: "List Chatwoot locales", scope: "read" },

  // Auth
  { name: "auth.qr", category: "auth", method: "GET", path: "/api/{session}/auth/qr", summary: "Get QR for pairing", scope: "read", pathParams: ["session"] },
  { name: "auth.requestCode", category: "auth", method: "POST", path: "/api/{session}/auth/request-code", summary: "Request authentication code", scope: "write", pathParams: ["session"] },

  // Profile
  { name: "profile.get", category: "profile", method: "GET", path: "/api/{session}/profile", summary: "Get session profile", scope: "read", pathParams: ["session"] },
  { name: "profile.setName", category: "profile", method: "PUT", path: "/api/{session}/profile/name", summary: "Set profile name", scope: "write", pathParams: ["session"] },
  { name: "profile.setStatus", category: "profile", method: "PUT", path: "/api/{session}/profile/status", summary: "Set profile status", scope: "write", pathParams: ["session"] },
  { name: "profile.setPicture", category: "profile", method: "PUT", path: "/api/{session}/profile/picture", summary: "Set profile picture", scope: "write", pathParams: ["session"], media: true },
  { name: "profile.deletePicture", category: "profile", method: "DELETE", path: "/api/{session}/profile/picture", summary: "Delete profile picture", scope: "write", pathParams: ["session"], destructive: true },

  // Screenshot
  { name: "screenshot.get", category: "screenshot", method: "GET", path: "/api/screenshot", summary: "Get WhatsApp screenshot / QR", scope: "read" },

  // Chatting
  { name: "chat.sendText", category: "chat", method: "POST", path: "/api/sendText", summary: "Send text message", scope: "write" },
  { name: "chat.sendTextGet", category: "chat", method: "GET", path: "/api/sendText", summary: "Send text via query", scope: "write" },
  { name: "chat.sendImage", category: "chat", method: "POST", path: "/api/sendImage", summary: "Send image", scope: "write", media: true },
  { name: "chat.sendFile", category: "chat", method: "POST", path: "/api/sendFile", summary: "Send file", scope: "write", media: true },
  { name: "chat.sendVoice", category: "chat", method: "POST", path: "/api/sendVoice", summary: "Send voice message", scope: "write", media: true },
  { name: "chat.sendVideo", category: "chat", method: "POST", path: "/api/sendVideo", summary: "Send video", scope: "write", media: true },
  { name: "chat.sendLinkCustomPreview", category: "chat", method: "POST", path: "/api/send/link-custom-preview", summary: "Send text with custom link preview", scope: "write" },
  { name: "chat.sendButtons", category: "chat", method: "POST", path: "/api/sendButtons", summary: "Send button message", scope: "write" },
  { name: "chat.sendList", category: "chat", method: "POST", path: "/api/sendList", summary: "Send list message", scope: "write" },
  { name: "chat.forwardMessage", category: "chat", method: "POST", path: "/api/forwardMessage", summary: "Forward message", scope: "write" },
  { name: "chat.sendSeen", category: "chat", method: "POST", path: "/api/sendSeen", summary: "Mark chat as seen", scope: "write" },
  { name: "chat.startTyping", category: "chat", method: "POST", path: "/api/startTyping", summary: "Simulate typing", scope: "write" },
  { name: "chat.stopTyping", category: "chat", method: "POST", path: "/api/stopTyping", summary: "Stop typing", scope: "write" },
  { name: "chat.react", category: "chat", method: "PUT", path: "/api/reaction", summary: "React to message", scope: "write" },
  { name: "chat.star", category: "chat", method: "PUT", path: "/api/star", summary: "Star or unstar message", scope: "write" },
  { name: "chat.sendPoll", category: "chat", method: "POST", path: "/api/sendPoll", summary: "Send poll", scope: "write" },
  { name: "chat.votePoll", category: "chat", method: "POST", path: "/api/sendPollVote", summary: "Vote on poll", scope: "write" },
  { name: "chat.sendLocation", category: "chat", method: "POST", path: "/api/sendLocation", summary: "Send location", scope: "write" },
  { name: "chat.sendContactVcard", category: "chat", method: "POST", path: "/api/sendContactVcard", summary: "Send contact vCard", scope: "write" },
  { name: "chat.replyButtons", category: "chat", method: "POST", path: "/api/send/buttons/reply", summary: "Reply to button message", scope: "write" },
  { name: "chat.replyDeprecated", category: "chat", method: "POST", path: "/api/reply", summary: "Reply (deprecated)", scope: "write" },
  { name: "chat.sendLinkPreview", category: "chat", method: "POST", path: "/api/sendLinkPreview", summary: "Send link preview", scope: "write" },

  // Channels
  { name: "channels.list", category: "channels", method: "GET", path: "/api/{session}/channels", summary: "List channels", scope: "read", pathParams: ["session"] },
  { name: "channels.create", category: "channels", method: "POST", path: "/api/{session}/channels", summary: "Create channel", scope: "write", pathParams: ["session"] },
  { name: "channels.delete", category: "channels", method: "DELETE", path: "/api/{session}/channels/{id}", summary: "Delete channel", scope: "write", pathParams: ["session", "id"], destructive: true },
  { name: "channels.get", category: "channels", method: "GET", path: "/api/{session}/channels/{id}", summary: "Get channel info", scope: "read", pathParams: ["session", "id"] },
  { name: "channels.preview", category: "channels", method: "GET", path: "/api/{session}/channels/{id}/messages/preview", summary: "Preview channel messages", scope: "read", pathParams: ["session", "id"] },
  { name: "channels.follow", category: "channels", method: "POST", path: "/api/{session}/channels/{id}/follow", summary: "Follow channel", scope: "write", pathParams: ["session", "id"] },
  { name: "channels.unfollow", category: "channels", method: "POST", path: "/api/{session}/channels/{id}/unfollow", summary: "Unfollow channel", scope: "write", pathParams: ["session", "id"] },
  { name: "channels.mute", category: "channels", method: "POST", path: "/api/{session}/channels/{id}/mute", summary: "Mute channel", scope: "write", pathParams: ["session", "id"] },
  { name: "channels.unmute", category: "channels", method: "POST", path: "/api/{session}/channels/{id}/unmute", summary: "Unmute channel", scope: "write", pathParams: ["session", "id"] },
  { name: "channels.searchByView", category: "channels", method: "POST", path: "/api/{session}/channels/search/by-view", summary: "Search channels by view", scope: "read", pathParams: ["session"] },
  { name: "channels.searchByText", category: "channels", method: "POST", path: "/api/{session}/channels/search/by-text", summary: "Search channels by text", scope: "read", pathParams: ["session"] },
  { name: "channels.searchViews", category: "channels", method: "GET", path: "/api/{session}/channels/search/views", summary: "List channel views", scope: "read", pathParams: ["session"] },
  { name: "channels.searchCountries", category: "channels", method: "GET", path: "/api/{session}/channels/search/countries", summary: "List channel countries", scope: "read", pathParams: ["session"] },
  { name: "channels.searchCategories", category: "channels", method: "GET", path: "/api/{session}/channels/search/categories", summary: "List channel categories", scope: "read", pathParams: ["session"] },

  // Status
  { name: "status.postText", category: "status", method: "POST", path: "/api/{session}/status/text", summary: "Post text status", scope: "write", pathParams: ["session"] },
  { name: "status.postImage", category: "status", method: "POST", path: "/api/{session}/status/image", summary: "Post image status", scope: "write", pathParams: ["session"], media: true },
  { name: "status.postVoice", category: "status", method: "POST", path: "/api/{session}/status/voice", summary: "Post voice status", scope: "write", pathParams: ["session"], media: true },
  { name: "status.postVideo", category: "status", method: "POST", path: "/api/{session}/status/video", summary: "Post video status", scope: "write", pathParams: ["session"], media: true },
  { name: "status.delete", category: "status", method: "POST", path: "/api/{session}/status/delete", summary: "Delete status", scope: "write", pathParams: ["session"], destructive: true },
  { name: "status.newMessageId", category: "status", method: "GET", path: "/api/{session}/status/new-message-id", summary: "Generate new message id", scope: "read", pathParams: ["session"] },

  // Chats
  { name: "chats.list", category: "chats", method: "GET", path: "/api/{session}/chats", summary: "List chats", scope: "read", pathParams: ["session"] },
  { name: "chats.overview", category: "chats", method: "GET", path: "/api/{session}/chats/overview", summary: "Get chats overview", scope: "read", pathParams: ["session"] },
  { name: "chats.overviewPost", category: "chats", method: "POST", path: "/api/{session}/chats/overview", summary: "Post chats overview with filters", scope: "read", pathParams: ["session"] },
  { name: "chats.delete", category: "chats", method: "DELETE", path: "/api/{session}/chats/{chatId}", summary: "Delete chat", scope: "write", pathParams: ["session", "chatId"], destructive: true },
  { name: "chats.picture", category: "chats", method: "GET", path: "/api/{session}/chats/{chatId}/picture", summary: "Get chat picture", scope: "read", pathParams: ["session", "chatId"] },
  { name: "chats.messages", category: "chats", method: "GET", path: "/api/{session}/chats/{chatId}/messages", summary: "Get chat messages", scope: "read", pathParams: ["session", "chatId"] },
  { name: "chats.clearMessages", category: "chats", method: "DELETE", path: "/api/{session}/chats/{chatId}/messages", summary: "Clear chat messages", scope: "write", pathParams: ["session", "chatId"], destructive: true },
  { name: "chats.markRead", category: "chats", method: "POST", path: "/api/{session}/chats/{chatId}/messages/read", summary: "Mark chat messages as read", scope: "write", pathParams: ["session", "chatId"] },
  { name: "chats.getMessage", category: "chats", method: "GET", path: "/api/{session}/chats/{chatId}/messages/{messageId}", summary: "Get message by id", scope: "read", pathParams: ["session", "chatId", "messageId"] },
  { name: "chats.deleteMessage", category: "chats", method: "DELETE", path: "/api/{session}/chats/{chatId}/messages/{messageId}", summary: "Delete message", scope: "write", pathParams: ["session", "chatId", "messageId"], destructive: true },
  { name: "chats.editMessage", category: "chats", method: "PUT", path: "/api/{session}/chats/{chatId}/messages/{messageId}", summary: "Edit message", scope: "write", pathParams: ["session", "chatId", "messageId"] },
  { name: "chats.pinMessage", category: "chats", method: "POST", path: "/api/{session}/chats/{chatId}/messages/{messageId}/pin", summary: "Pin message", scope: "write", pathParams: ["session", "chatId", "messageId"] },
  { name: "chats.unpinMessage", category: "chats", method: "POST", path: "/api/{session}/chats/{chatId}/messages/{messageId}/unpin", summary: "Unpin message", scope: "write", pathParams: ["session", "chatId", "messageId"] },
  { name: "chats.archive", category: "chats", method: "POST", path: "/api/{session}/chats/{chatId}/archive", summary: "Archive chat", scope: "write", pathParams: ["session", "chatId"] },
  { name: "chats.unarchive", category: "chats", method: "POST", path: "/api/{session}/chats/{chatId}/unarchive", summary: "Unarchive chat", scope: "write", pathParams: ["session", "chatId"] },
  { name: "chats.markUnread", category: "chats", method: "POST", path: "/api/{session}/chats/{chatId}/unread", summary: "Mark chat as unread", scope: "write", pathParams: ["session", "chatId"] },

  // Contacts
  { name: "contacts.listAll", category: "contacts", method: "GET", path: "/api/contacts/all", summary: "Get all contacts", scope: "read" },
  { name: "contacts.get", category: "contacts", method: "GET", path: "/api/contacts", summary: "Get contact info", scope: "read" },
  { name: "contacts.checkExists", category: "contacts", method: "GET", path: "/api/contacts/check-exists", summary: "Check number existence", scope: "read" },
  { name: "contacts.about", category: "contacts", method: "GET", path: "/api/contacts/about", summary: "Get contact about text", scope: "read" },
  { name: "contacts.profilePicture", category: "contacts", method: "GET", path: "/api/contacts/profile-picture", summary: "Get contact profile picture", scope: "read" },
  { name: "contacts.block", category: "contacts", method: "POST", path: "/api/contacts/block", summary: "Block contact", scope: "write" },
  { name: "contacts.unblock", category: "contacts", method: "POST", path: "/api/contacts/unblock", summary: "Unblock contact", scope: "write" },
  { name: "contacts.upsert", category: "contacts", method: "PUT", path: "/api/{session}/contacts/{chatId}", summary: "Create or update contact", scope: "write", pathParams: ["session", "chatId"] },
  { name: "contacts.lidsList", category: "contacts", method: "GET", path: "/api/{session}/lids", summary: "Get lids map", scope: "read", pathParams: ["session"] },
  { name: "contacts.lidsCount", category: "contacts", method: "GET", path: "/api/{session}/lids/count", summary: "Get lids count", scope: "read", pathParams: ["session"] },
  { name: "contacts.getByLid", category: "contacts", method: "GET", path: "/api/{session}/lids/{lid}", summary: "Get phone by lid", scope: "read", pathParams: ["session", "lid"] },
  { name: "contacts.getLidByPhone", category: "contacts", method: "GET", path: "/api/{session}/lids/pn/{phoneNumber}", summary: "Get lid by phone", scope: "read", pathParams: ["session", "phoneNumber"] },

  // Groups
  { name: "groups.create", category: "groups", method: "POST", path: "/api/{session}/groups", summary: "Create group", scope: "write", pathParams: ["session"] },
  { name: "groups.list", category: "groups", method: "GET", path: "/api/{session}/groups", summary: "List groups", scope: "read", pathParams: ["session"] },
  { name: "groups.joinInfo", category: "groups", method: "GET", path: "/api/{session}/groups/join-info", summary: "Get join info", scope: "read", pathParams: ["session"] },
  { name: "groups.join", category: "groups", method: "POST", path: "/api/{session}/groups/join", summary: "Join group via code", scope: "write", pathParams: ["session"] },
  { name: "groups.count", category: "groups", method: "GET", path: "/api/{session}/groups/count", summary: "Count groups", scope: "read", pathParams: ["session"] },
  { name: "groups.refresh", category: "groups", method: "POST", path: "/api/{session}/groups/refresh", summary: "Refresh groups", scope: "write", pathParams: ["session"] },
  { name: "groups.get", category: "groups", method: "GET", path: "/api/{session}/groups/{id}", summary: "Get group", scope: "read", pathParams: ["session", "id"] },
  { name: "groups.delete", category: "groups", method: "DELETE", path: "/api/{session}/groups/{id}", summary: "Delete group", scope: "write", pathParams: ["session", "id"], destructive: true },
  { name: "groups.leave", category: "groups", method: "POST", path: "/api/{session}/groups/{id}/leave", summary: "Leave group", scope: "write", pathParams: ["session", "id"] },
  { name: "groups.picture", category: "groups", method: "GET", path: "/api/{session}/groups/{id}/picture", summary: "Get group picture", scope: "read", pathParams: ["session", "id"] },
  { name: "groups.setPicture", category: "groups", method: "PUT", path: "/api/{session}/groups/{id}/picture", summary: "Set group picture", scope: "write", pathParams: ["session", "id"], media: true },
  { name: "groups.deletePicture", category: "groups", method: "DELETE", path: "/api/{session}/groups/{id}/picture", summary: "Delete group picture", scope: "write", pathParams: ["session", "id"], destructive: true },
  { name: "groups.setDescription", category: "groups", method: "PUT", path: "/api/{session}/groups/{id}/description", summary: "Update group description", scope: "write", pathParams: ["session", "id"] },
  { name: "groups.setSubject", category: "groups", method: "PUT", path: "/api/{session}/groups/{id}/subject", summary: "Update group subject", scope: "write", pathParams: ["session", "id"] },
  { name: "groups.setInfoAdminOnly", category: "groups", method: "PUT", path: "/api/{session}/groups/{id}/settings/security/info-admin-only", summary: "Set info admin-only", scope: "write", pathParams: ["session", "id"] },
  { name: "groups.getInfoAdminOnly", category: "groups", method: "GET", path: "/api/{session}/groups/{id}/settings/security/info-admin-only", summary: "Get info admin-only", scope: "read", pathParams: ["session", "id"] },
  { name: "groups.setMessagesAdminOnly", category: "groups", method: "PUT", path: "/api/{session}/groups/{id}/settings/security/messages-admin-only", summary: "Set messages admin-only", scope: "write", pathParams: ["session", "id"] },
  { name: "groups.getMessagesAdminOnly", category: "groups", method: "GET", path: "/api/{session}/groups/{id}/settings/security/messages-admin-only", summary: "Get messages admin-only", scope: "read", pathParams: ["session", "id"] },
  { name: "groups.inviteCode", category: "groups", method: "GET", path: "/api/{session}/groups/{id}/invite-code", summary: "Get group invite code", scope: "read", pathParams: ["session", "id"] },
  { name: "groups.revokeInviteCode", category: "groups", method: "POST", path: "/api/{session}/groups/{id}/invite-code/revoke", summary: "Revoke invite code", scope: "write", pathParams: ["session", "id"], destructive: true },
  { name: "groups.participants", category: "groups", method: "GET", path: "/api/{session}/groups/{id}/participants", summary: "Get group participants", scope: "read", pathParams: ["session", "id"] },
  { name: "groups.addParticipants", category: "groups", method: "POST", path: "/api/{session}/groups/{id}/participants/add", summary: "Add participants", scope: "write", pathParams: ["session", "id"] },
  { name: "groups.removeParticipants", category: "groups", method: "POST", path: "/api/{session}/groups/{id}/participants/remove", summary: "Remove participants", scope: "write", pathParams: ["session", "id"], destructive: true },
  { name: "groups.promoteAdmins", category: "groups", method: "POST", path: "/api/{session}/groups/{id}/admin/promote", summary: "Promote participants to admin", scope: "write", pathParams: ["session", "id"] },
  { name: "groups.demoteAdmins", category: "groups", method: "POST", path: "/api/{session}/groups/{id}/admin/demote", summary: "Demote admins", scope: "write", pathParams: ["session", "id"] },

  // Presence
  { name: "presence.set", category: "presence", method: "POST", path: "/api/{session}/presence", summary: "Set session presence", scope: "write", pathParams: ["session"] },
  { name: "presence.getAll", category: "presence", method: "GET", path: "/api/{session}/presence", summary: "Get subscribed presence", scope: "read", pathParams: ["session"] },
  { name: "presence.get", category: "presence", method: "GET", path: "/api/{session}/presence/{chatId}", summary: "Get presence for chat", scope: "read", pathParams: ["session", "chatId"] },
  { name: "presence.subscribe", category: "presence", method: "POST", path: "/api/{session}/presence/{chatId}/subscribe", summary: "Subscribe to presence", scope: "write", pathParams: ["session", "chatId"] },

  // Events
  { name: "events.send", category: "events", method: "POST", path: "/api/{session}/events", summary: "Send event message", scope: "write", pathParams: ["session"] },

  // Labels
  { name: "labels.list", category: "labels", method: "GET", path: "/api/{session}/labels", summary: "List labels", scope: "read", pathParams: ["session"] },
  { name: "labels.create", category: "labels", method: "POST", path: "/api/{session}/labels", summary: "Create label", scope: "write", pathParams: ["session"] },
  { name: "labels.update", category: "labels", method: "PUT", path: "/api/{session}/labels/{labelId}", summary: "Update label", scope: "write", pathParams: ["session", "labelId"] },
  { name: "labels.delete", category: "labels", method: "DELETE", path: "/api/{session}/labels/{labelId}", summary: "Delete label", scope: "write", pathParams: ["session", "labelId"], destructive: true },
  { name: "labels.chatLabels", category: "labels", method: "GET", path: "/api/{session}/labels/chats/{chatId}", summary: "Get labels for chat", scope: "read", pathParams: ["session", "chatId"] },
  { name: "labels.setChatLabels", category: "labels", method: "PUT", path: "/api/{session}/labels/chats/{chatId}", summary: "Set labels for chat", scope: "write", pathParams: ["session", "chatId"] },
  { name: "labels.labelChats", category: "labels", method: "GET", path: "/api/{session}/labels/{labelId}/chats", summary: "Get chats by label", scope: "read", pathParams: ["session", "labelId"] },

  // Media
  { name: "media.convertVoice", category: "media", method: "POST", path: "/api/{session}/media/convert/voice", summary: "Convert voice to WhatsApp format", scope: "write", pathParams: ["session"], media: true },
  { name: "media.convertVideo", category: "media", method: "POST", path: "/api/{session}/media/convert/video", summary: "Convert video to WhatsApp format", scope: "write", pathParams: ["session"], media: true },

  // Observability / Server
  { name: "server.ping", category: "server", method: "GET", path: "/ping", summary: "Ping server", scope: "read" },
  { name: "server.health", category: "server", method: "GET", path: "/health", summary: "Health check", scope: "read" },
  { name: "server.version", category: "server", method: "GET", path: "/api/server/version", summary: "Get server version", scope: "read" },
  { name: "server.environment", category: "server", method: "GET", path: "/api/server/environment", summary: "Get server environment", scope: "read" },
  { name: "server.status", category: "server", method: "GET", path: "/api/server/status", summary: "Get server status", scope: "read" },
  { name: "server.stop", category: "server", method: "POST", path: "/api/server/stop", summary: "Stop (and restart) server", scope: "write", destructive: true },
  { name: "server.heapSnapshot", category: "server", method: "GET", path: "/api/server/debug/heapsnapshot", summary: "Download heap snapshot", scope: "read" },
  { name: "server.browserTrace", category: "server", method: "GET", path: "/api/server/debug/browser/trace/{session}", summary: "Collect Chrome trace", scope: "read", pathParams: ["session"] },
  { name: "server.versionLegacy", category: "server", method: "GET", path: "/api/version", summary: "Get legacy version", scope: "read" },
];

const registry = new Map();

function enhanceBase(tool) {
  const tags = Array.isArray(tool.tags) && tool.tags.length > 0 ? tool.tags : [tool.category || "waha"];
  const costEstimate = tool.costEstimate || (tool.scope === "write" ? "medium" : "low");
  return {
    ...tool,
    tags,
    costEstimate,
  };
}

function registerWahaTool(tool) {
  if (!tool || !tool.name) return;
  const enhanced = enhanceBase({
    ...tool,
    type: "waha",
    allowWrite: tool.allowWrite ?? tool.scope === "write",
  });
  if (registry.has(enhanced.name)) {
    logWithTimestamp(`⚠️ Duplicated tool detected: ${enhanced.name}`);
  }
  registry.set(enhanced.name, Object.freeze(enhanced));
}

function registerCustomTool(tool) {
  if (!tool || !tool.name) {
    throw new Error("Custom tool requires a name");
  }
  if (typeof tool.executor !== "function") {
    throw new Error(`Custom tool ${tool.name} üçün executor funksiyası tələb olunur.`);
  }
  const enhanced = enhanceBase({
    ...tool,
    type: "custom",
    scope: tool.scope || "read",
    allowWrite: tool.allowWrite ?? tool.scope === "write",
  });
  if (registry.has(enhanced.name)) {
    logWithTimestamp(`⚠️ Duplicated tool detected: ${enhanced.name}`);
  }
  registry.set(enhanced.name, Object.freeze(enhanced));
}

for (const tool of rawTools) {
  registerWahaTool(tool);
}

registerCustomTool({
  name: "memory.retrieve",
  category: "memory",
  summary: "Çat yaddaşını, əlaqə və lead məlumatlarını Postgres ledger-dən gətir.",
  executor: customToolHandlers.memoryRetrieve,
  scope: "read",
  tags: ["memory", "context"],
  costEstimate: "low",
});

registerCustomTool({
  name: "memory.store",
  category: "memory",
  summary: "Kontakt/lead məlumatlarını Postgres ledger-ə yaz.",
  executor: customToolHandlers.memoryStore,
  scope: "write",
  allowWrite: false,
  tags: ["memory", "write"],
  costEstimate: "low",
});

registerCustomTool({
  name: "web.search",
  category: "research",
  summary: "Tavily üzərindən veb axtarışı apar və nəticələri qaytar.",
  executor: customToolHandlers.webSearch,
  scope: "read",
  tags: ["web", "search"],
});

registerCustomTool({
  name: "kb.lookup",
  category: "knowledge",
  summary: "Lokal məhsul/xidmət kataloqundan uyğun nəticələri topla.",
  executor: customToolHandlers.kbLookup,
  scope: "read",
  tags: ["knowledge", "catalog"],
});

function listTools() {
  return Array.from(registry.values());
}

function getTool(name) {
  return registry.get(name) || null;
}

function resolvePath(tool, args = {}) {
  if (!tool) return null;
  if (tool.type !== "waha") return null;
  const template = tool.path || "";
  return template.replace(/\{(.*?)\}/g, (match, key) => {
    if (args[key] === undefined || args[key] === null) {
      throw new Error(`Missing path parameter "${key}" for tool ${tool.name}`);
    }
    return encodeURIComponent(String(args[key]));
  });
}

function summarizeTools(maxPerCategory = 6) {
  const grouped = {};
  for (const tool of listTools()) {
    const bucket = grouped[tool.category] || [];
    if (bucket.length < maxPerCategory) {
      bucket.push(`- ${tool.name}: ${tool.summary}`);
    }
    grouped[tool.category] = bucket;
  }
  return Object.entries(grouped)
    .map(([category, lines]) => `## ${category}\n${lines.join("\n")}`)
    .join("\n\n");
}

module.exports = {
  listTools,
  getTool,
  resolvePath,
  summarizeTools,
};
