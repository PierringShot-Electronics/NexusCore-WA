const { getTool, resolvePath } = require("./toolRegistry");
const { sendToolCommand } = require("../toolkit/wahaClient");
const memoryRepository = require("../memory/repository");
const { logWithTimestamp } = require("../../utils/logger");

const DEFAULT_TRACE_LIMIT = Number(process.env.TOOL_TRACE_VALUE_LIMIT || 240);

function stringifySnippet(payload, limit = DEFAULT_TRACE_LIMIT) {
  if (!payload) return "(boş)";
  try {
    const text = typeof payload === "string" ? payload : JSON.stringify(payload);
    if (text.length <= limit) return text;
    return `${text.slice(0, limit)}…`; // ellipsis
  } catch (error) {
    return "(serialize edilmədi)";
  }
}

function formatResult({ call, tool, response, latencyMs }) {
  if (!response) {
    return `❌ ${call.name}: cavab alınmadı.`;
  }
  if (response.ok) {
    const latencyText = latencyMs !== undefined ? `, ${latencyMs}ms` : "";
    const target = tool.type === "custom" ? tool.name : `${tool.method} ${tool.path}`;
    return `✅ ${call.name} (${target}) → status ${response.status}${latencyText}, data: ${stringifySnippet(response.data)}`;
  }
  const reason = response.error || response.reason || "naməlum xəta";
  const target = tool.type === "custom" ? tool.name : `${tool.method} ${tool.path}`;
  const latencyText = latencyMs !== undefined ? `, ${latencyMs}ms` : "";
  return `⚠️ ${call.name} (${target}) → status ${response.status}${latencyText}, error: ${reason}`;
}

async function executeSingle(call, options = {}) {
  const tool = getTool(call.name);
  if (!tool) {
    return {
      call,
      tool: null,
      response: { ok: false, status: 404, error: "Alət tapılmadı." },
      skipped: true,
      skipReason: "Naməlum alət adı",
    };
  }

  if (tool.scope === "write" && !call.allowWrite && !tool.allowWrite) {
    return {
      call,
      tool,
      response: { ok: false, status: 412, error: "allowWrite tələb olunur." },
      skipped: true,
      skipReason: "allowWrite=false",
    };
  }

  if (tool.destructive && !options.allowDestructive) {
    return {
      call,
      tool,
      response: { ok: false, status: 451, error: "Destruktiv əmrlərə icazə verilməyib." },
      skipped: true,
      skipReason: "destructive-blocked",
    };
  }

  const startedAt = Date.now();
  let response;
  let skipped = false;
  let skipReason;

  try {
    if (tool.type === "custom" && typeof tool.executor === "function") {
      response = await tool.executor(call, options);
      if (!response || typeof response !== "object") {
        response = {
          ok: false,
          status: 500,
          error: "Custom tool boş cavab qaytardı.",
        };
      }
    } else {
      let resolvedPath;
      try {
        resolvedPath = resolvePath(tool, call.args || {});
      } catch (error) {
        skipped = true;
        skipReason = "path-resolution";
        response = { ok: false, status: 400, error: error.message };
      }

      if (!skipped) {
        response = await sendToolCommand({
          method: tool.method,
          endpoint: resolvedPath,
          payload: call.body || call.payload || undefined,
          query: call.query,
          headers: call.headers,
        });
      }
    }
  } catch (error) {
    logWithTimestamp(`❌ Tool çağırışı uğursuz oldu (${call.name}):`, error.message);
    response = { ok: false, status: 500, error: error.message };
  }

  const latencyMs = Date.now() - startedAt;

  if (!skipped && memoryRepository.isEnabled()) {
    memoryRepository
      .recordToolAudit({
        callName: call.name,
        payload: {
          args: call.args || null,
          body: call.body || call.payload || null,
          query: call.query || null,
        },
        result: response,
        latencyMs,
        model: options.model || null,
      })
      .catch((error) =>
        logWithTimestamp("⚠️ Tool audit yazıla bilmədi:", error.message),
      );
  }

  return {
    call,
    tool,
    response,
    skipped,
    skipReason,
    latencyMs,
  };
}

async function runToolRunner(toolCalls, options = {}) {
  if (!Array.isArray(toolCalls) || toolCalls.length === 0) {
    return {
      results: [],
      trace: "[TOOL TRACE] Heç bir alət çağırılmadı.",
      insights: [],
    };
  }

  const results = [];
  const traceLines = [];
  for (const call of toolCalls) {
    const result = await executeSingle(call, options);
    results.push(result);
    traceLines.push(formatResult(result));
  }

  return {
    results,
    trace: `
[TOOL TRACE]
${traceLines.join("\n")}`.trim(),
    insights: results
      .filter((item) => item.response?.ok && item.response?.data)
      .map((item) => ({
        name: item.call.name,
        status: item.response.status,
        data: item.response.data,
      })),
  };
}

module.exports = {
  runToolRunner,
};
