const { getGroqProvider } = require("../models/groqProvider");
const { logWithTimestamp } = require("../../utils/logger");

const INTENTS = [
  "customer_support",
  "technical_expert",
  "sales_advisor",
  "appointment_coordinator",
];

function ruleBasedIntent(text) {
  const lowered = (text || "").toLowerCase();
  const contains = (keywords) => keywords.some((word) => lowered.includes(word));

  if (contains(["qiymət", "neçəyə", "sat", "almaq", "stok", "məhsul", "adapter", "ssd", "kampaniya", "satış"])) {
    return "sales_advisor";
  }
  if (contains(["təmir", "qırılıb", "işləmir", "diaqnostika", "servis", "sökülüb", "zəmanət", "ustaya"])) {
    return "technical_expert";
  }
  if (contains(["çatdır", "kuryer", "ünvan", "gətir", "logistika", "təslim", "görüş", "rezerv", "appointment", "slot"])) {
    return "appointment_coordinator";
  }
  if (contains(["salam", "sağ ol", "təşəkkür", "şikayət", "ədavət", "problem", "məlumat", "help", "support"])) {
    return "customer_support";
  }
  return null;
}

async function modelIntent(text, context = "") {
  const provider = getGroqProvider();
  try {
    const response = await provider.chatCompletion({
      model:
        process.env.GROQ_ROUTER_MODEL ||
        "llama-3.3-70b-versatile",
      messages: [
        {
          role: "system",
          content:
            "Sən sorğunu analiz edən niyyət təsnifatçısan. Cavabı JSON formatında qaytar: {\"intent\":one of customer_support, technical_expert, sales_advisor, appointment_coordinator, \"confidence\":0-1}.",
        },
        {
          role: "user",
          content: `Sorğu: ${text}\nKontekst: ${context}`,
        },
      ],
      max_tokens: 120,
      temperature: 0.0,
    });

    const raw = response.choices?.[0]?.message?.content?.trim();
    if (!raw) {
      return null;
    }
    const cleaned = raw
      .replace(/```json/gi, "")
      .replace(/```/g, "")
      .trim();
    const parsed = JSON.parse(cleaned);
    if (INTENTS.includes(parsed.intent)) {
      return parsed;
    }
  } catch (error) {
    logWithTimestamp("⚠️ Model əsaslı niyyət təyini mümkün olmadı:", error.message);
  }
  return null;
}

async function detectIntent({ text, knowledgeSummary, historySummary }) {
  const heuristic = ruleBasedIntent(text || "");
  if (heuristic) {
    return { intent: heuristic, source: "heuristic", confidence: 0.6 };
  }

  const context = [knowledgeSummary, historySummary]
    .filter(Boolean)
    .join("\n\n");
  const predicted = await modelIntent(text || "", context);
  if (predicted && INTENTS.includes(predicted.intent)) {
    return { intent: predicted.intent, source: "model", confidence: predicted.confidence || 0.5 };
  }
  return { intent: "customer_support", source: "fallback", confidence: 0.2 };
}

module.exports = {
  detectIntent,
  INTENTS,
};
