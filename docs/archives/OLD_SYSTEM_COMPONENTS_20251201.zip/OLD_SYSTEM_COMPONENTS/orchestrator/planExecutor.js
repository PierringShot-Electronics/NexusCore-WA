const { ensureConversationSummary } = require("../memory/chatSummary");
const { upsertContact, getContact } = require("../memory/contactMemory");
const { getContactProfile } = require("../toolkit/wahaClient");
const { runSearch, renderSearchBlock } = require("../toolkit/webSearch");
const { runToolRunner } = require("./toolRunner");
const { logWithTimestamp } = require("../../utils/logger");

async function executePlan(plan, { chatId, history, userText }) {
  const outcome = {
    memorySummary: null,
    contactProfile: await getContact(chatId),
    knowledgeBlock: "",
    webBlock: "",
    toolTrace: "",
    leads: [],
    toolInsights: [],
    events: [],
  };
  const knowledgeSegments = [];
  const webSegments = [];
  const toolTraceParts = [];
  const webResults = [];

  for (const step of plan) {
    switch (step.type) {
      case "load_memory": {
        const summaryRecord = await ensureConversationSummary(chatId, history);
        outcome.memorySummary = summaryRecord?.summary || null;
        outcome.events.push({ step: step.type, status: "ok" });
        break;
      }
      case "sync_contact": {
        try {
          const profileResult = await getContactProfile(chatId);
          if (profileResult.ok && profileResult.data) {
            const updated = await upsertContact(chatId, profileResult.data);
            outcome.contactProfile = updated;
            outcome.events.push({ step: step.type, status: "ok" });
          } else {
            outcome.events.push({
              step: step.type,
              status: "skipped",
              reason: profileResult.error || profileResult.status,
            });
          }
        } catch (error) {
          logWithTimestamp("⚠️ Kontakt sinxronlaşdırma alınmadı:", error.message);
          outcome.events.push({ step: step.type, status: "error", reason: error.message });
        }
        break;
      }
      case "tool_batch": {
        const allowWrite = Boolean(step.allowWrite);
        const allowDestructive = Boolean(step.allowDestructive);
        const toolCalls = Array.isArray(step.tools) ? step.tools : [];
        const { results, trace, insights } = await runToolRunner(toolCalls, {
          allowWrite,
          allowDestructive,
          model: step.modelHint,
        });

        if (trace) {
          toolTraceParts.push(trace);
        }

        const successCount = results.filter((item) => item.response?.ok).length;
        const failureCount = results.filter((item) => item.response && !item.response.ok).length;
        outcome.events.push({
          step: step.type,
          status: successCount > 0 ? "ok" : failureCount > 0 ? "error" : "skipped",
          detail: { success: successCount, failure: failureCount },
        });

        for (const insight of insights) {
          outcome.toolInsights.push(insight);
          if (insight.name === "memory.retrieve" && insight.data) {
            if (insight.data.contact) {
              outcome.contactProfile = {
                ...(outcome.contactProfile || {}),
                ...insight.data.contact,
              };
            }
            if (insight.data.memory?.summary) {
              outcome.memorySummary = insight.data.memory.summary;
            }
            if (Array.isArray(insight.data.leads)) {
              outcome.leads = insight.data.leads;
            }
          }
          if (insight.name === "kb.lookup" && insight.data?.summary) {
            knowledgeSegments.push(`[KATALOQ]\n${insight.data.summary}`);
          }
          if (insight.name === "web.search" && insight.data) {
            webResults.push(insight.data);
            webSegments.push(renderSearchBlock(insight.data));
          }
        }
        break;
      }
      case "catalog_context": {
        if (step.payload?.summary) {
          knowledgeSegments.push(`[BİLİK BAZASI NƏTİCƏLƏRİ]\n${step.payload.summary}`);
        }
        outcome.events.push({ step: step.type, status: "ok" });
        break;
      }
      case "web_search": {
        const result = await runSearch(userText);
        webResults.push(result);
        webSegments.push(renderSearchBlock(result));
        outcome.events.push({
          step: step.type,
          status: result.ok ? "ok" : "skipped",
          reason: result.ok ? undefined : result.reason,
        });
        break;
      }
      case "compose_response": {
        outcome.events.push({ step: step.type, status: "pending" });
        break;
      }
      default: {
        outcome.events.push({ step: step.type, status: "unknown" });
        break;
      }
    }
  }

  if (knowledgeSegments.length > 0) {
    outcome.knowledgeBlock = knowledgeSegments.join("\n\n");
  }

  if (webSegments.length > 0) {
    outcome.webBlock = webSegments.join("\n\n");
  }

  if (toolTraceParts.length > 0) {
    outcome.toolTrace = toolTraceParts.join("\n\n");
  }

  outcome.webResults = webResults;

  return outcome;
}

module.exports = { executePlan };
