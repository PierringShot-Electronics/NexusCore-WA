function mergeBlocks(parts) {
  return parts.filter(Boolean).join("\n\n");
}

function buildKnowledgeBlock({ baseBlock, catalogSummary, analysis }) {
  const segments = [];
  if (baseBlock) segments.push(baseBlock.trim());
  if (analysis?.knowledge?.useCatalog && catalogSummary) {
    segments.push(`[BİLİK BAZASI]\n${catalogSummary}`);
  }
  return mergeBlocks(segments);
}

function buildWebBlock({ baseBlock, webResults }) {
  const segments = [];
  if (baseBlock) segments.push(baseBlock.trim());
  if (Array.isArray(webResults) && webResults.length > 0) {
    const lines = webResults
      .map((result, index) => {
        if (!result?.ok) {
          return `#${index + 1} - ⚠️ ${result?.reason || "Web axtarış alınmadı."}`;
        }
        const sources = Array.isArray(result.sources)
          ? result.sources
              .slice(0, 3)
              .map((src, idx) => `${idx + 1}. ${src.title} — ${src.url}`)
              .join("\n")
          : "";
        return `[WEB ${index + 1}] ${result.summary || "Xülasə yoxdur."}${sources ? `\n${sources}` : ""}`;
      })
      .join("\n\n");
    segments.push(lines);
  }
  return mergeBlocks(segments);
}

function assembleContext({
  baseOutcome = {},
  analysis,
  toolTrace,
  catalogMatches,
  extraWebResults,
}) {
  const knowledgeBlock = buildKnowledgeBlock({
    baseBlock: baseOutcome.knowledgeBlock,
    catalogSummary: catalogMatches?.summary,
    analysis,
  });

  const webBlock = buildWebBlock({
    baseBlock: baseOutcome.webBlock,
    webResults: extraWebResults,
  });

  const events = Array.isArray(baseOutcome.events) ? baseOutcome.events : [];

  return {
    memorySummary: baseOutcome.memorySummary || null,
    contactProfile: baseOutcome.contactProfile || null,
    knowledgeBlock: knowledgeBlock || "",
    webBlock: webBlock || "",
    toolTrace: toolTrace || "",
    events,
    clarifications: Array.isArray(analysis?.clarifications)
      ? analysis.clarifications
      : [],
    notes: Array.isArray(analysis?.notes) ? analysis.notes : [],
  };
}

module.exports = {
  assembleContext,
};
