const fs = require("fs-extra");
const path = require("path");

const TRUE_SET = new Set(["1", "true", "yes", "on"]);
const FALSE_SET = new Set(["0", "false", "no", "off"]);

const STATE_FILE =
  process.env.ORCHESTRATOR_STATE_FILE ||
  path.join(process.cwd(), "tmp", "orchestrator-state.json");

const DEFAULT_STATE = {
  paused: false,
  reason: null,
  updatedAt: null,
  updatedBy: null,
};

let state = loadState();

function toBool(value, fallback = false) {
  if (value === undefined || value === null) return fallback;
  const normalized = String(value).trim().toLowerCase();
  if (TRUE_SET.has(normalized)) return true;
  if (FALSE_SET.has(normalized)) return false;
  return fallback;
}

function loadState() {
  try {
    if (!fs.existsSync(STATE_FILE)) {
      return { ...DEFAULT_STATE };
    }
    const payload = fs.readJsonSync(STATE_FILE, { throws: false }) || {};
    return {
      ...DEFAULT_STATE,
      ...payload,
      paused: Boolean(payload.paused),
      updatedAt: payload.updatedAt || null,
      updatedBy: payload.updatedBy || null,
      reason: payload.reason || null,
    };
  } catch (error) {
    return { ...DEFAULT_STATE };
  }
}

function persistState() {
  try {
    fs.ensureDirSync(path.dirname(STATE_FILE));
    fs.writeJsonSync(STATE_FILE, state, { spaces: 2 });
  } catch (error) {
    // eslint-disable-next-line no-console
    console.warn("[orchestrator] Paused state yazıla bilmədi:", error.message);
  }
}

function isSafeModeEnabled() {
  return toBool(process.env.SAFE_MODE, false);
}

function isDevModeEnabled() {
  return toBool(process.env.DEV_MODE, false);
}

function setPaused(paused, { reason, actor } = {}) {
  state = {
    ...state,
    paused: Boolean(paused),
    reason: reason || null,
    updatedAt: new Date().toISOString(),
    updatedBy: actor || null,
  };
  persistState();
  return getState();
}

function getState() {
  return {
    paused: Boolean(state.paused),
    reason: state.reason || null,
    updatedAt: state.updatedAt || null,
    updatedBy: state.updatedBy || null,
    safeMode: isSafeModeEnabled(),
    devMode: isDevModeEnabled(),
    gate: getGateStatus(),
  };
}

function resetStateForTests() {
  state = { ...DEFAULT_STATE };
  persistState();
}

function getGateStatus() {
  if (state.paused) {
    return {
      blocked: true,
      source: "pause",
      message: state.reason || "Automation paused via API.",
    };
  }

  if (isSafeModeEnabled() && !isDevModeEnabled()) {
    return {
      blocked: true,
      source: "safe_mode",
      message: "SAFE_MODE aktivdir; avtomatik cavablar deaktiv edilib.",
    };
  }

  return {
    blocked: false,
    source: "active",
    message: "Automation enabled.",
  };
}

function isAutomationBlocked() {
  return getGateStatus().blocked;
}

module.exports = {
  getState,
  setPaused,
  getGateStatus,
  isAutomationBlocked,
  isSafeModeEnabled,
  isDevModeEnabled,
  resetStateForTests,
};
