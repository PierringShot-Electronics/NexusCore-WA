const { z } = require("zod");
const { logWithTimestamp } = require("../../utils/logger");
const memoryRepository = require("../memory/repository");
const { runSearch } = require("../toolkit/webSearch");
const { gatherCatalogMatches } = require("../toolkit/knowledgeBase");

const memoryRetrieveSchema = z.object({
  contactId: z.string().min(3),
});

const memoryStoreSchema = z
  .object({
    contactId: z.string().min(3),
    contact: z
      .object({
        name: z.string().optional(),
        businessName: z.string().optional(),
        labels: z.array(z.string()).optional(),
        language: z.string().optional(),
        sentimentAvg: z.number().optional(),
        lastSeen: z.string().optional(),
        raw: z.any().optional(),
      })
      .optional(),
    memory: z
      .object({
        summary: z.string().optional(),
        topics: z.array(z.string()).optional(),
        nextSteps: z.string().optional(),
      })
      .optional(),
    lead: z
      .object({
        leadId: z.string().optional(),
        status: z.string().optional(),
        valueEstimate: z.number().optional(),
        source: z.string().optional(),
        notes: z.string().optional(),
      })
      .optional(),
  })
  .refine(
    (value) => Boolean(value.contact || value.memory || value.lead),
    {
      message: "contact, memory və ya lead sahələrindən ən azı biri olmalıdır.",
    },
  );

const webSearchSchema = z.object({ query: z.string().min(3) });

const kbLookupSchema = z.object({ query: z.string().min(2) });

function extractContactId(call) {
  const candidates = [
    call?.contactId,
    call?.chatId,
    call?.args?.contactId,
    call?.args?.chatId,
    call?.payload?.contactId,
    call?.payload?.chatId,
    call?.body?.contactId,
    call?.body?.chatId,
  ];
  return candidates.find((value) => typeof value === "string" && value.trim().length > 0) || null;
}

async function memoryRetrieve(call) {
  if (!memoryRepository.isEnabled()) {
    return {
      ok: false,
      status: 503,
      error: "Memory store aktiv deyil (MEMORY_DATABASE_URL təyin edin).",
    };
  }

  const contactCandidate = extractContactId(call);
  const parsed = memoryRetrieveSchema.safeParse({ contactId: contactCandidate });
  if (!parsed.success) {
    return {
      ok: false,
      status: 400,
      error: parsed.error.issues?.[0]?.message || "contactId tələb olunur.",
    };
  }

  try {
    await memoryRepository.ensureReady();
    const bundle = await memoryRepository.fetchContactBundle(parsed.data.contactId);
    return {
      ok: true,
      status: 200,
      data: bundle,
    };
  } catch (error) {
    logWithTimestamp("❌ memory.retrieve uğursuz oldu:", error.message);
    return { ok: false, status: 500, error: error.message };
  }
}

async function memoryStore(call) {
  if (!memoryRepository.isEnabled()) {
    return {
      ok: false,
      status: 503,
      error: "Memory store aktiv deyil (MEMORY_DATABASE_URL təyin edin).",
    };
  }

  const rawPayload = call?.body || call?.payload || {};
  const contactCandidate = extractContactId(call);
  const parsed = memoryStoreSchema.safeParse({ contactId: contactCandidate, ...rawPayload });
  if (!parsed.success) {
    return {
      ok: false,
      status: 400,
      error: parsed.error.issues?.[0]?.message || "Payload düzgün deyil.",
    };
  }

  const data = parsed.data;

  try {
    await memoryRepository.ensureReady();
    let contactRecord = null;
    let summaryRecord = null;
    let leadRecord = null;

    if (data.contact) {
      contactRecord = await memoryRepository.upsertContact(data.contactId, data.contact);
    }
    if (data.memory) {
      summaryRecord = await memoryRepository.upsertChatSummary(data.contactId, data.memory);
    }
    if (data.lead) {
      leadRecord = await memoryRepository.upsertLead(data.contactId, data.lead);
    }

    return {
      ok: true,
      status: 200,
      data: {
        contact: contactRecord,
        memory: summaryRecord,
        lead: leadRecord,
      },
    };
  } catch (error) {
    logWithTimestamp("❌ memory.store uğursuz oldu:", error.message);
    return { ok: false, status: 500, error: error.message };
  }
}

async function webSearch(call) {
  const payload = call?.body || call?.payload || call?.args || {};
  const parsed = webSearchSchema.safeParse(payload);
  if (!parsed.success) {
    return {
      ok: false,
      status: 400,
      error: parsed.error.issues?.[0]?.message || "query tələb olunur.",
    };
  }

  const result = await runSearch(parsed.data.query);
  if (!result.ok) {
    return { ok: false, status: 502, error: result.reason || "Web search uğursuz oldu." };
  }
  return { ok: true, status: 200, data: result };
}

async function kbLookup(call) {
  const payload = call?.body || call?.payload || call?.args || {};
  const parsed = kbLookupSchema.safeParse(payload);
  if (!parsed.success) {
    return {
      ok: false,
      status: 400,
      error: parsed.error.issues?.[0]?.message || "query tələb olunur.",
    };
  }

  const matches = gatherCatalogMatches(parsed.data.query);
  return {
    ok: Boolean(matches.summary),
    status: matches.summary ? 200 : 204,
    data: matches,
  };
}

module.exports = {
  memoryRetrieve,
  memoryStore,
  webSearch,
  kbLookup,
};
