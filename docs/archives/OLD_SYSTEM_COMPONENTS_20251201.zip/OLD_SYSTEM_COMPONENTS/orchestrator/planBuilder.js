const { getConfig } = require("../toolkit/wahaClient");
const { normalizeChatId } = require("../waha/common");

function resolveDefaultSession() {
  const { session } = getConfig();
  return (
    process.env.WAHA_SESSION ||
    process.env.WAHA_DEFAULT_SESSION ||
    session ||
    null
  );
}

function buildPlan({ intent, catalogMatches, requiresWebSearch, chatId }) {
  const plan = [];

  const session = resolveDefaultSession();
  const normalizedChatId = chatId ? normalizeChatId(chatId) : null;

  plan.push({
    type: "load_memory",
    description: "Hazırkı söhbət üçün mövcud xülasələri və konteksti topla.",
  });

  plan.push({
    type: "sync_contact",
    description: "Kontakt məlumatlarını WAHA API vasitəsilə yoxla və yaddaşda saxla.",
  });

  const contextTools = [];

  if (normalizedChatId) {
    contextTools.push({
      name: "memory.retrieve",
      args: { contactId: normalizedChatId },
      allowWrite: false,
    });
  }

  if (session && normalizedChatId) {
    contextTools.push({
      name: "chats.messages",
      args: { session, chatId: normalizedChatId },
      query: { limit: 15 },
    });
    contextTools.push({
      name: "labels.chatLabels",
      args: { session, chatId: normalizedChatId },
    });
  }

  if (session) {
    contextTools.push({ name: "sessions.get", args: { session } });
  }

  if (contextTools.length > 0) {
    plan.push({
      type: "tool_batch",
      description: "WAHA və yaddaş mənbələrindən kontekst topla.",
      allowWrite: false,
      tools: contextTools,
    });
  }

  if (catalogMatches?.summary) {
    plan.push({
      type: "catalog_context",
      description: "Məhsul və xidmət kataloqundan uyğun nəticələri daxil et.",
      payload: catalogMatches,
    });
  }

  if (requiresWebSearch) {
    plan.push({
      type: "web_search",
      description: "Lokal məlumat tapılmadıqda internetdə dəqiqləşdirici axtarış et.",
    });
  }

  plan.push({
    type: "compose_response",
    description: `Intent: ${intent} üzrə cavabı formalaşdır.`,
  });

  return plan;
}

module.exports = { buildPlan };
