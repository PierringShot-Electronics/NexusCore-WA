const { isWahaConfigured } = require("../services/waha");
const { logWithTimestamp } = require("../utils/logger");

const TRUE_VALUES = new Set(["true", "1", "yes", "y", "on", "force", "retry"]);
const DISABLE_VALUES = new Set([
  "false",
  "0",
  "no",
  "n",
  "off",
  "disabled",
  "disable",
  "never",
]);

function toBoolean(value) {
  if (value === undefined || value === null) return undefined;
  const normalized = String(value).trim().toLowerCase();
  if (TRUE_VALUES.has(normalized)) return true;
  if (DISABLE_VALUES.has(normalized)) return false;
  return undefined;
}

function isQrPrintingDisabled() {
  const flag = process.env.WAHA_PRINT_QR;
  if (flag === undefined || flag === null || flag === "") return false;
  const interpreted = toBoolean(flag);
  if (interpreted === undefined) return false;
  return interpreted === false;
}

function shouldForce(req) {
  const { query = {}, body = {} } = req;
  const candidates = [query.force, query.qr, body.force, body.qr];
  return candidates.some((value) => toBoolean(value) === true);
}

function ensureWaha(res) {
  if (!isWahaConfigured()) {
    res.status(503).json({
      status: "Error",
      message: "WAHA konfiqurasiyası tamamlanmayıb.",
    });
    return false;
  }
  return true;
}

function handleServiceResponse(res, result, successStatus = 200) {
  if (!result) {
    return res.status(500).json({ status: "Error", message: "Naməlum WAHA cavabı." });
  }
  if (result.ok) {
    if (Buffer.isBuffer(result.data)) {
      return res.status(successStatus).send(result.data);
    }
    if (typeof result.data === "string" && result.data.trim() !== "") {
      return res.status(successStatus).send(result.data);
    }
    return res.status(successStatus).json({ status: "OK", data: result.data || null });
  }
  return res
    .status(result.status || 500)
    .json({ status: "Error", message: result.error || "WAHA cavabı uğursuz oldu." });
}

function ensureQrEnabled(req, res) {
  if (shouldForce(req)) {
    return true;
  }
  if (!isQrPrintingDisabled()) {
    return true;
  }

  logWithTimestamp("ℹ️ WAHA QR sorğusu bloklandı (WAHA_PRINT_QR=false).");
  res.status(409).json({
    status: "Error",
    transport: "WAHA",
    message:
      "QR kodunun avtomatik alınması deaktiv edilib. WAHA_PRINT_QR=true təyin edin və ya ?force=true ilə yenidən cəhd edin.",
  });
  return false;
}

module.exports = {
  ensureWaha,
  handleServiceResponse,
  ensureQrEnabled,
};
