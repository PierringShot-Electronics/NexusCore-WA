const { proxyRawRequest } = require("../services/waha");
const { getConfig } = require("../services/toolkit/wahaClient");
const { logWithTimestamp } = require("../utils/logger");

function isWahaConfigured() {
  const { baseUrl } = getConfig();
  return Boolean(baseUrl);
}

function mapPath(pathname = "") {
  if (!pathname.startsWith("/")) {
    pathname = `/${pathname}`;
  }
  if (pathname === "/ping") {
    return "/ping";
  }
  if (!pathname.startsWith("/api")) {
    return `/api${pathname}`;
  }
  return pathname;
}

function extractSession(req) {
  return (
    req.query?.session ||
    req.body?.session ||
    req.headers?.["x-waha-session"] ||
    undefined
  );
}

function writeResponse(res, result) {
  const status = result.status || (result.ok ? 200 : 500);
  const headers = result.headers;
  const contentType =
    typeof headers?.get === "function"
      ? headers.get("content-type") || ""
      : headers?.["content-type"] || "";

  if (contentType) {
    res.set("Content-Type", contentType);
  }

  if (Buffer.isBuffer(result.data)) {
    return res.status(status).send(result.data);
  }

  if (typeof result.data === "string" && !contentType.includes("application/json")) {
    return res.status(status).send(result.data);
  }

  if (result.data !== undefined) {
    return res.status(status).json(result.data);
  }

  if (result.error) {
    return res.status(status).json({ status: "Error", message: result.error });
  }

  return res.status(status).end();
}

async function forward(req, res) {
  if (!isWahaConfigured()) {
    return res.status(503).json({
      status: "Error",
      message: "WAHA konfiqurasiyası tamamlanmayıb.",
    });
  }

  try {
    const targetPath = mapPath(req.path);
    const session = extractSession(req);
    const result = await proxyRawRequest({
      method: req.method,
      path: targetPath,
      query: req.query,
      body: req.body,
      headers: req.headers,
      session,
    });

    return writeResponse(res, result);
  } catch (error) {
    logWithTimestamp("❌ WAHA proxy xətası:", error.message);
    return res.status(500).json({
      status: "Error",
      message: error.message,
    });
  }
}

module.exports = {
  forward,
};
