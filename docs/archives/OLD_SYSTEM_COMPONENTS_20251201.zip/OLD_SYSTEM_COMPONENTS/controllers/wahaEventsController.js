const waha = require("../services/waha");
const { ensureWaha, handleServiceResponse } = require("./wahaUtils");

async function sendEvent(req, res) {
  if (!ensureWaha(res)) return;
  const session = req.params?.session || req.body?.session;
  const event = { ...(req.body || {}) };
  delete event.session;
  const result = await waha.sendEvent({ session, event });
  return handleServiceResponse(res, result, 202);
}

module.exports = {
  sendEvent,
};
