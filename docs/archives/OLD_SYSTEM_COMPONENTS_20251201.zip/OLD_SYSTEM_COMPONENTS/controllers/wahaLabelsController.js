const waha = require("../services/waha");
const { ensureWaha, handleServiceResponse } = require("./wahaUtils");

async function listLabels(req, res) {
  if (!ensureWaha(res)) return;
  const session = req.params?.session || req.query?.session;
  const result = await waha.listLabels({ session });
  return handleServiceResponse(res, result);
}

async function createLabel(req, res) {
  if (!ensureWaha(res)) return;
  const session = req.params?.session || req.body?.session;
  const label = { ...(req.body || {}) };
  delete label.session;
  const result = await waha.createLabel({ session, label });
  return handleServiceResponse(res, result, 201);
}

async function updateLabel(req, res) {
  if (!ensureWaha(res)) return;
  const { labelId } = req.params;
  const session = req.params?.session || req.body?.session;
  const label = { ...(req.body || {}) };
  delete label.session;
  const result = await waha.updateLabel({ session, labelId, label });
  return handleServiceResponse(res, result);
}

async function deleteLabel(req, res) {
  if (!ensureWaha(res)) return;
  const { labelId } = req.params;
  const session = req.params?.session || req.query?.session;
  const result = await waha.deleteLabel({ session, labelId });
  return handleServiceResponse(res, result, 204);
}

async function getChatLabels(req, res) {
  if (!ensureWaha(res)) return;
  const { chatId } = req.params;
  const session = req.params?.session || req.query?.session;
  const result = await waha.getChatLabels({ session, chatId });
  return handleServiceResponse(res, result);
}

async function setChatLabels(req, res) {
  if (!ensureWaha(res)) return;
  const { chatId } = req.params;
  const session = req.params?.session || req.body?.session;
  const { labels } = req.body || {};
  const result = await waha.setChatLabels({ session, chatId, labels });
  return handleServiceResponse(res, result);
}

async function listLabelChats(req, res) {
  if (!ensureWaha(res)) return;
  const { labelId } = req.params;
  const session = req.params?.session || req.query?.session;
  const result = await waha.listLabelChats({ session, labelId });
  return handleServiceResponse(res, result);
}

module.exports = {
  listLabels,
  createLabel,
  updateLabel,
  deleteLabel,
  getChatLabels,
  setChatLabels,
  listLabelChats,
};
