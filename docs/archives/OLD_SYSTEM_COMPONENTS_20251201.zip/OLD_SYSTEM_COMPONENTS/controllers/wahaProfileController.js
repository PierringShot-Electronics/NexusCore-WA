const waha = require("../services/waha");
const { ensureWaha, handleServiceResponse } = require("./wahaUtils");

async function getProfile(req, res) {
  if (!ensureWaha(res)) return;
  const session = req.params?.session || req.query?.session;
  const result = await waha.getProfile({ session });
  return handleServiceResponse(res, result);
}

async function setName(req, res) {
  if (!ensureWaha(res)) return;
  const session = req.params?.session || req.body?.session;
  const { name } = req.body || {};
  const result = await waha.setName({ session, name });
  return handleServiceResponse(res, result);
}

async function setStatus(req, res) {
  if (!ensureWaha(res)) return;
  const session = req.params?.session || req.body?.session;
  const { status } = req.body || {};
  const result = await waha.setStatus({ session, status });
  return handleServiceResponse(res, result);
}

async function setPicture(req, res) {
  if (!ensureWaha(res)) return;
  const session = req.params?.session || req.body?.session;
  const picture = { ...(req.body || {}) };
  delete picture.session;
  const result = await waha.setPicture({ session, picture });
  return handleServiceResponse(res, result);
}

async function deletePicture(req, res) {
  if (!ensureWaha(res)) return;
  const session = req.params?.session || req.query?.session;
  const result = await waha.deletePicture({ session });
  return handleServiceResponse(res, result, 204);
}

module.exports = {
  getProfile,
  setName,
  setStatus,
  setPicture,
  deletePicture,
};
