const waha = require("../services/waha");
const { ensureWaha, handleServiceResponse } = require("./wahaUtils");

async function listChannels(req, res) {
  if (!ensureWaha(res)) return;
  const { limit, cursor } = req.query;
  const result = await waha.listChannels({
    session: req.query.session,
    limit: limit ? Number(limit) : undefined,
    cursor,
  });
  return handleServiceResponse(res, result);
}

async function getChannel(req, res) {
  if (!ensureWaha(res)) return;
  const { channelId } = req.params;
  const result = await waha.getChannel({ session: req.query.session, channelId });
  return handleServiceResponse(res, result);
}

async function followChannel(req, res) {
  if (!ensureWaha(res)) return;
  const { channelId } = req.params;
  const result = await waha.followChannel({ session: req.query.session, channelId });
  return handleServiceResponse(res, result, 201);
}

async function unfollowChannel(req, res) {
  if (!ensureWaha(res)) return;
  const { channelId } = req.params;
  const result = await waha.unfollowChannel({ session: req.query.session, channelId });
  return handleServiceResponse(res, result, 204);
}

async function muteChannel(req, res) {
  if (!ensureWaha(res)) return;
  const { channelId } = req.params;
  const { durationMs } = req.body || {};
  const result = await waha.muteChannel({ session: req.query.session, channelId, durationMs });
  return handleServiceResponse(res, result);
}

async function unmuteChannel(req, res) {
  if (!ensureWaha(res)) return;
  const { channelId } = req.params;
  const result = await waha.unmuteChannel({ session: req.query.session, channelId });
  return handleServiceResponse(res, result);
}

async function getChannelPosts(req, res) {
  if (!ensureWaha(res)) return;
  const { channelId } = req.params;
  const { limit, cursor } = req.query;
  const result = await waha.getChannelPosts({
    session: req.query.session,
    channelId,
    limit: limit ? Number(limit) : undefined,
    cursor,
  });
  return handleServiceResponse(res, result);
}

module.exports = {
  listChannels,
  getChannel,
  followChannel,
  unfollowChannel,
  muteChannel,
  unmuteChannel,
  getChannelPosts,
};
