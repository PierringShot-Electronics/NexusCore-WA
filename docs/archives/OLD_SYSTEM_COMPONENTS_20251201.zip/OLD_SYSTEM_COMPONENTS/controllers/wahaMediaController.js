const waha = require("../services/waha");
const { ensureWaha, handleServiceResponse } = require("./wahaUtils");

async function downloadMessage(req, res) {
  if (!ensureWaha(res)) return;
  const { messageId } = req.params;
  const { format } = req.query;
  const result = await waha.downloadMessageMedia({ session: req.query.session, messageId, format });
  return handleServiceResponse(res, result);
}

async function retryDownload(req, res) {
  if (!ensureWaha(res)) return;
  const { messageId } = req.params;
  const result = await waha.retryMediaDownload({ session: req.query.session, messageId });
  return handleServiceResponse(res, result);
}

module.exports = {
  downloadMessage,
  retryDownload,
};
