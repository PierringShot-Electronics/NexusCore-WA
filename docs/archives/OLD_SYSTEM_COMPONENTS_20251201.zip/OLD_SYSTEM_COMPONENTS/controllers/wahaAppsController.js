const waha = require("../services/waha");
const { ensureWaha, handleServiceResponse } = require("./wahaUtils");

async function listApps(req, res) {
  if (!ensureWaha(res)) return;
  const session = req.query?.session || req.params?.session;
  const result = await waha.listApps({ session });
  return handleServiceResponse(res, result);
}

async function createApp(req, res) {
  if (!ensureWaha(res)) return;
  const session = req.body?.session || req.params?.session;
  const payload = { ...(req.body || {}) };
  delete payload.session;
  const result = await waha.createApp({ session, payload });
  return handleServiceResponse(res, result, 201);
}

async function getApp(req, res) {
  if (!ensureWaha(res)) return;
  const { appId } = req.params;
  const session = req.query?.session || req.params?.session;
  const result = await waha.getApp({ session, id: appId });
  return handleServiceResponse(res, result);
}

async function updateApp(req, res) {
  if (!ensureWaha(res)) return;
  const { appId } = req.params;
  const session = req.body?.session || req.params?.session;
  const payload = { ...(req.body || {}) };
  delete payload.session;
  const result = await waha.updateApp({ session, id: appId, payload });
  return handleServiceResponse(res, result);
}

async function deleteApp(req, res) {
  if (!ensureWaha(res)) return;
  const { appId } = req.params;
  const session = req.query?.session || req.params?.session;
  const result = await waha.deleteApp({ session, id: appId });
  return handleServiceResponse(res, result, 204);
}

async function listChatwootLocales(req, res) {
  if (!ensureWaha(res)) return;
  const session = req.query?.session || req.params?.session;
  const result = await waha.listChatwootLocales({ session });
  return handleServiceResponse(res, result);
}

module.exports = {
  listApps,
  createApp,
  getApp,
  updateApp,
  deleteApp,
  listChatwootLocales,
};
