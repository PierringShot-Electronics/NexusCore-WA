/**
 * WhatsCore.AI - Maverick Edition
 *
 * Hybrid WAHA + whatsapp-web.js controller layer.
 * WAHA (HTTP) is preferred when configured; whatsapp-web.js remains as fallback.
 */
const { MessageMedia, Location } = require("whatsapp-web.js");
const { logWithTimestamp } = require("../utils/logger");
const productManager = require("../services/productManager");
const serviceManager = require("../services/serviceManager");
const orderManager = require("../services/orderManager");
const wahaActions = require("../services/waha");
const {
  getConfig: getWahaConfig,
  request: wahaRequest,
} = require("../services/toolkit/wahaClient");
const legacyMessenger = require("../services/legacyMessenger");
const { ensureQrEnabled } = require("./wahaUtils");

let whatsappClient;

const DISABLE_VALUES = new Set(["false", "0", "no", "off", "disabled"]);

function isFallbackEnabled() {
  const flag = process.env.ENABLE_WEBJS_FALLBACK;
  if (!flag) return false;
  const normalized = flag.trim().toLowerCase();
  return !DISABLE_VALUES.has(normalized);
}

function setWhatsAppClient(client) {
  whatsappClient = client;
  logWithTimestamp(
    "✅ WhatsApp Klient instansiyası API kontrollerinə ötürüldü.",
  );
  legacyMessenger.setClient(client);
}

function isWahaEnabled() {
  const { baseUrl, session } = getWahaConfig();
  return Boolean(baseUrl && session);
}

function requireLegacyClient(res) {
  if (!whatsappClient) {
    res
      .status(503)
      .json({
        status: "Error",
        message: "WhatsApp Klienti hazır deyil və WAHA istifadə oluna bilmir.",
      });
    return false;
  }
  return true;
}

// --- Status və Sessiya ---
async function getClientStatus(req, res) {
  let wahaResult = null;
  if (isWahaEnabled()) {
    try {
      const { session } = getWahaConfig();
      const profile = await wahaRequest({
        method: "GET",
        path: `/api/${session}/profile`,
      });
      if (profile.ok) {
        return res
          .status(200)
          .json({ status: "OK", transport: "WAHA", clientState: profile.data });
      }
      wahaResult = profile;
      logWithTimestamp(
        `⚠️ WAHA status sorğusu uğursuz oldu: ${profile.status} ${profile.error || ""}`,
      );
    } catch (error) {
      wahaResult = { ok: false, status: 500, error: error.message };
      logWithTimestamp("⚠️ WAHA status xətası:", error.message);
    }
  }

  if (!isFallbackEnabled()) {
    const statusCode = wahaResult?.status || 503;
    const message =
      wahaResult?.error ||
      "WAHA statusu alınmadı və whatsapp-web.js fallback deaktivdir.";
    return res.status(statusCode).json({
      status: "Error",
      transport: "WAHA",
      message,
      data: wahaResult?.data || null,
    });
  }

  if (!requireLegacyClient(res)) return;

  try {
    const state = await whatsappClient.getState();
    res
      .status(200)
      .json({ status: "OK", transport: "webjs", clientState: state });
  } catch (error) {
    res
      .status(500)
      .json({
        status: "Error",
        message: "Klient statusunu almaq mümkün olmadı.",
        error: error.message,
      });
  }
}

async function logoutClient(req, res) {
  if (!requireLegacyClient(res)) return;
  try {
    await whatsappClient.logout();
    logWithTimestamp("🚪 WhatsApp Klientindən uğurla çıxış edildi.");
    res
      .status(200)
      .json({
        status: "OK",
        message: "WhatsApp Klientindən uğurla çıxış edildi.",
      });
  } catch (error) {
    res
      .status(500)
      .json({
        status: "Error",
        message: "Çıxış etmək mümkün olmadı.",
        error: error.message,
      });
  }
}

async function resetClientSession(req, res) {
  if (!requireLegacyClient(res)) return;
  try {
    await whatsappClient.destroy();
    logWithTimestamp(
      "🔄 WhatsApp Klient sessiyası sıfırlandı. Tətbiqi yenidən başladın.",
    );
    res
      .status(200)
      .json({
        status: "OK",
        message: "Sessiya sıfırlandı. Tətbiqi yenidən başladın.",
      });
  } catch (error) {
    res
      .status(500)
      .json({
        status: "Error",
        message: "Sessiyanı sıfırlamaq mümkün olmadı.",
        error: error.message,
      });
  }
}

async function getWahaSessionStatus(req, res) {
  if (!isWahaEnabled()) {
    return res
      .status(503)
      .json({
        status: "Error",
        message: "WAHA konfiqurasiyası tamamlanmayıb.",
      });
  }
  try {
    const result = await wahaActions.getSessionStatus({
      session: req.query.session,
      verbose: req.query.verbose === "true",
    });
    if (result.ok) {
      return res.status(200).json({
        status: "OK",
        transport: "WAHA",
        data: result.data,
      });
    }
    return res.status(result.status || 500).json({
      status: "Error",
      transport: "WAHA",
      message: result.error || "Sessiya statusunu almaq mümkün olmadı.",
    });
  } catch (error) {
    logWithTimestamp("⚠️ WAHA session status xətası:", error.message);
    return res.status(500).json({ status: "Error", message: error.message });
  }
}

async function startWahaSession(req, res) {
  if (!isWahaEnabled()) {
    return res
      .status(503)
      .json({
        status: "Error",
        message: "WAHA konfiqurasiyası tamamlanmayıb.",
      });
  }

  const restart = Boolean(req.body?.restart);
  const sessionName = req.body?.session;
  const webhookUrl =
    req.body?.webhookUrl ||
    process.env.WAHA_WEBHOOK_URL ||
    `http://host.docker.internal:${process.env.PORT || 9876}/api/webhooks/waha`;
  let config = req.body?.config;

  if (!restart && !config && webhookUrl) {
    config = {
      webhooks: [
        {
          url: webhookUrl,
          events: ["message", "session.status"],
        },
      ],
    };
  }

  try {
    const result = await wahaActions.startSession({
      session: sessionName,
      config,
      restart,
    });

    if (result.ok) {
      return res.status(restart ? 202 : 201).json({
        status: "OK",
        transport: "WAHA",
        message: restart
          ? "Sessiya yenidən başladılır."
          : "Sessiya yaradıldı və işə salındı.",
        data: result.data || null,
      });
    }

    return res.status(result.status || 500).json({
      status: "Error",
      transport: "WAHA",
      message:
        result.error ||
        (restart
          ? "Sessiyanı yenidən başlatmaq olmadı."
          : "Sessiya yaratmaq olmadı."),
    });
  } catch (error) {
    logWithTimestamp("⚠️ WAHA session start xətası:", error.message);
    return res.status(500).json({ status: "Error", message: error.message });
  }
}

async function getWahaSessionQr(req, res) {
  if (!isWahaEnabled()) {
    return res
      .status(503)
      .json({
        status: "Error",
        message: "WAHA konfiqurasiyası tamamlanmayıb.",
      });
  }

  const format = (req.query.format || "base64").toLowerCase();
  if (!ensureQrEnabled(req, res)) return;

  try {
    const result = await wahaActions.getSessionQRCode({
      session: req.query.session,
      format,
    });

    if (!result.ok) {
      return res.status(result.status || 500).json({
        status: "Error",
        transport: "WAHA",
        message: result.error || "QR kodu almaq mümkün olmadı.",
      });
    }

    if (format === "image" || format === "png") {
      res.setHeader("Content-Type", "image/png");
      return res.status(200).send(result.data);
    }

    return res.status(200).json({
      status: "OK",
      transport: "WAHA",
      data: {
        format,
        qr: result.data,
      },
    });
  } catch (error) {
    logWithTimestamp("⚠️ WAHA session QR xətası:", error.message);
    return res.status(500).json({ status: "Error", message: error.message });
  }
}

// --- Mesaj Göndərmə ---
async function sendText(req, res) {
  const { number, message, quotedMsgId } = req.body;
  if (!number || !message)
    return res
      .status(400)
      .json({ status: "Error", message: "Nömrə və mesaj boş ola bilməz." });

  if (isWahaEnabled()) {
    try {
      const result = await wahaActions.sendText({
        number,
        message,
        quotedMsgId,
      });
      if (result.ok) {
        return res
          .status(200)
          .json({ status: "OK", transport: "WAHA", data: result.data || null });
      }
      logWithTimestamp(
        `⚠️ WAHA mətn göndərmə xətası: ${result.status} ${result.error || ""}`,
      );
    } catch (error) {
      logWithTimestamp("⚠️ WAHA sendText istisnası:", error.message);
    }
  }

  if (!requireLegacyClient(res)) return;

  try {
    const chatId = `${number}@c.us`;
    await whatsappClient.sendMessage(chatId, message);
    res
      .status(200)
      .json({
        status: "OK",
        transport: "webjs",
        message: "Mətn mesajı uğurla göndərildi.",
      });
  } catch (error) {
    res
      .status(500)
      .json({
        status: "Error",
        message: "Mesaj göndərmək mümkün olmadı.",
        error: error.message,
      });
  }
}

async function sendMedia(req, res) {
  const { number, fileUrl, caption } = req.body;
  if (!number || !fileUrl)
    return res
      .status(400)
      .json({
        status: "Error",
        message: "Nömrə və fayl URL-i boş ola bilməz.",
      });

  if (isWahaEnabled()) {
    try {
      const result = await wahaActions.sendMedia({
        number,
        mediaUrl: fileUrl,
        caption,
      });
      if (result.ok) {
        return res
          .status(200)
          .json({ status: "OK", transport: "WAHA", data: result.data || null });
      }
      logWithTimestamp(
        `⚠️ WAHA media göndərmə xətası: ${result.status} ${result.error || ""}`,
      );
    } catch (error) {
      logWithTimestamp("⚠️ WAHA sendMedia istisnası:", error.message);
    }
  }

  if (!requireLegacyClient(res)) return;

  try {
    const media = await MessageMedia.fromUrl(fileUrl, { unsafeMime: true });
    await whatsappClient.sendMessage(`${number}@c.us`, media, { caption });
    res
      .status(200)
      .json({
        status: "OK",
        transport: "webjs",
        message: "Media mesajı uğurla göndərildi.",
      });
  } catch (error) {
    res
      .status(500)
      .json({
        status: "Error",
        message: "Media mesajı göndərmək mümkün olmadı.",
        error: error.message,
      });
  }
}

async function sendLocation(req, res) {
  const { number, latitude, longitude, description } = req.body;
  if (
    !number ||
    typeof latitude === "undefined" ||
    typeof longitude === "undefined"
  ) {
    return res
      .status(400)
      .json({
        status: "Error",
        message: "Nömrə, enlik və uzunluq boş ola bilməz.",
      });
  }

  if (isWahaEnabled()) {
    try {
      const result = await wahaActions.sendLocation({
        number,
        latitude,
        longitude,
        description,
      });
      if (result.ok) {
        return res
          .status(200)
          .json({ status: "OK", transport: "WAHA", data: result.data || null });
      }
      logWithTimestamp(
        `⚠️ WAHA məkan göndərmə xətası: ${result.status} ${result.error || ""}`,
      );
    } catch (error) {
      logWithTimestamp("⚠️ WAHA sendLocation istisnası:", error.message);
    }
  }

  if (!requireLegacyClient(res)) return;

  try {
    const location = new Location(latitude, longitude, description);
    await whatsappClient.sendMessage(`${number}@c.us`, location);
    res
      .status(200)
      .json({
        status: "OK",
        transport: "webjs",
        message: "Məkan uğurla göndərildi.",
      });
  } catch (error) {
    res
      .status(500)
      .json({
        status: "Error",
        message: "Məkan göndərmək mümkün olmadı.",
        error: error.message,
      });
  }
}

async function sendContact(req, res) {
  const { number, contactId, contacts: rawContacts, session } = req.body;
  const contactsPayload = Array.isArray(rawContacts)
    ? rawContacts.filter(Boolean)
    : contactId
      ? [{ contactId }]
      : [];

  if (!number || contactsPayload.length === 0)
    return res
      .status(400)
      .json({
        status: "Error",
        message: "Nömrə və ən azı bir kontakt məlumatı tələb olunur.",
      });

  if (isWahaEnabled()) {
    try {
      const result = await wahaActions.sendContact({
        number,
        contacts: contactsPayload,
        session,
      });
      if (result.ok) {
        return res
          .status(200)
          .json({ status: "OK", transport: "WAHA", data: result.data || null });
      }
      logWithTimestamp(
        `⚠️ WAHA kontakt göndərmə xətası: ${result.status} ${result.error || ""}`,
      );
    } catch (error) {
      logWithTimestamp("⚠️ WAHA sendContact istisnası:", error.message);
    }
  }

  if (!requireLegacyClient(res)) return;

  const legacyContactId = contactId || (contactsPayload[0] && contactsPayload[0].contactId);
  if (!legacyContactId) {
    return res.status(400).json({
      status: "Error",
      message: "Legacy mühitdə kontakt göndərmək üçün contactId tələb olunur.",
    });
  }

  try {
    const contact = await whatsappClient.getContactById(legacyContactId);
    await whatsappClient.sendMessage(`${number}@c.us`, contact);
    res
      .status(200)
      .json({
        status: "OK",
        transport: "webjs",
        message: "Kontakt uğurla göndərildi.",
      });
  } catch (error) {
    res
      .status(500)
      .json({
        status: "Error",
        message: "Kontakt göndərmək mümkün olmadı.",
        error: error.message,
      });
  }
}

// --- Məlumatların İdarəsi (Products, Services, Orders) ---
function getProducts(req, res) {
  res.status(200).json({ status: "OK", data: productManager.getProducts() });
}

function getServices(req, res) {
  res.status(200).json({ status: "OK", data: serviceManager.getServices() });
}

function getAllOrders(req, res) {
  res.status(200).json({ status: "OK", data: orderManager.getAllOrders() });
}

async function createOrder(req, res) {
  try {
    const newOrder = await orderManager.createOrder(req.body);
    if (newOrder.customer_phone) {
      const confirmationMessage = `Hörmətli müştəri, ${newOrder.id} nömrəli sifarişiniz uğurla qeydə alındı. Təşəkkür edirik!`;
      if (isWahaEnabled()) {
        try {
          const result = await wahaActions.sendText({
            number: newOrder.customer_phone,
            message: confirmationMessage,
          });
          wahaActions.logResult("📦 Sifariş təsdiqi WAHA", result);
        } catch (error) {
          logWithTimestamp(
            "⚠️ WAHA sifariş təsdiq mesajı xətası:",
            error.message,
          );
        }
      } else if (whatsappClient) {
        await whatsappClient.sendMessage(
          `${newOrder.customer_phone}@c.us`,
          confirmationMessage,
        );
      }
    }
    res
      .status(201)
      .json({ status: "OK", message: "Sifariş yaradıldı.", data: newOrder });
  } catch (error) {
    res.status(400).json({ status: "Error", message: error.message });
  }
}

// --- Söhbət (Chat) İdarəetməsi ---
async function getChats(req, res) {
  if (isWahaEnabled()) {
    try {
      const result = await wahaActions.listChats({
        limit: Number(req.query.limit) || 50,
      });
      if (result.ok) {
        return res
          .status(200)
          .json({ status: "OK", transport: "WAHA", data: result.data || [] });
      }
      logWithTimestamp(
        `⚠️ WAHA söhbət siyahısı xətası: ${result.status} ${result.error || ""}`,
      );
    } catch (error) {
      logWithTimestamp("⚠️ WAHA getChats istisnası:", error.message);
    }
  }

  if (!requireLegacyClient(res)) return;

  try {
    const chats = await whatsappClient.getChats();
    res.status(200).json({
      status: "OK",
      transport: "webjs",
      data: chats.map((c) => ({
        id: c.id._serialized,
        name: c.name,
        isGroup: c.isGroup,
        unreadCount: c.unreadCount,
      })),
    });
  } catch (error) {
    res
      .status(500)
      .json({
        status: "Error",
        message: "Söhbətləri almaq mümkün olmadı.",
        error: error.message,
      });
  }
}

async function archiveChat(req, res) {
  const { chatId } = req.body;
  if (!chatId)
    return res
      .status(400)
      .json({ status: "Error", message: "Söhbət ID-si boş ola bilməz." });

  if (isWahaEnabled()) {
    try {
      const result = await wahaActions.archiveChat({ chatId });
      if (result.ok) {
        return res
          .status(200)
          .json({
            status: "OK",
            transport: "WAHA",
            message: `Söhbət ${chatId} WAHA ilə arxivləndi.`,
          });
      }
      logWithTimestamp(
        `⚠️ WAHA archiveChat xətası: ${result.status} ${result.error || ""}`,
      );
    } catch (error) {
      logWithTimestamp("⚠️ WAHA archiveChat istisnası:", error.message);
    }
  }

  if (!requireLegacyClient(res)) return;

  try {
    const chat = await whatsappClient.getChatById(chatId);
    await chat.archive();
    res
      .status(200)
      .json({
        status: "OK",
        transport: "webjs",
        message: `Söhbət ${chatId} uğurla arxivləndi.`,
      });
  } catch (error) {
    res
      .status(500)
      .json({
        status: "Error",
        message: "Söhbəti arxivləmək mümkün olmadı.",
        error: error.message,
      });
  }
}

async function unarchiveChat(req, res) {
  const { chatId } = req.body;
  if (!chatId)
    return res
      .status(400)
      .json({ status: "Error", message: "Söhbət ID-si boş ola bilməz." });

  if (isWahaEnabled()) {
    try {
      const result = await wahaActions.unarchiveChat({ chatId });
      if (result.ok) {
        return res
          .status(200)
          .json({
            status: "OK",
            transport: "WAHA",
            message: `Söhbət ${chatId} WAHA ilə arxivdən çıxarıldı.`,
          });
      }
      logWithTimestamp(
        `⚠️ WAHA unarchiveChat xətası: ${result.status} ${result.error || ""}`,
      );
    } catch (error) {
      logWithTimestamp("⚠️ WAHA unarchiveChat istisnası:", error.message);
    }
  }

  if (!requireLegacyClient(res)) return;

  try {
    const chat = await whatsappClient.getChatById(chatId);
    await chat.unarchive();
    res
      .status(200)
      .json({
        status: "OK",
        transport: "webjs",
        message: `Söhbət ${chatId} uğurla arxivdən çıxarıldı.`,
      });
  } catch (error) {
    res
      .status(500)
      .json({
        status: "Error",
        message: "Söhbəti arxivdən çıxarmaq mümkün olmadı.",
        error: error.message,
      });
  }
}

async function pinMessage(req, res) {
  const { messageId, chatId } = req.body;
  if (!messageId)
    return res
      .status(400)
      .json({ status: "Error", message: "Mesaj ID-si boş ola bilməz." });

  if (isWahaEnabled() && chatId) {
    try {
      const result = await wahaActions.pinMessage({
        chatId,
        messageId,
        pin: true,
      });
      if (result.ok) {
        return res
          .status(200)
          .json({
            status: "OK",
            transport: "WAHA",
            message: `Mesaj ${messageId} WAHA ilə pinləndi.`,
          });
      }
      logWithTimestamp(
        `⚠️ WAHA pinMessage xətası: ${result.status} ${result.error || ""}`,
      );
    } catch (error) {
      logWithTimestamp("⚠️ WAHA pinMessage istisnası:", error.message);
    }
  }

  if (!requireLegacyClient(res)) return;

  try {
    const message = await whatsappClient.getMessageById(messageId);
    await message.pin();
    res
      .status(200)
      .json({
        status: "OK",
        transport: "webjs",
        message: `Mesaj ${messageId} uğurla pinləndi.`,
      });
  } catch (error) {
    res
      .status(500)
      .json({
        status: "Error",
        message: "Mesajı pinləmək mümkün olmadı.",
        error: error.message,
      });
  }
}

async function unpinMessage(req, res) {
  const { messageId, chatId } = req.body;
  if (!messageId)
    return res
      .status(400)
      .json({ status: "Error", message: "Mesaj ID-si boş ola bilməz." });

  if (isWahaEnabled() && chatId) {
    try {
      const result = await wahaActions.pinMessage({
        chatId,
        messageId,
        pin: false,
      });
      if (result.ok) {
        return res
          .status(200)
          .json({
            status: "OK",
            transport: "WAHA",
            message: `Mesaj ${messageId} WAHA ilə pin ləğv edildi.`,
          });
      }
      logWithTimestamp(
        `⚠️ WAHA unpinMessage xətası: ${result.status} ${result.error || ""}`,
      );
    } catch (error) {
      logWithTimestamp("⚠️ WAHA unpinMessage istisnası:", error.message);
    }
  }

  if (!requireLegacyClient(res)) return;

  try {
    const message = await whatsappClient.getMessageById(messageId);
    await message.unpin();
    res
      .status(200)
      .json({
        status: "OK",
        transport: "webjs",
        message: `Mesaj ${messageId} pini uğurla ləğv edildi.`,
      });
  } catch (error) {
    res
      .status(500)
      .json({
        status: "Error",
        message: "Mesajın pinini ləğv etmək mümkün olmadı.",
        error: error.message,
      });
  }
}

async function markChatAsRead(req, res) {
  const { chatId } = req.body;
  if (!chatId)
    return res
      .status(400)
      .json({ status: "Error", message: "Söhbət ID-si boş ola bilməz." });

  if (isWahaEnabled()) {
    try {
      const result = await wahaActions.markChat({ chatId, action: "read" });
      if (result.ok) {
        return res
          .status(200)
          .json({
            status: "OK",
            transport: "WAHA",
            message: `Söhbət ${chatId} WAHA ilə oxunmuş kimi işarələndi.`,
          });
      }
      logWithTimestamp(
        `⚠️ WAHA markChat read xətası: ${result.status} ${result.error || ""}`,
      );
    } catch (error) {
      logWithTimestamp("⚠️ WAHA markChat read istisnası:", error.message);
    }
  }

  if (!requireLegacyClient(res)) return;

  try {
    const chat = await whatsappClient.getChatById(chatId);
    await chat.sendSeen();
    res
      .status(200)
      .json({
        status: "OK",
        transport: "webjs",
        message: `Söhbət ${chatId} oxunmuş kimi işarələndi.`,
      });
  } catch (error) {
    res
      .status(500)
      .json({
        status: "Error",
        message: "Söhbəti oxunmuş kimi işarələmək mümkün olmadı.",
        error: error.message,
      });
  }
}

async function markChatAsUnread(req, res) {
  const { chatId } = req.body;
  if (!chatId)
    return res
      .status(400)
      .json({ status: "Error", message: "Söhbət ID-si boş ola bilməz." });

  if (isWahaEnabled()) {
    try {
      const result = await wahaActions.markChat({ chatId, action: "unread" });
      if (result.ok) {
        return res
          .status(200)
          .json({
            status: "OK",
            transport: "WAHA",
            message: `Söhbət ${chatId} WAHA ilə oxunmamış kimi işarələndi.`,
          });
      }
      logWithTimestamp(
        `⚠️ WAHA markChat unread xətası: ${result.status} ${result.error || ""}`,
      );
    } catch (error) {
      logWithTimestamp("⚠️ WAHA markChat unread istisnası:", error.message);
    }
  }

  if (!requireLegacyClient(res)) return;

  try {
    const chat = await whatsappClient.getChatById(chatId);
    await chat.markUnread();
    res
      .status(200)
      .json({
        status: "OK",
        transport: "webjs",
        message: `Söhbət ${chatId} oxunmamış kimi işarələndi.`,
      });
  } catch (error) {
    res
      .status(500)
      .json({
        status: "Error",
        message: "Söhbəti oxunmamış kimi işarələmək mümkün olmadı.",
        error: error.message,
      });
  }
}

// --- Kontakt (Contact) İdarəetməsi ---
async function getContactInfo(req, res) {
  const { number } = req.query;
  if (!number)
    return res
      .status(400)
      .json({ status: "Error", message: "Nömrə boş ola bilməz." });

  if (isWahaEnabled()) {
    try {
      const { session } = getWahaConfig();
      const result = await wahaRequest({
        method: "GET",
        path: `/api/${session}/contacts/${encodeURIComponent(number.includes("@") ? number : `${number}@c.us`)}`,
      });
      if (result.ok) {
        return res
          .status(200)
          .json({ status: "OK", transport: "WAHA", data: result.data });
      }
      logWithTimestamp(
        `⚠️ WAHA kontakt məlumatı xətası: ${result.status} ${result.error || ""}`,
      );
    } catch (error) {
      logWithTimestamp("⚠️ WAHA getContactInfo istisnası:", error.message);
    }
  }

  if (!requireLegacyClient(res)) return;

  try {
    const contact = await whatsappClient.getContactById(`${number}@c.us`);
    res.status(200).json({
      status: "OK",
      transport: "webjs",
      data: {
        id: contact.id._serialized,
        name: contact.name || contact.pushname,
        isBlocked: contact.isBlocked,
        isBusiness: contact.isBusiness,
      },
    });
  } catch (error) {
    res
      .status(500)
      .json({
        status: "Error",
        message: "Kontakt məlumatını almaq mümkün olmadı.",
        error: error.message,
      });
  }
}

async function getProfilePicUrl(req, res) {
  const { number } = req.query;
  if (!number)
    return res
      .status(400)
      .json({ status: "Error", message: "Nömrə boş ola bilməz." });

  if (isWahaEnabled()) {
    try {
      const { session } = getWahaConfig();
      const result = await wahaRequest({
        method: "GET",
        path: `/api/${session}/contacts/${encodeURIComponent(number.includes("@") ? number : `${number}@c.us`)}/profile-picture`,
      });
      if (result.ok) {
        return res
          .status(200)
          .json({ status: "OK", transport: "WAHA", data: result.data });
      }
      logWithTimestamp(
        `⚠️ WAHA profil şəkli xətası: ${result.status} ${result.error || ""}`,
      );
    } catch (error) {
      logWithTimestamp("⚠️ WAHA getProfilePicUrl istisnası:", error.message);
    }
  }

  if (!requireLegacyClient(res)) return;

  try {
    const url = await whatsappClient.getProfilePicUrl(`${number}@c.us`);
    res
      .status(200)
      .json({ status: "OK", transport: "webjs", data: { profilePicUrl: url } });
  } catch (error) {
    res
      .status(500)
      .json({
        status: "Error",
        message: "Profil şəkli URL-i almaq mümkün olmadı.",
        error: error.message,
      });
  }
}

async function getAllContacts(req, res) {
  if (isWahaEnabled()) {
    try {
      const result = await wahaActions.fetchContacts({
        limit: Number(req.query.limit) || 100,
      });
      if (result.ok) {
        return res
          .status(200)
          .json({ status: "OK", transport: "WAHA", data: result.data });
      }
      logWithTimestamp(
        `⚠️ WAHA kontakt siyahısı xətası: ${result.status} ${result.error || ""}`,
      );
    } catch (error) {
      logWithTimestamp("⚠️ WAHA getAllContacts istisnası:", error.message);
    }
  }

  if (!requireLegacyClient(res)) return;

  try {
    const contacts = await whatsappClient.getContacts();
    res.status(200).json({
      status: "OK",
      transport: "webjs",
      data: contacts.map((c) => ({
        id: c.id._serialized,
        name: c.name || c.pushname || c.id._serialized,
        isBusiness: c.isBusiness,
      })),
    });
  } catch (error) {
    res
      .status(500)
      .json({
        status: "Error",
        message: "Bütün kontaktları almaq mümkün olmadı.",
        error: error.message,
      });
  }
}

module.exports = {
  setWhatsAppClient,
  // Sessiya və Status
  getClientStatus,
  logoutClient,
  resetClientSession,
  getWahaSessionStatus,
  startWahaSession,
  getWahaSessionQr,
  // Mesajlar
  sendText,
  sendMedia,
  sendLocation,
  sendContact,
  // Məlumatlar
  getProducts,
  getServices,
  getAllOrders,
  createOrder,
  // Söhbətlər
  getChats,
  archiveChat,
  unarchiveChat,
  pinMessage,
  unpinMessage,
  markChatAsRead,
  markChatAsUnread,
  // Kontaktlar
  getContactInfo,
  getProfilePicUrl,
  getAllContacts,
};
