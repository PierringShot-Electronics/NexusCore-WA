const waha = require("../services/waha");
const { ensureWaha, handleServiceResponse } = require("./wahaUtils");

async function listStatus(req, res) {
  if (!ensureWaha(res)) return;
  const result = await waha.listStatus({ session: req.query.session });
  return handleServiceResponse(res, result);
}

async function postTextStatus(req, res) {
  if (!ensureWaha(res)) return;
  const { text, backgroundColor, font } = req.body;
  try {
    const result = await waha.postTextStatus({ session: req.query.session, text, backgroundColor, font });
    return handleServiceResponse(res, result, 201);
  } catch (error) {
    return res.status(400).json({ status: "Error", message: error.message });
  }
}

async function postImageStatus(req, res) {
  return sendMediaStatus(req, res, waha.postImageStatus);
}

async function postVideoStatus(req, res) {
  return sendMediaStatus(req, res, waha.postVideoStatus);
}

async function deleteStatus(req, res) {
  if (!ensureWaha(res)) return;
  const { statusId } = req.params;
  const result = await waha.deleteStatus({ session: req.query.session, statusId });
  return handleServiceResponse(res, result, 204);
}

async function sendMediaStatus(req, res, handler) {
  if (!ensureWaha(res)) return;
  const { mediaUrl, mediaBase64, caption, mimeType, fileName } = req.body;
  try {
    const result = await handler({
      session: req.query.session,
      mediaUrl,
      mediaBase64,
      caption,
      mimeType,
      fileName,
    });
    return handleServiceResponse(res, result, 201);
  } catch (error) {
    return res.status(400).json({ status: "Error", message: error.message });
  }
}

module.exports = {
  listStatus,
  postTextStatus,
  postImageStatus,
  postVideoStatus,
  deleteStatus,
};
