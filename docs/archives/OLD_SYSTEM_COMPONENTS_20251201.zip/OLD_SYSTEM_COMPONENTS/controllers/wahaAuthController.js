const waha = require("../services/waha");
const { ensureWaha, handleServiceResponse, ensureQrEnabled } = require("./wahaUtils");

async function getQr(req, res) {
  if (!ensureWaha(res)) return;
  if (!ensureQrEnabled(req, res)) return;
  const session = req.params?.session || req.query?.session;
  const { format } = req.query || {};
  const result = await waha.getQr({ session, format });
  return handleServiceResponse(res, result);
}

async function requestCode(req, res) {
  if (!ensureWaha(res)) return;
  const session = req.params?.session || req.body?.session;
  const { channel, phone } = req.body || {};
  const result = await waha.requestCode({ session, channel, phone });
  return handleServiceResponse(res, result, 202);
}

module.exports = {
  getQr,
  requestCode,
};
