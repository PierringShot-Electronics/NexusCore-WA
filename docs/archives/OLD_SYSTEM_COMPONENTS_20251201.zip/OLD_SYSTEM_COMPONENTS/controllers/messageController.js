/**
 * WhatsCore.AI - Maverick Edition
 *
 * Mesaj Controller (Controller) - v5.1.0
 * Mətn və media buferləri üçün fallback məntiqi bufferEngine xidmətinə daşınıb.
 */
const { getAIResponse } = require("../services/ai");
const { logWithTimestamp } = require("../utils/logger");
const { saveHistory } = require("../services/historyManager");
const { findOrCreateLead } = require("../services/leadManager");
const { createBufferEngine } = require("../services/bufferEngine");
const { routeIntent } = require("../services/intentRouter");
const { prepareAutoReplies } = require("../services/automation/autoResponses");

const IGNORED_MESSAGE_TYPES = new Set([
  "e2e_notification",
  "notification_template",
  "ciphertext",
  "protocol_message",
  "reaction",
  "revoked",
]);

async function replyToMessage(client, chatId, responseText, originalMessage) {
  try {
    if (!responseText || responseText.trim() === "") return;
    const options = { quotedMessageId: originalMessage ? originalMessage.id._serialized : null };
    const sentMessage = await client.sendMessage(chatId, responseText.trim(), options);
    logWithTimestamp(`✅ Cavab (Reply) uğurla göndərildi: [${chatId}]`);
    await saveHistory(
      chatId,
      {
        type: "text",
        content: responseText.trim(),
        sender: "assistant",
        quotedMsgId: originalMessage ? originalMessage.id._serialized : null,
      },
      sentMessage.id._serialized,
    );
  } catch (error) {
    logWithTimestamp(`❌ Cavab göndərmə xətası [${chatId}]:`, error.message);
  }
}

const bufferEngine = createBufferEngine({ getAIResponse, replyToMessage });

async function handleMessage(client, message) {
  const chatId = message.from;
  if (message.fromMe || message.isStatus) return;
  if (IGNORED_MESSAGE_TYPES.has(message.type)) {
    logWithTimestamp(
      `ℹ️  ${message.type} tipli mesaj cavablandırılmır: [${chatId}]`,
    );
    return;
  }

  try {
    const chat = await message.getChat();
    await chat.sendSeen();
    const lead = await findOrCreateLead(chatId);
    logWithTimestamp(`📨 Mesaj [${lead.status}] statuslu lead üçün emal edilir: [${lead.lead_id}]`);
    const quotedMsgId = message.hasQuotedMsg && message._data.quotedMsg
      ? message._data.quotedMsg.id._serialized
      : null;
    await saveHistory(
      chatId,
      { type: message.type, content: message.body || "", sender: "user", quotedMsgId },
      message.id._serialized,
    );

    const autoReplies = await prepareAutoReplies({ chatId });
    for (const auto of autoReplies) {
      await replyToMessage(client, chatId, auto.text, message);
    }

    if (message.hasMedia) {
      if (bufferEngine.hasTextBuffer(chatId)) {
        bufferEngine.cancelTextTimer(chatId);
        await bufferEngine.flushTextBuffer(client, chatId);
      }
      bufferEngine.cancelMediaTimer(chatId);
      const entry = bufferEngine.enqueueMediaMessage({ client, chatId, message });
      logWithTimestamp(
        `📥 Media buferə əlavə olundu: [${chatId}]. Hazırda ${entry.messages.length} fayl var.`,
      );
      return;
    }

    if (message.type === "chat" && message.body.trim() !== "") {
      const routing = routeIntent(message.body, { chatId });
      if (routing.requiresClarification && routing.clarificationPrompt) {
        logWithTimestamp(
          `🤔 Niyyət qeyri-müəyyəndir (${routing.score}); aydınlaşdırma soruşulur.`,
        );
        await replyToMessage(client, chatId, routing.clarificationPrompt, message);
        return;
      }
      message.intentHint = routing.intent;
      message.intentScore = routing.score;
      if (bufferEngine.hasMediaBuffer(chatId)) {
        bufferEngine.cancelMediaTimer(chatId);
        await bufferEngine.flushMediaBuffer(client, chatId);
      }
      chat.sendStateTyping();
      bufferEngine.cancelTextTimer(chatId);
      const entry = bufferEngine.enqueueTextMessage({ client, chat, chatId, message });
      logWithTimestamp(
        `✏️ Mətn buferinə mesaj əlavə edildi: [${chatId}] say ${entry.messages.length}.`,
      );
      return;
    }

    if (bufferEngine.hasMediaBuffer(chatId)) {
      bufferEngine.cancelMediaTimer(chatId);
      await bufferEngine.flushMediaBuffer(client, chatId);
    }
    if (bufferEngine.hasTextBuffer(chatId)) {
      bufferEngine.cancelTextTimer(chatId);
      await bufferEngine.flushTextBuffer(client, chatId);
    }

    chat.sendStateTyping();
    let userInput = { text: message.body || "", media: [] };
    if (message.type === "location") {
      userInput.text = `İstifadəçi bir məkan göndərdi: Lat: ${message.location.latitude}, Lon: ${message.location.longitude}.`;
    }
    const aiResponse = await getAIResponse(chatId, userInput);
    await replyToMessage(client, chatId, aiResponse, message);
    chat.clearState();
  } catch (error) {
    logWithTimestamp(`❌ Mesaj emalında ümumi xəta [${chatId}]:`, error);
    await replyToMessage(client, chatId, "🤖 Üzr istəyirəm, naməlum bir xəta baş verdi.", message);
  }
}

module.exports = { handleMessage };
