const {
  getState,
  setPaused,
} = require("../services/orchestrator/automationState");

function requireAdmin(req, res) {
  const adminKey = process.env.ADMIN_API_KEY;
  if (!adminKey) {
    return true;
  }
  const provided =
    req.get("X-Admin-Key") ||
    req.query.adminKey ||
    (req.body && req.body.adminKey);
  if (provided === adminKey) {
    return true;
  }
  res.status(403).json({
    status: "Error",
    message: "Admin icazəsi tələb olunur.",
  });
  return false;
}

function buildActor(req) {
  return (
    req.get("X-Admin-Actor") ||
    req.body?.actor ||
    req.query?.actor ||
    "api"
  );
}

async function getAutomationState(req, res) {
  if (!requireAdmin(req, res)) return;
  if (process.env.LOG_AUTOMATION_DEBUG === "true") {
    // eslint-disable-next-line no-console
    console.log("[orchestrator] State requested");
  }
  res.status(200).json({ status: "OK", data: getState() });
}

async function pauseAutomation(req, res) {
  if (!requireAdmin(req, res)) return;
  const reason =
    (req.body && req.body.reason) || req.query?.reason || "Operator initiated pause";
  const actor = buildActor(req);
  const next = setPaused(true, { reason, actor });
  res.status(202).json({ status: "OK", data: next });
}

async function resumeAutomation(req, res) {
  if (!requireAdmin(req, res)) return;
  const actor = buildActor(req);
  const next = setPaused(false, { actor, reason: null });
  res.status(202).json({ status: "OK", data: next });
}

module.exports = {
  getAutomationState,
  pauseAutomation,
  resumeAutomation,
};
