const waha = require("../services/waha");
const { ensureWaha, handleServiceResponse } = require("./wahaUtils");

async function listContacts(req, res) {
  if (!ensureWaha(res)) return;
  const { limit, cursor } = req.query;
  const result = await waha.listContacts({
    session: req.query.session,
    limit: limit ? Number(limit) : undefined,
    cursor,
  });
  return handleServiceResponse(res, result);
}

async function getContact(req, res) {
  if (!ensureWaha(res)) return;
  const { contactId } = req.params;
  const { number } = req.query;
  const result = await waha.getContact({ session: req.query.session, chatId: contactId, number });
  return handleServiceResponse(res, result);
}

async function getAbout(req, res) {
  if (!ensureWaha(res)) return;
  const { contactId } = req.params;
  const { number } = req.query;
  const result = await waha.getContactAbout({ session: req.query.session, chatId: contactId, number });
  return handleServiceResponse(res, result);
}

async function setLabels(req, res) {
  if (!ensureWaha(res)) return;
  const { contactId } = req.params;
  const { labels } = req.body;
  try {
    const result = await waha.setContactLabel({ session: req.query.session, chatId: contactId, labels });
    return handleServiceResponse(res, result);
  } catch (error) {
    return res.status(400).json({ status: "Error", message: error.message });
  }
}

async function checkNumber(req, res) {
  if (!ensureWaha(res)) return;
  const { number } = req.body;
  try {
    const result = await waha.checkNumberStatus({ session: req.query.session, number });
    return handleServiceResponse(res, result);
  } catch (error) {
    return res.status(400).json({ status: "Error", message: error.message });
  }
}

async function blockContact(req, res) {
  if (!ensureWaha(res)) return;
  const { contactId } = req.params;
  const result = await waha.blockContact({ session: req.query.session, chatId: contactId });
  return handleServiceResponse(res, result);
}

async function unblockContact(req, res) {
  if (!ensureWaha(res)) return;
  const { contactId } = req.params;
  const result = await waha.unblockContact({ session: req.query.session, chatId: contactId });
  return handleServiceResponse(res, result);
}

async function getProfilePicture(req, res) {
  if (!ensureWaha(res)) return;
  const { contactId } = req.params;
  const { number, format } = req.query;
  const result = await waha.getProfilePicture({ session: req.query.session, chatId: contactId, number, format });
  return handleServiceResponse(res, result);
}

module.exports = {
  listContacts,
  getContact,
  getAbout,
  setLabels,
  checkNumber,
  blockContact,
  unblockContact,
  getProfilePicture,
};
