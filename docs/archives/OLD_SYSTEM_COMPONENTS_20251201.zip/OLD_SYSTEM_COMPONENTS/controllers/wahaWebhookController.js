const crypto = require("crypto");
const { logWithTimestamp } = require("../utils/logger");
const { dispatchEvents } = require("../services/wahaWebhookHandler");

const DEFAULT_HMAC_HEADER = (process.env.WAHA_HMAC_HEADER || "x-signature").toLowerCase();

function getRawBody(req) {
  if (Buffer.isBuffer(req.rawBody)) {
    return req.rawBody;
  }
  if (typeof req.body === "string") {
    return Buffer.from(req.body);
  }
  if (req.body && typeof req.body === "object") {
    try {
      return Buffer.from(JSON.stringify(req.body));
    } catch (error) {
      logWithTimestamp("⚠️ WAHA webhook raw body stringify xətası:", error.message);
    }
  }
  return Buffer.from("");
}

function normalizeSignature(headerValue) {
  if (!headerValue) return "";
  const trimmed = String(headerValue).trim();
  if (!trimmed) return "";
  return trimmed.toLowerCase().startsWith("sha256=")
    ? trimmed.slice(7).trim()
    : trimmed;
}

function timingSafeCompare(a, b, encoding = "hex") {
  try {
    const bufA = Buffer.from(a, encoding);
    const bufB = Buffer.from(b, encoding);
    if (bufA.length !== bufB.length) return false;
    return crypto.timingSafeEqual(bufA, bufB);
  } catch {
    return false;
  }
}

function verifySignature(req) {
  const secret = process.env.WAHA_HMAC_SECRET;
  if (!secret) {
    return true;
  }

  const headerName = DEFAULT_HMAC_HEADER;
  const provided = req.get(headerName) || req.headers[headerName];
  if (!provided) {
    logWithTimestamp("⚠️ WAHA webhook imza header-i çatmır:", headerName);
    return false;
  }

  const payload = getRawBody(req);
  const digest = crypto.createHmac("sha256", secret).update(payload).digest("hex");
  const normalized = normalizeSignature(provided);

  if (/^[0-9a-f]+$/i.test(normalized) && normalized.length === digest.length) {
    return timingSafeCompare(digest, normalized);
  }

  const digestBase64 = Buffer.from(digest, "hex").toString("base64");
  if (digestBase64.length === normalized.length) {
    return timingSafeCompare(digestBase64, normalized, "utf8");
  }

  logWithTimestamp("⚠️ WAHA webhook imzası formatı uyğun deyil.");
  return false;
}

function ensureEventArray(body) {
  if (Array.isArray(body)) {
    return body;
  }
  if (body && typeof body === "object") {
    return [body];
  }
  return [];
}

async function handleWebhook(req, res) {
  const events = ensureEventArray(req.body);
  if (events.length === 0) {
    return res
      .status(400)
      .json({ status: "Error", message: "Payload boş və ya düzgün formatda deyil." });
  }

  if (!verifySignature(req)) {
    return res
      .status(401)
      .json({ status: "Error", message: "WAHA HMAC imzası təsdiqlənmədi." });
  }

  dispatchEvents(events);
  return res.status(202).json({ status: "OK" });
}

module.exports = { handleWebhook };
