const waha = require("../services/waha");
const { handleServiceResponse } = require("./wahaUtils");
const legacyMessenger = require("../services/legacyMessenger");
const { logWithTimestamp } = require("../utils/logger");

const DISABLE_VALUES = new Set(["false", "0", "no", "off", "disabled"]);

function isWahaReady() {
  return waha.isWahaConfigured && waha.isWahaConfigured();
}

function isFallbackEnabled() {
  const flag = process.env.ENABLE_WEBJS_FALLBACK;
  if (!flag) return false;
  const normalized = String(flag).trim().toLowerCase();
  return !DISABLE_VALUES.has(normalized);
}

async function executeWithFallback(res, {
  operation,
  successStatus = 200,
  wahaCall,
  fallbackCall,
}) {
  const wahaConfigured = isWahaReady();
  const fallbackAllowed = isFallbackEnabled();
  const fallbackReady = fallbackAllowed && legacyMessenger.isReady();

  if (wahaConfigured) {
    try {
      const result = await wahaCall();
      if (result?.ok) {
        return handleServiceResponse(res, result, successStatus);
      }
      const statusCode = Number(result?.status || 0);
      if (
        statusCode >= 400 &&
        statusCode < 500 &&
        statusCode !== 429
      ) {
        logWithTimestamp(
          `⚠️ WAHA ${operation} ${statusCode} statusu qaytardı; whatsapp-web.js fallback işə düşməyəcək.`,
        );
        return res
          .status(statusCode)
          .json({
            status: "Error",
            transport: "WAHA",
            message:
              result?.error ||
              `WAHA ${operation} əməliyyatı ${statusCode} statusu ilə tamamlandı.`,
            data: result?.data || null,
          });
      }
      if (!fallbackReady) {
        return res
          .status(result?.status || 500)
          .json({
            status: "Error",
            transport: "WAHA",
            message:
              result?.error ||
              `WAHA ${operation} əməliyyatı uğursuz oldu və fallback aktiv deyil.`,
          });
      }
      logWithTimestamp(
        `⚠️ WAHA ${operation} uğursuz oldu (${result?.status || "?"}). whatsapp-web.js fallback tətbiq olunur.`,
      );
    } catch (error) {
      if (!fallbackReady) {
        return res
          .status(500)
          .json({
            status: "Error",
            transport: "WAHA",
            message: error.message,
          });
      }
      logWithTimestamp(
        `⚠️ WAHA ${operation} istisnası: ${error.message}. whatsapp-web.js fallback istifadə olunur.`,
      );
    }
  } else if (!fallbackReady) {
    return res
      .status(503)
      .json({
        status: "Error",
        message:
          "WAHA konfiqurasiyası deaktivdir və whatsapp-web.js fallback hələ hazır deyil.",
      });
  }

  if (!fallbackReady) {
    return res
      .status(503)
      .json({
        status: "Error",
        message:
          "whatsapp-web.js fallback hazır deyil və WAHA əməliyyatı tamamlanmadı.",
      });
  }

  try {
    const fallbackResult = await fallbackCall();
    if (fallbackResult?.ok) {
      return res.status(fallbackResult.status || successStatus).json({
        status: "OK",
        transport: "webjs",
        message:
          fallbackResult.message ||
          `${operation} whatsapp-web.js ilə icra olundu.`,
        data: fallbackResult.data || null,
      });
    }
    return res.status(fallbackResult?.status || 500).json({
      status: "Error",
      transport: "webjs",
      message:
        fallbackResult?.error ||
        `whatsapp-web.js fallback ${operation} əməliyyatını yerinə yetirə bilmədi.`,
    });
  } catch (error) {
    return res.status(500).json({
      status: "Error",
      transport: "webjs",
      message: error.message,
    });
  }
}

async function sendText(req, res) {
  const { number, chatId, message, quotedMsgId, options } = req.body;
  return executeWithFallback(res, {
    operation: "sendText",
    wahaCall: () =>
      waha.sendText({ number, chatId, message, quotedMsgId, options }),
    fallbackCall: () =>
      legacyMessenger.sendText({ number, chatId, message, quotedMsgId, options }),
  });
}

async function sendImage(req, res) {
  return sendMediaVariant(req, res, "sendImage", waha.sendImage);
}

async function sendVideo(req, res) {
  return sendMediaVariant(req, res, "sendVideo", waha.sendVideo);
}

async function sendAudio(req, res) {
  return sendMediaVariant(req, res, "sendAudio", waha.sendAudio);
}

async function sendVoice(req, res) {
  return sendMediaVariant(req, res, "sendVoice", waha.sendVoice);
}

async function sendFile(req, res) {
  return sendMediaVariant(req, res, "sendFile", waha.sendFile);
}

async function sendSticker(req, res) {
  return sendMediaVariant(req, res, "sendSticker", waha.sendSticker);
}

async function sendTemplate(req, res) {
  const { number, chatId, namespace, templateName, language, components } = req.body;
  return executeWithFallback(res, {
    operation: "sendTemplate",
    successStatus: 201,
    wahaCall: () =>
      waha.sendTemplate({
        number,
        chatId,
        namespace,
        templateName,
        language,
        components,
      }),
    fallbackCall: async () => ({
      ok: false,
      status: 501,
      error: "Şablon mesajları yalnız WAHA vasitəsilə dəstəklənir.",
    }),
  });
}

async function sendList(req, res) {
  const { number, chatId, header, body, footer, buttonText, sections, replyTo } = req.body;
  return executeWithFallback(res, {
    operation: "sendList",
    successStatus: 201,
    wahaCall: () =>
      waha.sendList({
        number,
        chatId,
        header,
        body,
        footer,
        buttonText,
        sections,
        replyTo,
      }),
    fallbackCall: () =>
      legacyMessenger.sendList({
        number,
        chatId,
        header,
        body,
        footer,
        buttonText,
        sections,
        replyTo,
      }),
  });
}

async function sendButtons(req, res) {
  const { number, chatId, header, body, footer, buttons, headerImage, replyTo } = req.body;
  return executeWithFallback(res, {
    operation: "sendButtons",
    successStatus: 201,
    wahaCall: () =>
      waha.sendButtons({
        number,
        chatId,
        header,
        body,
        footer,
        buttons,
        headerImage,
        replyTo,
      }),
    fallbackCall: () =>
      legacyMessenger.sendButtons({
        number,
        chatId,
        header,
        body,
        footer,
        buttons,
        headerImage,
        replyTo,
      }),
  });
}

async function sendButtonsReply(req, res) {
  const { number, chatId, replyTo, selectedDisplayText, selectedButtonID } = req.body;
  return executeWithFallback(res, {
    operation: "sendButtonsReply",
    wahaCall: () =>
      waha.sendButtonsReply({
        number,
        chatId,
        replyTo,
        selectedDisplayText,
        selectedButtonID,
      }),
    fallbackCall: async () => ({
      ok: false,
      status: 501,
      error: "Buttons cavabları yalnız WAHA vasitəsilə mövcuddur.",
    }),
  });
}

async function sendPoll(req, res) {
  const { number, chatId, poll, replyTo } = req.body;
  return executeWithFallback(res, {
    operation: "sendPoll",
    successStatus: 201,
    wahaCall: () => waha.sendPoll({ number, chatId, poll, replyTo }),
    fallbackCall: () => legacyMessenger.sendPoll({ number, chatId, poll, replyTo }),
  });
}

async function sendLocation(req, res) {
  const { number, chatId, latitude, longitude, description, title } = req.body;
  return executeWithFallback(res, {
    operation: "sendLocation",
    successStatus: 201,
    wahaCall: () =>
      waha.sendLocation({
        number,
        chatId,
        latitude,
        longitude,
        description,
        title,
      }),
    fallbackCall: () =>
      legacyMessenger.sendLocation({
        number,
        chatId,
        latitude,
        longitude,
        description,
        title,
      }),
  });
}

async function sendContact(req, res) {
  const { number, chatId, contacts } = req.body;
  return executeWithFallback(res, {
    operation: "sendContact",
    successStatus: 201,
    wahaCall: () => waha.sendContact({ number, chatId, contacts }),
    fallbackCall: async () => ({
      ok: false,
      status: 501,
      error: "Kontakt paylaşımı yalnız WAHA vasitəsilə dəstəklənir.",
    }),
  });
}

async function forwardMessage(req, res) {
  const { number, chatId, messageId } = req.body;
  return executeWithFallback(res, {
    operation: "forwardMessage",
    wahaCall: () => waha.forwardMessage({ number, chatId, messageId }),
    fallbackCall: async () => ({
      ok: false,
      status: 501,
      error: "Mesajı yönləndirmə hələ fallback rejimində mövcud deyil.",
    }),
  });
}

async function markSeen(req, res) {
  const { number, chatId, messageIds, participant } = req.body;
  return executeWithFallback(res, {
    operation: "markSeen",
    wahaCall: () => waha.sendSeen({ number, chatId, messageIds, participant }),
    fallbackCall: async () => ({
      ok: false,
      status: 501,
      error: "Seen statusu yalnız WAHA vasitəsilə dəstəklənir.",
    }),
  });
}

async function startTyping(req, res) {
  const { number, chatId } = req.body;
  return executeWithFallback(res, {
    operation: "startTyping",
    wahaCall: () => waha.startTyping({ number, chatId }),
    fallbackCall: async () => ({
      ok: false,
      status: 501,
      error: "Typing indikatoru yalnız WAHA vasitəsilə aktivləşdirilir.",
    }),
  });
}

async function stopTyping(req, res) {
  const { number, chatId } = req.body;
  return executeWithFallback(res, {
    operation: "stopTyping",
    wahaCall: () => waha.stopTyping({ number, chatId }),
    fallbackCall: async () => ({
      ok: false,
      status: 501,
      error: "Typing indikatoru yalnız WAHA vasitəsilə deaktiv edilir.",
    }),
  });
}

async function starMessage(req, res) {
  const { number, chatId, messageId, star } = req.body;
  return executeWithFallback(res, {
    operation: "starMessage",
    wahaCall: () => waha.starMessage({ number, chatId, messageId, star }),
    fallbackCall: async () => ({
      ok: false,
      status: 501,
      error: "Mesajları ulduzlama funksiyası yalnız WAHA ilə aktivdir.",
    }),
  });
}

async function sendMediaVariant(req, res, operation, handler) {
  const { number, chatId, caption, mediaUrl, mediaBase64, mimeType, fileName, replyTo, message, extra, file } = req.body;
  return executeWithFallback(res, {
    operation,
    successStatus: 201,
    wahaCall: () =>
      handler({
        number,
        chatId,
        caption,
        mediaUrl,
        mediaBase64,
        mimeType,
        fileName,
        replyTo,
        message,
        extra,
        file,
      }),
    fallbackCall: () =>
      legacyMessenger.sendMedia({
        number,
        chatId,
        caption,
        mediaUrl,
        mediaBase64,
        mimeType,
        fileName,
        replyTo,
        message,
        extra,
        file,
      }),
  });
}

module.exports = {
  sendText,
  sendImage,
  sendVideo,
  sendAudio,
  sendVoice,
  sendFile,
  sendSticker,
  sendTemplate,
  sendList,
  sendButtons,
  sendButtonsReply,
  sendPoll,
  sendLocation,
  sendContact,
  forwardMessage,
  markSeen,
  startTyping,
  stopTyping,
  starMessage,
};
