const waha = require("../services/waha");
const { ensureWaha, handleServiceResponse } = require("./wahaUtils");

async function listGroups(req, res) {
  if (!ensureWaha(res)) return;
  const { limit, cursor } = req.query;
  const result = await waha.listGroups({
    session: req.query.session,
    limit: limit ? Number(limit) : undefined,
    cursor,
  });
  return handleServiceResponse(res, result);
}

async function getGroup(req, res) {
  if (!ensureWaha(res)) return;
  const { groupId } = req.params;
  const result = await waha.getGroup({ session: req.query.session, groupId });
  return handleServiceResponse(res, result);
}

async function createGroup(req, res) {
  if (!ensureWaha(res)) return;
  const { subject, participants, description } = req.body;
  try {
    const result = await waha.createGroup({
      session: req.query.session,
      subject,
      participants,
      description,
    });
    return handleServiceResponse(res, result, 201);
  } catch (error) {
    return res.status(400).json({ status: "Error", message: error.message });
  }
}

async function updateSubject(req, res) {
  if (!ensureWaha(res)) return;
  const { groupId } = req.params;
  const { subject } = req.body;
  try {
    const result = await waha.updateGroupSubject({ session: req.query.session, groupId, subject });
    return handleServiceResponse(res, result);
  } catch (error) {
    return res.status(400).json({ status: "Error", message: error.message });
  }
}

async function updateDescription(req, res) {
  if (!ensureWaha(res)) return;
  const { groupId } = req.params;
  const { description } = req.body;
  const result = await waha.updateGroupDescription({ session: req.query.session, groupId, description });
  return handleServiceResponse(res, result);
}

async function addParticipants(req, res) {
  if (!ensureWaha(res)) return;
  const { groupId } = req.params;
  const { participants } = req.body;
  try {
    const result = await waha.addParticipants({ session: req.query.session, groupId, participants });
    return handleServiceResponse(res, result);
  } catch (error) {
    return res.status(400).json({ status: "Error", message: error.message });
  }
}

async function removeParticipants(req, res) {
  if (!ensureWaha(res)) return;
  const { groupId } = req.params;
  const { participants } = req.body;
  try {
    const result = await waha.removeParticipants({ session: req.query.session, groupId, participants });
    return handleServiceResponse(res, result);
  } catch (error) {
    return res.status(400).json({ status: "Error", message: error.message });
  }
}

async function promoteParticipants(req, res) {
  if (!ensureWaha(res)) return;
  const { groupId } = req.params;
  const { participants } = req.body;
  try {
    const result = await waha.promoteParticipants({ session: req.query.session, groupId, participants });
    return handleServiceResponse(res, result);
  } catch (error) {
    return res.status(400).json({ status: "Error", message: error.message });
  }
}

async function demoteParticipants(req, res) {
  if (!ensureWaha(res)) return;
  const { groupId } = req.params;
  const { participants } = req.body;
  try {
    const result = await waha.demoteParticipants({ session: req.query.session, groupId, participants });
    return handleServiceResponse(res, result);
  } catch (error) {
    return res.status(400).json({ status: "Error", message: error.message });
  }
}

async function getInviteCode(req, res) {
  if (!ensureWaha(res)) return;
  const { groupId } = req.params;
  const result = await waha.getInviteCode({ session: req.query.session, groupId });
  return handleServiceResponse(res, result);
}

async function revokeInviteCode(req, res) {
  if (!ensureWaha(res)) return;
  const { groupId } = req.params;
  const result = await waha.revokeInviteCode({ session: req.query.session, groupId });
  return handleServiceResponse(res, result, 204);
}

async function joinGroup(req, res) {
  if (!ensureWaha(res)) return;
  const { inviteCode } = req.body;
  try {
    const result = await waha.joinGroup({ session: req.query.session, inviteCode });
    return handleServiceResponse(res, result, 201);
  } catch (error) {
    return res.status(400).json({ status: "Error", message: error.message });
  }
}

module.exports = {
  listGroups,
  getGroup,
  createGroup,
  updateSubject,
  updateDescription,
  addParticipants,
  removeParticipants,
  promoteParticipants,
  demoteParticipants,
  getInviteCode,
  revokeInviteCode,
  joinGroup,
};
