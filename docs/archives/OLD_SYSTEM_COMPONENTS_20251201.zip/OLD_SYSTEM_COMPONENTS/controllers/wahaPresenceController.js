const waha = require("../services/waha");
const { ensureWaha, handleServiceResponse } = require("./wahaUtils");

async function getPresence(req, res) {
  if (!ensureWaha(res)) return;
  const { chatId } = req.params;
  const result = await waha.getPresence({ session: req.query.session, chatId });
  return handleServiceResponse(res, result);
}

async function subscribePresence(req, res) {
  if (!ensureWaha(res)) return;
  const { chatId } = req.params;
  const result = await waha.subscribePresence({ session: req.query.session, chatId });
  return handleServiceResponse(res, result, 202);
}

async function unsubscribePresence(req, res) {
  if (!ensureWaha(res)) return;
  const { chatId } = req.params;
  const result = await waha.unsubscribePresence({ session: req.query.session, chatId });
  return handleServiceResponse(res, result, 202);
}

async function setPresence(req, res) {
  if (!ensureWaha(res)) return;
  const { chatId } = req.params;
  const { state } = req.body;
  try {
    const result = await waha.setPresence({ session: req.query.session, chatId, state });
    return handleServiceResponse(res, result);
  } catch (error) {
    return res.status(400).json({ status: "Error", message: error.message });
  }
}

module.exports = {
  getPresence,
  subscribePresence,
  unsubscribePresence,
  setPresence,
};
