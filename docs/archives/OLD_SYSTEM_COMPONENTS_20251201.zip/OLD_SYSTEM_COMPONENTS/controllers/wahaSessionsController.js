const waha = require("../services/waha");
const { ensureWaha, handleServiceResponse } = require("./wahaUtils");

async function listSessions(req, res) {
  if (!ensureWaha(res)) return;
  const { verbose } = req.query;
  const result = await waha.listSessions({ verbose: verbose === "true" });
  return handleServiceResponse(res, result);
}

async function getSession(req, res) {
  if (!ensureWaha(res)) return;
  const { session } = req.params;
  const { verbose } = req.query;
  const result = await waha.getSession({ session, verbose: verbose === "true" });
  return handleServiceResponse(res, result);
}

async function createSession(req, res) {
  if (!ensureWaha(res)) return;
  const { session, config, start = true } = req.body;
  try {
    const result = await waha.createSession({ session, config, start });
    return handleServiceResponse(res, result, 201);
  } catch (error) {
    return res.status(400).json({ status: "Error", message: error.message });
  }
}

async function restartSession(req, res) {
  if (!ensureWaha(res)) return;
  const { session } = req.params;
  const result = await waha.restartSession({ session });
  return handleServiceResponse(res, result, 202);
}

async function stopSession(req, res) {
  if (!ensureWaha(res)) return;
  const { session } = req.params;
  const result = await waha.stopSession({ session });
  return handleServiceResponse(res, result);
}

async function logoutSession(req, res) {
  if (!ensureWaha(res)) return;
  const { session } = req.params;
  const result = await waha.logoutSession({ session });
  return handleServiceResponse(res, result);
}

async function deleteSession(req, res) {
  if (!ensureWaha(res)) return;
  const { session } = req.params;
  const result = await waha.deleteSession({ session });
  return handleServiceResponse(res, result, 204);
}

async function getProfile(req, res) {
  if (!ensureWaha(res)) return;
  const { session } = req.params;
  const result = await waha.getSessionProfile({ session });
  return handleServiceResponse(res, result);
}

async function getMe(req, res) {
  if (!ensureWaha(res)) return;
  const { session } = req.params;
  const result = await waha.getSessionMe({ session });
  return handleServiceResponse(res, result);
}

async function getAuthCode(req, res) {
  if (!ensureWaha(res)) return;
  const { session } = req.params;
  const result = await waha.getAuthCode({ session });
  return handleServiceResponse(res, result);
}

module.exports = {
  listSessions,
  getSession,
  createSession,
  restartSession,
  stopSession,
  logoutSession,
  deleteSession,
  getProfile,
  getMe,
  getAuthCode,
};
