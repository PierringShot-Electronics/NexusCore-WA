const waha = require("../services/waha");
const { ensureWaha, handleServiceResponse } = require("./wahaUtils");

async function listChats(req, res) {
  if (!ensureWaha(res)) return;
  const { limit, cursor, overview } = req.query;
  const result = await waha.listChats({
    session: req.query.session,
    limit: limit ? Number(limit) : undefined,
    cursor,
    overview: overview === "true",
  });
  return handleServiceResponse(res, result);
}

async function getChat(req, res) {
  if (!ensureWaha(res)) return;
  const { chatId } = req.params;
  const result = await waha.getChat({ session: req.query.session, chatId });
  return handleServiceResponse(res, result);
}

async function getChatMessages(req, res) {
  if (!ensureWaha(res)) return;
  const { chatId } = req.params;
  const { limit, cursor, withMedia } = req.query;
  const result = await waha.getChatMessages({
    session: req.query.session,
    chatId,
    limit: limit ? Number(limit) : undefined,
    cursor,
    withMedia: withMedia === "true",
  });
  return handleServiceResponse(res, result);
}

async function deleteChat(req, res) {
  if (!ensureWaha(res)) return;
  const { chatId } = req.params;
  const result = await waha.deleteChat({ session: req.query.session, chatId });
  return handleServiceResponse(res, result, 204);
}

async function clearChat(req, res) {
  if (!ensureWaha(res)) return;
  const { chatId } = req.params;
  const result = await waha.clearChat({ session: req.query.session, chatId });
  return handleServiceResponse(res, result, 204);
}

async function deleteMessage(req, res) {
  if (!ensureWaha(res)) return;
  const { chatId, messageId } = req.params;
  const { forEveryone = true } = req.body || {};
  const result = await waha.deleteMessage({ session: req.query.session, chatId, messageId, forEveryone });
  return handleServiceResponse(res, result, 204);
}

async function editMessage(req, res) {
  if (!ensureWaha(res)) return;
  const { chatId, messageId } = req.params;
  const { text } = req.body;
  try {
    const result = await waha.editMessage({ session: req.query.session, chatId, messageId, text });
    return handleServiceResponse(res, result);
  } catch (error) {
    return res.status(400).json({ status: "Error", message: error.message });
  }
}

async function markRead(req, res) {
  if (!ensureWaha(res)) return;
  const { chatId } = req.params;
  const { messageId } = req.body || {};
  const result = await waha.markChatRead({ session: req.query.session, chatId, messageId });
  return handleServiceResponse(res, result);
}

async function markUnread(req, res) {
  if (!ensureWaha(res)) return;
  const { chatId } = req.params;
  const result = await waha.markChatUnread({ session: req.query.session, chatId });
  return handleServiceResponse(res, result);
}

async function archiveChat(req, res) {
  if (!ensureWaha(res)) return;
  const { chatId } = req.params;
  const result = await waha.archiveChat({ session: req.query.session, chatId });
  return handleServiceResponse(res, result);
}

async function unarchiveChat(req, res) {
  if (!ensureWaha(res)) return;
  const { chatId } = req.params;
  const result = await waha.unarchiveChat({ session: req.query.session, chatId });
  return handleServiceResponse(res, result);
}

async function pinMessage(req, res) {
  if (!ensureWaha(res)) return;
  const { chatId, messageId } = req.params;
  const result = await waha.pinMessage({ session: req.query.session, chatId, messageId });
  return handleServiceResponse(res, result);
}

async function unpinMessage(req, res) {
  if (!ensureWaha(res)) return;
  const { chatId, messageId } = req.params;
  const result = await waha.unpinMessage({ session: req.query.session, chatId, messageId });
  return handleServiceResponse(res, result);
}

module.exports = {
  listChats,
  getChat,
  getChatMessages,
  deleteChat,
  clearChat,
  deleteMessage,
  editMessage,
  markRead,
  markUnread,
  archiveChat,
  unarchiveChat,
  pinMessage,
  unpinMessage,
};
