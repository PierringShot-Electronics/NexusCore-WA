const crypto = require("crypto");
const { greetingQuickReply, buildAwayMessageText, DEFAULT_TIMEZONE } = require("../../prompts/customerExperience");
const { getContact, upsertContact } = require("../memory/contactMemory");
const { logWithTimestamp } = require("../../utils/logger");

const DAY_ORDER = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const WEEKDAY_LABELS = {
  Sun: "Bazar",
  Mon: "Bazar ertəsi",
  Tue: "Çərşənbə axşamı",
  Wed: "Çərşənbə",
  Thu: "Cümə axşamı",
  Fri: "Cümə",
  Sat: "Şənbə",
};

const AWAY_COOLDOWN_HOURS = Number(process.env.AWAY_MESSAGE_COOLDOWN_HOURS || 6);

function getAzContext(now = new Date()) {
  const formatter = new Intl.DateTimeFormat("en-US", {
    timeZone: DEFAULT_TIMEZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
    weekday: "short",
  });
  const parts = formatter.formatToParts(now).reduce((acc, part) => {
    if (part.type !== "literal") {
      acc[part.type] = part.value;
    }
    return acc;
  }, {});

  const hour = Number(parts.hour || "0");
  const minute = Number(parts.minute || "0");
  return {
    weekday: parts.weekday || "Mon",
    hour,
    minute,
    isoDate: `${parts.year}-${parts.month}-${parts.day}`,
    timeLabel: `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`,
    now,
  };
}

function isWithinSupportWindow({ weekday, hour }) {
  const index = DAY_ORDER.indexOf(weekday);
  const isWeekday = index >= 1 && index <= 5;
  return isWeekday && hour >= 9 && hour < 21;
}

function computeNextWindowLabel({ weekday }) {
  let index = DAY_ORDER.indexOf(weekday);
  if (index === -1) index = 1;

  let nextIndex = index;
  for (let i = 0; i < 7; i += 1) {
    nextIndex = (nextIndex + 1) % DAY_ORDER.length;
    if (nextIndex >= 1 && nextIndex <= 5) {
      const label = WEEKDAY_LABELS[DAY_ORDER[nextIndex]] || "növbəti iş günü";
      return `${label} 09:00`;
    }
  }
  return "növbəti iş günündə 09:00";
}

function shouldSendAway(autoResponses = {}, azContext, now) {
  if (isWithinSupportWindow(azContext)) {
    return false;
  }
  const last = autoResponses.lastAwayMessageAt;
  if (!last) {
    return true;
  }
  const diffMs = now.getTime() - new Date(last).getTime();
  return diffMs > AWAY_COOLDOWN_HOURS * 60 * 60 * 1000;
}

async function prepareAutoReplies({ chatId, now = new Date() }) {
  try {
    const contact = await getContact(chatId);
    const autoResponses = contact?.autoResponses || {};
    const responses = [];
    const updates = { autoResponses: { ...autoResponses } };
    const isoNow = now.toISOString();

    const azContext = getAzContext(now);
    const nextWindowLabel = computeNextWindowLabel(azContext);

    let greetingText = null;
    let awayText = null;

    if (!autoResponses.greetingSentAt) {
      greetingText = greetingQuickReply;
      updates.autoResponses.greetingSentAt = isoNow;
    }

    const canSendAway = shouldSendAway(autoResponses, azContext, now);

    if (canSendAway) {
      awayText = buildAwayMessageText({
        timeLabel: azContext.timeLabel,
        nextWindowLabel,
      });
      updates.autoResponses.lastAwayMessageAt = isoNow;
    }

    if (greetingText && awayText) {
      responses.push({
        type: "greeting-away",
        text: `${greetingText}\n\n${awayText}`,
      });
    } else {
      if (greetingText) {
        responses.push({ type: "greeting", text: greetingText });
      }
      if (awayText) {
        responses.push({ type: "away", text: awayText });
      }
    }

    if (responses.length > 0) {
      const signature = crypto
        .createHash("sha1")
        .update(responses.map((entry) => entry.text).join("||"))
        .digest("hex");

      const hasAwayResponse = responses.some(
        (entry) => entry.type === "away" || entry.type === "greeting-away",
      );
      const bypassSignature = hasAwayResponse && canSendAway;

      if (!bypassSignature && autoResponses.lastSignature === signature) {
        responses.length = 0;
      } else {
        updates.autoResponses.lastSignature = signature;
      }
    }

    if (responses.length > 0) {
      updates.autoResponses.lastEvaluatedAt = isoNow;
      await upsertContact(chatId, updates);
    }

    return responses;
  } catch (error) {
    logWithTimestamp("⚠️ Auto-response hazırlamaq mümkün olmadı:", error.message);
    return [];
  }
}

module.exports = {
  prepareAutoReplies,
  getAzContext,
};
