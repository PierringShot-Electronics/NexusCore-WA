/**
 * WhatsCore.AI - Maverick Edition
 *
 * Məhsul Meneceri (Product Manager) - v4.6.0
 * CSV və JSON mənbələrindən oxuyur, axtarış və siyahılama funksiyaları təqdim edir.
 */
const fs = require('fs');
const path = require('path');
const { parse } = require('csv-parse/sync');
const { logWithTimestamp } = require('../utils/logger');

const DATA_DIR = path.join(__dirname, '..', 'data');
const PRODUCTS_CSV_PATH = path.join(DATA_DIR, 'products.csv');
const PRODUCTS_JSON_PATH = path.join(DATA_DIR, 'products.json');

let products = [];

function toNumber(value) {
  if (value === undefined || value === null || value === '') return 0;
  const numeric = Number(value);
  return Number.isFinite(numeric) ? numeric : 0;
}

function loadProductsFromCsv() {
  if (!fs.existsSync(PRODUCTS_CSV_PATH)) {
    return [];
  }
  try {
    const fileContent = fs.readFileSync(PRODUCTS_CSV_PATH);
    const parsed = parse(fileContent, {
      columns: true,
      skip_empty_lines: true,
      trim: true,
    });
    const normalized = parsed.map((product) => ({
      ...product,
      price: toNumber(product.price),
      stock: toNumber(product.stock),
    }));
    logWithTimestamp(`✅ ${normalized.length} məhsul CSV verilənlər bazasından uğurla yükləndi.`);
    return normalized;
  } catch (error) {
    logWithTimestamp('❌ Məhsulları CSV-dən oxumaq mümkün olmadı:', error);
    return [];
  }
}

function loadProductsFromJson() {
  if (!fs.existsSync(PRODUCTS_JSON_PATH)) {
    return [];
  }
  try {
    const raw = fs.readFileSync(PRODUCTS_JSON_PATH, 'utf8').trim();
    if (!raw) {
      return [];
    }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) {
      logWithTimestamp('⚠️ products.json gözlənilən massiv formatında deyil.');
      return [];
    }
    const normalized = parsed.map((product) => ({
      ...product,
      price: toNumber(product.price ?? product.unitPrice),
      stock: toNumber(product.stock ?? product.quantity),
    }));
    logWithTimestamp(`✅ ${normalized.length} məhsul JSON verilənlər bazasından yükləndi.`);
    return normalized;
  } catch (error) {
    logWithTimestamp('❌ Məhsulları JSON-dan oxumaq mümkün olmadı:', error);
    return [];
  }
}

function loadProducts() {
  const csvProducts = loadProductsFromCsv();
  if (csvProducts.length > 0) {
    return csvProducts;
  }
  const jsonProducts = loadProductsFromJson();
  if (jsonProducts.length > 0) {
    return jsonProducts;
  }
  logWithTimestamp('⚠️ Aktiv məhsul verilənlər bazası tapılmadı. Boş massiv qaytarılır.');
  return [];
}

products = loadProducts();

/**
 * Məhsulları açar sözlərə görə axtarır.
 * @param {string} query - Axtarış üçün istifadəçi sorğusu və ya məhsul ID-si.
 * @returns {Array} - Tapılan məhsulların massivi.
 */
function searchProducts(query) {
  if (!query) return [];

  const lowerCaseQuery = query.toLowerCase().trim();

  // İlk olaraq dəqiq ID ilə axtarış
  const byId = products.find((p) => p.id && p.id.toLowerCase() === lowerCaseQuery);
  if (byId) return [byId];

  // Sonra ad və təsvirdə axtarış
  const searchTerms = lowerCaseQuery.split(/\s+/).filter((term) => term.length > 2);
  if (searchTerms.length === 0) return [];

  return products.filter((product) => {
    const productName = (product.name || '').toLowerCase();
    const productDescription = (product.description || '').toLowerCase();
    const productCategory = (product.category || '').toLowerCase();

    // Bütün axtarış sözləri məhsul məlumatlarında mövcud olmalıdır
    return searchTerms.every(
      (term) =>
        productName.includes(term) ||
        productDescription.includes(term) ||
        productCategory.includes(term)
    );
  });
}

function getProducts() {
  return products.map((product) => ({ ...product }));
}

function refreshProducts() {
  products = loadProducts();
  return getProducts();
}

module.exports = {
  searchProducts,
  getProducts,
  refreshProducts,
  products,
};
