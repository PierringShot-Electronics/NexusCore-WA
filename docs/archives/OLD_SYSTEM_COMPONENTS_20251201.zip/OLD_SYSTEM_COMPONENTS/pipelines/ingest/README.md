# KB Ingest Pipeline

This folder will host scripts that convert raw CSV/YAML assets under `kb/` and `intent/` into runtime JSON stored in `data/generated/`.

## Planned steps
1. Validate schema (headers + types)
2. Normalize pricing fields (AZN conversions)
3. Emit `data/generated/services.json`, `products.json`, `faq.json`
4. Optionally push to a vector index / Postgres table
