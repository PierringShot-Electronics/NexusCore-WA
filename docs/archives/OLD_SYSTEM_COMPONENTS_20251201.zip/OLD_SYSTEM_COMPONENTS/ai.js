const path = require("path");
const mime = require("mime-types");
const { getGroqProvider } = require("./models/groqProvider");
const { getHistory } = require("./historyManager");
const { detectIntent } = require("./orchestrator/intentRouter");
const { buildPlan } = require("./orchestrator/planBuilder");
const { executePlan } = require("./orchestrator/planExecutor");
const { gatherCatalogMatches } = require("./toolkit/knowledgeBase");
const { runSearch } = require("./toolkit/webSearch");
const { logWithTimestamp } = require("../utils/logger");
const { getSystemPrompt } = require("../prompts/assistant_prompt");
const {
  getCustomerExperienceReference,
} = require("../prompts/customerExperience");
const { getGateStatus } = require("./orchestrator/automationState");

const DEFAULT_HISTORY_LIMIT = parseInt(
  process.env.MAX_HISTORY_MESSAGES || "12",
  10,
);
const DEFAULT_USER_CHAR_LIMIT = parseInt(
  process.env.MAX_USER_MESSAGE_CHARS || "2000",
  10,
);
const RESPONSE_TOKEN_LIMIT = parseInt(process.env.GROQ_MAX_TOKENS || "420", 10);
const MIN_USER_CHAR_LIMIT = 600;
const MIN_HISTORY_LIMIT = 6;

async function analyzeMediaInputs(media = []) {
  if (!Array.isArray(media) || media.length === 0) {
    return { analysis: "", transcriptions: [] };
  }

  const provider = getGroqProvider();
  const analysisLines = [];
  const transcriptions = [];

  for (const item of media) {
    const mimeType =
      item.mimeType ||
      mime.lookup(item.path || "") ||
      "application/octet-stream";
    if (mimeType.startsWith("image")) {
      try {
        const response = await provider.multimodalCompletion({
          prompt:
            "Bu şəkili təhlil et: nəyi göstərir, zədələnmə və ya komponent tap, qiymətə təsir edən nöqtələri qeyd et.",
          media: [item],
          maxTokens: 280,
        });
        const content = response.choices?.[0]?.message?.content?.trim();
        if (content) {
          analysisLines.push(`(PHOTO) ${content}`);
        }
      } catch (error) {
        logWithTimestamp("⚠️ Şəkil analizi uğursuz oldu:", error.message);
      }
    } else if (mimeType.startsWith("audio")) {
      try {
        const result = await provider.transcribeAudio(item.path, {
          language: "az",
          temperature: 0.1,
        });
        const text = result.text || result.transcript || "";
        if (text) {
          transcriptions.push(text.trim());
          analysisLines.push(`(AUDIO) Səs transkripsiyası: ${text.trim()}`);
        }
      } catch (error) {
        logWithTimestamp(
          "⚠️ Audio transkripsiyası uğursuz oldu:",
          error.message,
        );
      }
    } else if (mimeType.startsWith("video")) {
      try {
        const response = await provider.multimodalCompletion({
          prompt:
            "Video kadrını təsvir et və müştərinin nə göstərmək istədiyini yekunlaşdır.",
          media: [item],
          maxTokens: 300,
        });
        const content = response.choices?.[0]?.message?.content?.trim();
        if (content) {
          analysisLines.push(`(VIDEO) ${content}`);
        }
      } catch (error) {
        logWithTimestamp("⚠️ Video analizi uğursuz oldu:", error.message);
      }
    } else {
      analysisLines.push(
        `(MEDIA) ${mimeType} formatlı fayl alındı; əlavə emal tələb etmir.`,
      );
    }
  }

  return {
    analysis: analysisLines.join("\n"),
    transcriptions,
  };
}

function shouldTriggerWebSearch(text, catalogMatches) {
  const lowered = (text || "").toLowerCase();
  const needsExplicitResearch =
    /(internet|web|google|araşdır|tap|yenilənmiş)|real vaxt|ən son/.test(
      lowered,
    );
  const catalogEmpty = !catalogMatches?.summary;
  return needsExplicitResearch || (catalogEmpty && lowered.length > 0);
}

function trimUserInput(text, limit) {
  if (!text) return { text: "", trimmed: false };
  if (text.length <= limit) return { text, trimmed: false };
  return { text: text.slice(-limit), trimmed: true };
}

async function buildMessages({
  history,
  systemPrompt,
  combinedUserInput,
  intentInfo,
  planOutcome,
  mediaAnalysis,
  userTrimmed,
}) {
  const messages = [];
  messages.push({ role: "system", content: systemPrompt });

  const contextBlocks = [];
  if (planOutcome?.contactProfile) {
    const contact = planOutcome.contactProfile;
    contextBlocks.push(
      `[KONTAKT MƏLUMATI]\nAd: ${contact.name || "bilinmir"}\nBiznes: ${
        contact.businessName || "-"
      }\nLead etiketi: ${(contact.labels || []).join(", ") || "yoxdur"}`,
    );
  }

  if (Array.isArray(planOutcome?.leads) && planOutcome.leads.length > 0) {
    const leadLines = planOutcome.leads
      .slice(0, 3)
      .map(
        (lead) =>
          `- #${lead.leadId || "?"} | Status: ${lead.status || "open"} | Dəyər: ${
            lead.valueEstimate !== null && lead.valueEstimate !== undefined
              ? `${lead.valueEstimate}₼`
              : "b.e."
          }${lead.notes ? ` | QEYD: ${lead.notes}` : ""}`,
      )
      .join("\n");
    contextBlocks.push(`[LEAD LEDGER]\n${leadLines}`);
  }

  if (planOutcome?.memorySummary) {
    contextBlocks.push(`[SOHBƏT XÜLASƏSİ]\n${planOutcome.memorySummary}`);
  }

  if (planOutcome?.knowledgeBlock) {
    contextBlocks.push(planOutcome.knowledgeBlock);
  }

  if (planOutcome?.webBlock) {
    contextBlocks.push(planOutcome.webBlock);
  }

  if (mediaAnalysis) {
    contextBlocks.push(`[MEDİA ANALİZİ]\n${mediaAnalysis}`);
  }

  if (planOutcome?.events) {
    const steps = planOutcome.events
      .map(
        (event) =>
          `- ${event.step}: ${event.status}${event.reason ? ` (${event.reason})` : ""}`,
      )
      .join("\n");
    contextBlocks.push(`[ORKESTRATOR JURNALI]\n${steps}`);
  }

  if (planOutcome?.toolTrace) {
    const trace =
      planOutcome.toolTrace.length > 1400
        ? `${planOutcome.toolTrace.slice(0, 1400)}…`
        : planOutcome.toolTrace;
    contextBlocks.push(`[TOOL TRACE]\n${trace}`);
  }

  contextBlocks.push(getCustomerExperienceReference());

  if (contextBlocks.length > 0) {
    messages.push({
      role: "system",
      content: contextBlocks.join("\n\n"),
    });
  }

  for (const item of history) {
    messages.push({
      role: item.sender === "assistant" ? "assistant" : "user",
      content: item.content,
    });
  }

  const notice = userTrimmed
    ? `\n\n[QISALDILMIŞ QEYD]: İstifadəçi mətni token limitinə görə son ${combinedUserInput.length} simvol ilə məhdudlaşdırıldı.`
    : "";

  messages.push({
    role: "user",
    content: `NİYYƏT: ${intentInfo.intent} (${intentInfo.source}, etibarlılıq ${(
      intentInfo.confidence || 0
    ).toFixed(2)})\n\nISTIFADEÇI SORĞUSU:\n${combinedUserInput}${notice}`,
  });

  return messages;
}

async function getAIResponse(chatId, userInput) {
  const gateStatus = getGateStatus();
  if (gateStatus.blocked) {
    logWithTimestamp(
      `ℹ️ AI cavablandırması bloklandı (${gateStatus.source}: ${gateStatus.message}).`,
    );
    const fallback =
      (process.env.AUTOMATION_PAUSED_REPLY &&
        process.env.AUTOMATION_PAUSED_REPLY.trim()) ||
      "🤖 Sistem texniki xidmət rejimindədir, tezliklə cavab verəcəyik.";
    return fallback;
  }

  const provider = getGroqProvider();
  let historyLimit = Number.isNaN(DEFAULT_HISTORY_LIMIT)
    ? 10
    : DEFAULT_HISTORY_LIMIT;
  let userCharLimit = Number.isNaN(DEFAULT_USER_CHAR_LIMIT)
    ? 1800
    : DEFAULT_USER_CHAR_LIMIT;

  let history = await getHistory(chatId);
  if (history.length > historyLimit) {
    history = history.slice(-historyLimit);
    logWithTimestamp(
      `ℹ️ ${chatId} üçün tarixçə ${historyLimit} mesaja qədər qısaldıldı.`,
    );
  }

  const media = Array.isArray(userInput.media) ? userInput.media : [];
  const { analysis: mediaAnalysis, transcriptions } =
    await analyzeMediaInputs(media);

  let combinedUserInput = userInput.text || "";
  if (transcriptions.length > 0) {
    combinedUserInput = `${combinedUserInput} ${transcriptions
      .map((t) => `[Səs transkripsiyası]: ${t}`)
      .join(" ")}`.trim();
  }

  const { text: trimmedInput, trimmed } = trimUserInput(
    combinedUserInput,
    Math.max(userCharLimit, MIN_USER_CHAR_LIMIT),
  );
  combinedUserInput = trimmedInput;

  const catalogMatches = gatherCatalogMatches(combinedUserInput);
  const requiresWebSearch = shouldTriggerWebSearch(
    combinedUserInput,
    catalogMatches,
  );

  const intentInfo = await detectIntent({
    text: combinedUserInput,
    knowledgeSummary: catalogMatches.summary,
    historySummary: history
      .slice(-3)
      .map((msg) => `${msg.sender}: ${msg.content}`)
      .join(" | "),
  });

  const plan = buildPlan({
    intent: intentInfo.intent,
    catalogMatches,
    requiresWebSearch,
    chatId,
  });
  const planOutcome = await executePlan(plan, {
    chatId,
    history,
    userText: combinedUserInput,
  });

  const messages = await buildMessages({
    history,
    systemPrompt: getSystemPrompt(intentInfo.intent),
    combinedUserInput,
    intentInfo,
    planOutcome,
    mediaAnalysis,
    userTrimmed: trimmed,
  });

  const chatModel = process.env.GROQ_CHAT_MODEL || "llama-3.3-70b-versatile";
  const temperature = Number(process.env.GROQ_TEMPERATURE || 0.23);
  const tools = buildToolset(chatModel);

  try {
    const { content } = await runChatCompletionWithTools(
      provider,
      {
        model: chatModel,
        messages,
        max_tokens: RESPONSE_TOKEN_LIMIT,
        temperature,
      },
      { tools },
    );

    if (content) {
      return content;
    }

    return "🤖 Hazırda cavab formalaşdırmaq alınmadı. Zəhmət olmasa sualınızı yenidən göndərin.";
  } catch (error) {
    logWithTimestamp(`❌ Groq cavabı alınmadı:`, error.message || error);

    if (error.status === 413 && historyLimit > MIN_HISTORY_LIMIT) {
      historyLimit = Math.max(
        MIN_HISTORY_LIMIT,
        Math.floor(historyLimit * 0.7),
      );
      userCharLimit = Math.max(
        MIN_USER_CHAR_LIMIT,
        Math.floor(userCharLimit * 0.8),
      );
      logWithTimestamp(
        `⚠️ Token limiti aşılır, yeni limitlər: history=${historyLimit}, chars=${userCharLimit}.`,
      );
      return getAIResponse(chatId, userInput);
    }

    return "🤖 Üzr istəyirəm, AI ilə əlaqədə naməlum bir problem yarandı.";
  }
}

module.exports = { getAIResponse };

function buildToolset(model) {
  const explicit = process.env.GROQ_ENABLE_BROWSER_TOOL;
  const enableBrowserTool = explicit
    ? explicit.toLowerCase() === "true"
    : (model || "").toLowerCase().includes("gpt-oss-20b");

  const functionMode = (
    process.env.GROQ_FUNCTION_TOOL_MODE || "auto"
  ).toLowerCase();
  const enableFunctionTool =
    functionMode === "enable" || (functionMode === "auto" && enableBrowserTool);

  const tools = [];
  if (enableBrowserTool) {
    tools.push({ type: "browser_search" });
  }

  if (enableFunctionTool) {
    tools.push({
      type: "function",
      function: {
        name: "web_search",
        description: "Real vaxt məlumatlarını tapmaq üçün veb axtarışı apar.",
        parameters: {
          type: "object",
          properties: {
            query: {
              type: "string",
              description: "Axtarılacaq sorğu cümləsi.",
            },
          },
          required: ["query"],
        },
      },
    });
  }

  return tools;
}

async function runChatCompletionWithTools(
  provider,
  basePayload,
  { tools = [] } = {},
) {
  const maxToolCalls = Math.max(
    parseInt(process.env.GROQ_MAX_TOOL_CALLS || "2", 10),
    0,
  );
  const conversation = basePayload.messages.map((msg) => ({ ...msg }));
  let iterations = 0;

  // eslint-disable-next-line no-constant-condition
  while (true) {
    const requestPayload = {
      ...basePayload,
      messages: conversation,
    };

    if (tools.length > 0) {
      requestPayload.tools = tools;
    }

    const response = await provider.chatCompletion(requestPayload, {
      maxTokens: basePayload.max_tokens,
      temperature: basePayload.temperature,
    });

    const choice = response.choices?.[0];
    const assistantMessage = choice?.message;

    if (!assistantMessage) {
      return { content: null, response };
    }

    const toolCalls = assistantMessage.tool_calls || [];
    const trimmedContent =
      typeof assistantMessage.content === "string"
        ? assistantMessage.content.trim()
        : "";

    if (toolCalls.length === 0 || iterations >= maxToolCalls) {
      return { content: trimmedContent || null, response };
    }

    conversation.push({
      role: "assistant",
      content: trimmedContent,
      tool_calls: toolCalls,
    });

    let handledTool = false;

    for (const call of toolCalls) {
      if (call.type === "function" && call.function?.name === "web_search") {
        handledTool = true;
        let args = {};
        try {
          args = JSON.parse(call.function.arguments || "{}");
        } catch (error) {
          logWithTimestamp(
            "⚠️ web_search tool argumentləri parse olunmadı:",
            error.message,
          );
        }

        const query = args.query || args.prompt || args.text || args.q || "";
        const searchResult = await runSearch(query);
        const toolPayload = searchResult.ok
          ? {
              ok: true,
              summary: searchResult.summary || "",
              sources: searchResult.sources || [],
            }
          : { ok: false, reason: searchResult.reason || "Search failed" };

        conversation.push({
          role: "tool",
          tool_call_id: call.id,
          name: call.function.name,
          content: JSON.stringify(toolPayload),
        });
      } else {
        logWithTimestamp(
          "⚠️ Dəstəklənməyən tool call aşkarlandı:",
          JSON.stringify(call),
        );
      }
    }

    if (!handledTool) {
      return { content: trimmedContent || null, response };
    }

    iterations += 1;
  }
}
