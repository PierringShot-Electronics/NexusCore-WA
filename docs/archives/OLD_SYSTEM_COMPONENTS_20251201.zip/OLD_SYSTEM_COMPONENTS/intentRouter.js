const fs = require("fs");
const path = require("path");
const YAML = require("yaml");
const { logWithTimestamp } = require("../utils/logger");

const MAP_PATH = path.join(__dirname, "..", "intent", "map.yaml");
const DEFAULT_CONFIG = {
  intents: [],
  fallback: {
    default_intent: "customer_support",
    clarify_threshold: 0.35,
  },
};

let cachedConfig = null;
let cachedMtimeMs = 0;

function loadIntentMap() {
  try {
    const stats = fs.statSync(MAP_PATH);
    if (cachedConfig && cachedMtimeMs === stats.mtimeMs) {
      return cachedConfig;
    }
    const yamlText = fs.readFileSync(MAP_PATH, "utf8");
    const parsed = YAML.parse(yamlText) || {};
    cachedConfig = {
      ...DEFAULT_CONFIG,
      ...parsed,
      fallback: {
        ...DEFAULT_CONFIG.fallback,
        ...(parsed.fallback || {}),
      },
    };
    cachedMtimeMs = stats.mtimeMs;
    return cachedConfig;
  } catch (error) {
    logWithTimestamp(
      "⚠️ intent/map.yaml yüklənə bilmədi, default config istifadə olunur:",
      error.message,
    );
    cachedConfig = DEFAULT_CONFIG;
    cachedMtimeMs = Date.now();
    return cachedConfig;
  }
}

function tokenize(text) {
  return (text || "")
    .toLowerCase()
    .split(/[^a-zəöğüçıər0-9]+/i)
    .filter(Boolean);
}

function scoreIntent(utteranceTokens, intent) {
  if (!intent || !Array.isArray(intent.examples)) return 0;
  let bestScore = 0;
  for (const example of intent.examples) {
    const exampleTokens = tokenize(example);
    if (exampleTokens.length === 0) continue;
    const matches = exampleTokens.filter((token) =>
      utteranceTokens.includes(token),
    ).length;
    if (matches === 0) continue;
    const ratio = matches / exampleTokens.length;
    if (ratio > bestScore) {
      bestScore = ratio;
    }
  }
  const confidenceBias =
    typeof intent.confidence === "number" ? intent.confidence : 0.5;
  return Number((bestScore * confidenceBias).toFixed(3));
}

function buildClarifyingPrompt(topGuesses = []) {
  if (!topGuesses.length) {
    return "Dəqiq yardım edə bilmək üçün xahiş edirik nəyə ehtiyacınız olduğunu bir az daha izah edin. 😊";
  }
  const options = topGuesses
    .slice(0, 3)
    .map((item) => item.id.replace(/_/g, " "))
    .join(", ");
  return `Dəqiq yardım üçün təsdiqləyin: ${options} mövzusunda danışırsınız, yoxsa başqa bir mövzu?`;
}

function routeIntent(text, meta = {}) {
  const config = loadIntentMap();
  const utteranceTokens = tokenize(text);
  const scores = (config.intents || []).map((intent) => ({
    id: intent.id,
    handler: intent.handler,
    score: scoreIntent(utteranceTokens, intent),
  }));

  scores.sort((a, b) => b.score - a.score);
  const best = scores[0];
  const clarifyThreshold =
    typeof config.fallback?.clarify_threshold === "number"
      ? config.fallback.clarify_threshold
      : DEFAULT_CONFIG.fallback.clarify_threshold;

  const requiresClarification = !best || best.score < clarifyThreshold;
  const resolvedIntent =
    (!requiresClarification && best?.id) ||
    config.fallback?.default_intent ||
    DEFAULT_CONFIG.fallback.default_intent;

  return {
    intent: resolvedIntent,
    handler: best?.handler || null,
    score: best?.score || 0,
    requiresClarification,
    clarificationPrompt: requiresClarification
      ? buildClarifyingPrompt(scores)
      : null,
    metadata: {
      scores,
      chatId: meta.chatId,
    },
  };
}

function resetIntentCache() {
  cachedConfig = null;
  cachedMtimeMs = 0;
}

module.exports = {
  routeIntent,
  loadIntentMap,
  resetIntentCache,
};
