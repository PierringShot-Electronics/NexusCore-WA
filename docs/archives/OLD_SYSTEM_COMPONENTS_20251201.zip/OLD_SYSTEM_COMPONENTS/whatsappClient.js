const { Client, LocalAuth } = require("whatsapp-web.js");
const qrcode = require("qrcode-terminal");
const QRCode = require("qrcode");
const fs = require("fs");
const path = require("path");
const { handleMessage } = require("../controllers/messageController");
const { logWithTimestamp } = require("../utils/logger");
const { resolvePuppeteerExecutable } = require("../utils/puppeteerPath");

async function initializeWhatsAppClient() {
  logWithTimestamp("🔄 WhatsApp klienti başladılır...");
  const executablePath = resolvePuppeteerExecutable();
  logWithTimestamp(`🧭 Chromium yolu tapıldı: ${executablePath}`);

  // --- WhatsApp Client-in qurulması ---
  const client = new Client({
    authStrategy: new LocalAuth({
      clientId: process.env.SESSION_CLIENT_ID,
      dataPath: "./.wwebjs_auth",
    }),
    puppeteer: {
      headless: true,
      executablePath,
      args: [
        "--no-sandbox",
        "--disable-setuid-sandbox",
        "--disable-dev-shm-usage",
        "--disable-accelerated-2d-canvas",
        "--no-first-run",
        "--no-zygote",
        "--disable-gpu",
        "--disable-dbus",
      ],
    },
  });

  client.on("qr", async (qr) => {
    logWithTimestamp("⚡ whatsapp-web.js QR kodu yeniləndi. Telefonda skan edin.");
    const tmpDir = path.resolve(process.cwd(), "tmp");
    await fs.promises.mkdir(tmpDir, { recursive: true });

    const asciiPath = path.join(tmpDir, "wwebjs-qr.txt");
    qrcode.generate(qr, { small: true }, (ascii) => {
      console.log(ascii);
      fs.promises
        .writeFile(asciiPath, ascii)
        .catch((error) =>
          logWithTimestamp(`⚠️ wwebjs QR ASCII yazılmadı: ${error.message}`),
        );
    });

    const pngPath = path.join(tmpDir, "wwebjs-qr.png");
    try {
      await QRCode.toFile(pngPath, qr, { width: 512 });
      logWithTimestamp(`🖼️ whatsapp-web.js QR faylı: ${pngPath}`);
    } catch (error) {
      logWithTimestamp(`⚠️ wwebjs QR PNG yaradılmadı: ${error.message}`);
    }
  });

  client.on("ready", () => {
    logWithTimestamp("====================================================");
    logWithTimestamp(
      "🚀 WhatsApp Asistanı Tam Hazırdır və Mesajları Gözləyir!",
    );
    logWithTimestamp("====================================================");
    client.pupPage
      .evaluate(() => typeof window !== "undefined" && window.WWebJS)
      .catch((error) =>
        logWithTimestamp(
          `⚠️ whatsapp-web.js inject yoxlaması uğursuz oldu: ${error.message}`,
        ),
      );
  });

  client.on("authenticated", () => {
    logWithTimestamp("✅ Autentifikasiya uğurludur!");
  });

  client.on("message_create", async (message) => {
    // Statusları və öz mesajlarımızı ignor edirik
    if (message.fromMe || message.isStatus) {
      return;
    }
    logWithTimestamp(
      `📨 Yeni mesaj alındı: [${message.from}] | Tip: [${message.type}]`,
    );
    await handleMessage(client, message);
  });

  client.on("disconnected", (reason) => {
    logWithTimestamp(
      `❌ Klient bağlantını itirdi: ${reason}. Yenidən başlatmağa çalışın.`,
    );
  });

  await client.initialize();
  return client;
}

module.exports = { initializeWhatsAppClient };

//    const client = new Client({
//        authStrategy: new LocalAuth({
//            clientId: process.env.SESSION_CLIENT_ID,
//            dataPath: './wwebjs_auth'
//        }),
//        puppeteer: {
//            headless: true,
//            executablePath: process.env.PUPPETEER_EXECUTABLE_PATH,
//            args: [
//                '--no-sandbox',
//                '--disable-setuid-sandbox',
//                '--disable-dev-shm-usage',
//                '--disable-accelerated-2d-canvas',
//                '--no-first-run',
//                '--no-zygote',
//                '--disable-gpu'
//            ],
//        },
//    });
//
