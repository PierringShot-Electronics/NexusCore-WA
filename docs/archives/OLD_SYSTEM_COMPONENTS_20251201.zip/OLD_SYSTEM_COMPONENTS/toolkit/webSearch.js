const fetch = require("node-fetch");
const { logWithTimestamp } = require("../../utils/logger");

async function runTavily(query) {
  const apiKey = process.env.TAVILY_API_KEY || process.env.WEB_SEARCH_API_KEY;
  if (!apiKey) {
    return { ok: false, reason: "TAVILY_API_KEY təyin edilməyib." };
  }
  try {
    const response = await fetch("https://api.tavily.com/search", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Tavily-Api-Key": apiKey,
      },
      body: JSON.stringify({
        query,
        max_results: 5,
        include_answer: true,
        include_images: false,
        search_depth: "advanced",
      }),
    });
    const data = await response.json();
    if (!response.ok) {
      return { ok: false, reason: data?.error || "Tavily sorğusu uğursuz oldu." };
    }
    return {
      ok: true,
      provider: "tavily",
      summary: data?.answer || "",
      sources: Array.isArray(data?.results)
        ? data.results.map((item) => ({ title: item.title, url: item.url, snippet: item.content }))
        : [],
    };
  } catch (error) {
    logWithTimestamp("⚠️ Tavily sorğusu mümkün olmadı:", error.message);
    return { ok: false, reason: error.message };
  }
}

async function runSearch(query) {
  if (!query || !query.trim()) {
    return { ok: false, reason: "Axtarış sorğusu boşdur." };
  }

  if (process.env.DISABLE_WEB_SEARCH === "true") {
    return { ok: false, reason: "Web search deaktiv edilib." };
  }

  const handlers = [runTavily];
  for (const handler of handlers) {
    const result = await handler(query.trim());
    if (result.ok) {
      return result;
    }
  }
  return { ok: false, reason: "Heç bir web search təminatçısı konfiqurasiya edilməyib." };
}

function renderSearchBlock(result) {
  if (!result?.ok) {
    return `WEB AXTARIŞI: ${result?.reason || "Konfiqurasiya edilməyib."}`;
  }

  const lines = ["[WEB AXTARIŞI NƏTİCƏSİ]"];
  if (result.summary) {
    lines.push(`Xülasə: ${result.summary}`);
  }
  if (Array.isArray(result.sources) && result.sources.length > 0) {
    lines.push(
      ...result.sources.slice(0, 5).map((source, index) =>
        `${index + 1}. ${source.title} — ${source.url}${source.snippet ? `\n   ${source.snippet}` : ""}`,
      ),
    );
  }
  return lines.join("\n");
}

module.exports = {
  runSearch,
  renderSearchBlock,
};
