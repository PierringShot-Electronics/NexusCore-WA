const fetch = require("node-fetch");
const { URL } = require("url");
const { logWithTimestamp } = require("../../utils/logger");

const DEFAULT_TIMEOUT_MS = toInt(process.env.WAHA_TIMEOUT_MS, 15000);
const DEFAULT_RETRY_ATTEMPTS = Math.max(
  0,
  toInt(process.env.WAHA_RETRY_ATTEMPTS, 2),
);
const DEFAULT_RETRY_DELAY_MS = Math.max(
  0,
  toInt(process.env.WAHA_RETRY_DELAY_MS, 500),
);
const RETRYABLE_STATUS = new Set([408, 409, 425, 429, 500, 502, 503, 504]);

function toInt(value, fallback) {
  if (value === undefined || value === null || value === "") return fallback;
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function getConfig() {
  const baseUrl = process.env.WAHA_API_BASE || process.env.WAHA_BASE_URL;
  const apiKey = process.env.WAHA_API_KEY || process.env.WAHA_TOKEN;
  const session = process.env.WAHA_SESSION || process.env.WAHA_DEFAULT_SESSION;

  return { baseUrl, apiKey, session };
}

function buildUrl(pathname, query = {}) {
  const { baseUrl } = getConfig();
  if (!baseUrl) {
    throw new Error("WAHA_API_BASE təyin edilməyib.");
  }
  const base = baseUrl.endsWith("/") ? baseUrl : `${baseUrl}/`;
  const safePath = Array.isArray(pathname)
    ? pathname.filter(Boolean).join("/")
    : pathname;
  const url = new URL(String(safePath || "").replace(/^\//, ""), base);
  Object.entries(query || {}).forEach(([key, value]) => {
    if (value === undefined || value === null) return;
    if (value === "") return;
    url.searchParams.set(key, value);
  });
  return url.toString();
}
function buildHeaders(input = {}) {
  const headers = { ...input };
  const { apiKey } = getConfig();
  if (apiKey) {
    headers["X-Api-Key"] = headers["X-Api-Key"] || apiKey;
    if (!headers["Authorization"] && apiKey.startsWith("Bearer ")) {
      headers["Authorization"] = apiKey;
    }
  }
  return headers;
}

function isFormData(body) {
  if (!body || typeof body !== "object") return false;
  if (typeof body.getBoundary === "function") return true;
  if (typeof body.getHeaders === "function") return true;
  return false;
}

function isStreamBody(body) {
  return body && typeof body === "object" && typeof body.pipe === "function";
}

function prepareBody(body, headers) {
  if (body === undefined || body === null) return { body: undefined, headers };

  if (Buffer.isBuffer(body) || typeof body === "string" || body instanceof Uint8Array) {
    return { body, headers };
  }

  if (isFormData(body)) {
    const formHeaders = typeof body.getHeaders === "function" ? body.getHeaders() : {};
    return { body, headers: { ...headers, ...formHeaders } };
  }

  if (isStreamBody(body)) {
    return { body, headers };
  }

  if (body instanceof URLSearchParams) {
    const newHeaders = { ...headers };
    if (!newHeaders["Content-Type"]) {
      newHeaders["Content-Type"] = "application/x-www-form-urlencoded";
    }
    return { body, headers: newHeaders };
  }

  const newHeaders = { ...headers };
  if (!newHeaders["Content-Type"]) {
    newHeaders["Content-Type"] = "application/json";
  }
  return { body: JSON.stringify(body), headers: newHeaders };
}

function shouldRetry(result, attempt, maxAttempts) {
  if (!result) return false;
  if (result.ok) return false;
  if (attempt >= maxAttempts) return false;
  return RETRYABLE_STATUS.has(result.status || 0);
}

async function request({
  method = "GET",
  path,
  query,
  body,
  headers = {},
  timeoutMs = DEFAULT_TIMEOUT_MS,
  retry,
}) {
  if (!path) throw new Error("WAHA sorğusu üçün path tələb olunur.");
  if (!getConfig().baseUrl) {
    return {
      ok: false,
      status: 503,
      error: "WAHA inteqrasiyası deaktivdir — WAHA_API_BASE konfiqurasiya edilməyib.",
    };
  }

  const attempts = Math.max(0, retry ?? DEFAULT_RETRY_ATTEMPTS);
  let attempt = 0;
  let lastError;

  while (attempt <= attempts) {
    const url = buildUrl(path, query);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);

    try {
      const mergedHeaders = buildHeaders(headers);
      const { body: preparedBody, headers: finalHeaders } = prepareBody(
        body,
        mergedHeaders,
      );

      const options = {
        method,
        headers: finalHeaders,
        signal: controller.signal,
      };

      const methodUpper = String(method || "GET").toUpperCase();
      if (
        preparedBody !== undefined &&
        methodUpper !== "GET" &&
        methodUpper !== "HEAD"
      ) {
        options.body = preparedBody;
      }

      const response = await fetch(url, options);

      const result = await parseResponse(response);
      if (!shouldRetry(result, attempt, attempts)) {
        return result;
      }

      attempt += 1;
      logWithTimestamp(
        `⚠️ WAHA sorğusu (attempt ${attempt}/${attempts}) status ${result.status} üçün yenidən sınaq: ${method} ${path}`,
      );
      await sleep(DEFAULT_RETRY_DELAY_MS);
      continue;
    } catch (error) {
      lastError = error;
      if (error.name === "AbortError") {
        logWithTimestamp(`⚠️ WAHA sorğusu vaxt aşımı: ${method} ${path}`);
        if (attempt >= attempts) {
          return {
            ok: false,
            status: 504,
            error: "WAHA sorğusu vaxt aşımına uğradı.",
          };
        }
      } else {
        logWithTimestamp(`❌ WAHA sorğusu xətası: ${method} ${path}`, error.message);
        if (attempt >= attempts) {
          return {
            ok: false,
            status: 500,
            error: error.message,
          };
        }
      }
    } finally {
      clearTimeout(timer);
    }

    attempt += 1;
    if (attempt <= attempts) {
      await sleep(DEFAULT_RETRY_DELAY_MS);
    }
  }

  return {
    ok: false,
    status: 500,
    error: lastError ? lastError.message : "WAHA sorğusu uğursuz oldu.",
  };
}

async function parseResponse(response) {
  const contentType = response.headers.get("content-type") || "";
  let payload;
  try {
    if (contentType.includes("application/json")) {
      payload = await response.json();
    } else if (contentType.startsWith("text/")) {
      payload = await response.text();
    } else {
      payload = await response.buffer();
    }
  } catch (error) {
    logWithTimestamp(
      `⚠️ WAHA cavabını oxumaq mümkün olmadı (status ${response.status})`,
      error.message,
    );
    payload = null;
  }

  return {
    ok: response.ok,
    status: response.status,
    headers: response.headers,
    data: payload,
  };
}

async function getContactProfile(chatId) {
  const { session } = getConfig();
  if (!session) {
    return { ok: false, error: "WAHA_SESSION təyin edilməyib." };
  }

  const contactId = chatId.includes("@") ? chatId : `${chatId}@c.us`;
  const result = await request({
    method: "GET",
    path: `/api/${session}/contacts/${contactId}`,
  });

  if (!result.ok) {
    return result;
  }

  const profile = result.data || {};
  return {
    ok: true,
    data: {
      id: contactId,
      name: profile?.name || profile?.pushname || profile?.shortName || null,
      businessName: profile?.businessName || null,
      isBusiness: !!profile?.isBusiness,
      labels: profile?.labels || [],
      raw: profile,
    },
  };
}

async function listChats(limit = 20) {
  const { session } = getConfig();
  if (!session) {
    return { ok: false, error: "WAHA_SESSION təyin edilməyib." };
  }
  return request({
    method: "GET",
    path: `/api/${session}/chats`,
    query: { limit },
  });
}

async function sendToolCommand(command) {
  if (!command || typeof command !== "object") {
    throw new Error("WAHA tool əmri obyekt formatında olmalıdır.");
  }

  const { method = "POST", endpoint, payload, query, headers } = command;
  if (!endpoint) {
    throw new Error("WAHA tool əmri üçün endpoint tələb olunur.");
  }

  return request({
    method,
    path: endpoint,
    body: payload,
    query,
    headers,
  });
}

function resolveSession(sessionOverride) {
  const { session } = getConfig();
  return sessionOverride || session;
}

function buildPaginationParams({
  limit,
  cursor,
  before,
  after,
  offset,
  page,
  pageSize,
} = {}) {
  const params = {};
  if (limit !== undefined && limit !== null) params.limit = limit;
  if (cursor) params.cursor = cursor;
  if (before) params.before = before;
  if (after) params.after = after;
  if (offset !== undefined && offset !== null) params.offset = offset;
  if (page !== undefined && page !== null) params.page = page;
  if (pageSize !== undefined && pageSize !== null) params.pageSize = pageSize;
  return params;
}

function buildMediaPayload({
  session,
  phone,
  chatId,
  message,
  mediaUrl,
  mediaBase64,
  mimeType,
  fileName,
  caption,
  sendAsDocument,
} = {}) {
  const payload = {};
  if (session) payload.session = session;
  if (phone) payload.phone = phone;
  if (chatId) payload.chatId = chatId;
  if (message) payload.message = message;
  if (caption) payload.caption = caption;
  if (mimeType) payload.mimetype = mimeType;
  if (fileName) payload.fileName = fileName;
  if (sendAsDocument !== undefined) payload.sendAsDocument = sendAsDocument;

  if (mediaBase64) {
    payload.media = mediaBase64;
  } else if (mediaUrl) {
    payload.media = mediaUrl;
  }

  return payload;
}

module.exports = {
  request,
  getContactProfile,
  listChats,
  sendToolCommand,
  getConfig,
  buildUrl,
  buildPaginationParams,
  buildMediaPayload,
  resolveSession,
};
