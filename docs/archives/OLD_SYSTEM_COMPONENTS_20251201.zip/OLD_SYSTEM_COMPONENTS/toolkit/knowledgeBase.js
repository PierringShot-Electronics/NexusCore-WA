const fs = require("fs-extra");
const path = require("path");
const { searchProducts } = require("../productManager");
const { searchServices } = require("../serviceManager");
const { logWithTimestamp } = require("../../utils/logger");

const DOC_FILES = [
  "docs/business.md",
  "docs/LEAD_promt.md",
  "docs/deep_research_cleaned.txt",
];

let cachedBrief = null;

function loadBrief() {
  if (cachedBrief) return cachedBrief;
  const parts = [];
  for (const relativePath of DOC_FILES) {
    const absolutePath = path.join(process.cwd(), relativePath);
    try {
      if (fs.existsSync(absolutePath)) {
        const content = fs.readFileSync(absolutePath, "utf8").trim();
        if (content) {
          parts.push(`# Mənbə: ${relativePath}\n${content}`);
        }
      }
    } catch (error) {
      logWithTimestamp(`⚠️ ${relativePath} oxunmadı:`, error.message);
    }
  }
  cachedBrief = parts.join("\n\n---\n\n");
  return cachedBrief;
}

function gatherCatalogMatches(query) {
  const products = searchProducts(query) || [];
  const services = searchServices(query) || [];

  const lines = [];
  if (products.length > 0) {
    lines.push(
      "TAPILAN MƏHSULLAR:",
      ...products.slice(0, 8).map((product) =>
        `- ID: ${product.id || "?"}, Ad: ${product.name || ""}, Qiymət: ${
          product.price !== undefined ? `${product.price} AZN` : "bilinmir"
        }${product.stock !== undefined ? `, Stok: ${product.stock}` : ""}`,
      ),
    );
  }
  if (services.length > 0) {
    lines.push(
      "TAPILAN XİDMƏTLƏR:",
      ...services.slice(0, 8).map((service) =>
        `- ID: ${service.id || "?"}, Ad: ${service.name || ""}, Qiymət: ${
          service.price !== undefined ? `${service.price} AZN` : "bilinmir"
        }`,
      ),
    );
  }

  return {
    products,
    services,
    summary: lines.length > 0 ? lines.join("\n") : "",
  };
}

function buildKnowledgeContext(query) {
  const { summary } = gatherCatalogMatches(query || "");
  const brief = loadBrief();
  const blocks = [];

  if (summary) {
    blocks.push(`[BİLİK BAZASI NƏTİCƏLƏRİ]\n${summary}`);
  }
  if (brief) {
    blocks.push(`[STRATEJİ QISA MƏLUMAT]\n${brief}`);
  }
  return blocks.join("\n\n");
}

module.exports = {
  gatherCatalogMatches,
  buildKnowledgeContext,
  loadBrief,
};
