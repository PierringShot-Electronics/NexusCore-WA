const DEFAULT_TIMEZONE = "Asia/Baku";

const greetingQuickReply = `📩 Salam, qardaş! PierringShot Electronics™ yanındadır və sənə kömək etməyə hazırdır.
1️⃣ 🔧 Təmir lazımdır
2️⃣ 💻 Məhsul qiymətləri
3️⃣ 📍 Ünvan & çatdırılma
4️⃣ 📆 Görüş təyin et

Bu kodlardan birini yaz və ya problemini qısa təsvir et, dərhal plan quraq. 😊`;

function buildAwayMessageText({ timeLabel, nextWindowLabel } = {}) {
  const clockLine = timeLabel
    ? `Hazırda Bakı vaxtı ilə ${timeLabel}-dir və Elvin Ağayev AKM-də növbədən kənardadır.`
    : "Hazırda Elvin Ağayev AKM-də növbədən kənardadır.";
  const nextLine = nextWindowLabel
    ? `Servis komandasının növbəti canlı cavab pəncərəsi ${nextWindowLabel}-da açılacaq.`
    : "Servis komandasının canlı cavab pəncərəsi həftəiçi 09:00–21:00, şənbə 11:00–17:00 arasındadır.";
  const closing =
    "Adınızı və problemi buraxın, növbəti iş saatında mesajınıza geri dönəcəyik. Təcili təmir üçün Gənclik laboratoriyamız açılan kimi sıraya salınacaqsınız.";
  return `⏳ Hey qardaş! ${clockLine} ${nextLine} ${closing}`;
}

const depotInfoBlock = `🏢 Depolar & İş Saatları
• Gənclik Servis Lab — Həsən Əliyev 96 (həftəiçi 10:00–19:00, şənbə 11:00–17:00): diaqnostika, təmir, sürətli testlər.
• 28 May Retail Spot — Süleyman Rüstəm 15d (10:30–20:00): aksessuarlar, ekspres quraşdırma, kassalı satış.
• Rəşid Behbudov Depo — ADU yanı (11:00–18:00, şənbə 12:00–17:00): ehtiyat hissələri, kuryer çıxışı.

🚚 Çatdırılma: Bakı daxili kuryer 2–4 saat, regionlar poçt ilə 1–3 iş günü. Təhvil üçün şəxsiyyət vəsiqəsi və sipariş kodu tələb olunur.`;

function getCustomerExperienceReference() {
  const segments = [
    `[CX-GREETING]\n${greetingQuickReply}`,
    `[CX-AWAY]\n${buildAwayMessageText()}`,
    `[CX-DEPOTS]\n${depotInfoBlock}`,
  ];
  return `[CX-BLOKLARI]\n${segments.join("\n\n")}`;
}

module.exports = {
  DEFAULT_TIMEZONE,
  greetingQuickReply,
  buildAwayMessageText,
  depotInfoBlock,
  getCustomerExperienceReference,
};
