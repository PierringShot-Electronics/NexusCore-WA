# Moderation Layer

This directory will contain rule-sets and model prompts for profanity/PII masking as required by SAFE_MODE.

Planned artifacts:
- `rules.yaml`: keyword/regex filters
- `policies.md`: escalation and audit steps
- `tests/`: fixtures for red-team prompts
