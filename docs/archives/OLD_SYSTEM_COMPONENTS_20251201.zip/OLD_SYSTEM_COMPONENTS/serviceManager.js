/**
 * WhatsCore.AI - Maverick Edition
 *
 * Xidmət Meneceri (Service Manager) - v4.6.0
 * CSV və JSON mənbələrindən oxuyur, axtarış və siyahı funksiyaları təqdim edir.
 */
const fs = require('fs');
const path = require('path');
const { parse } = require('csv-parse/sync');
const { logWithTimestamp } = require('../utils/logger');

const DATA_DIR = path.join(__dirname, '..', 'data');
const SERVICES_CSV_PATH = path.join(DATA_DIR, 'services.csv');
const SERVICES_JSON_PATH = path.join(DATA_DIR, 'services.json');

let services = [];

function toNumber(value) {
  if (value === undefined || value === null || value === '') return 0;
  const numeric = Number(value);
  return Number.isFinite(numeric) ? numeric : 0;
}

function loadServicesFromCsv() {
  if (!fs.existsSync(SERVICES_CSV_PATH)) {
    return [];
  }
  try {
    const fileContent = fs.readFileSync(SERVICES_CSV_PATH);
    const parsed = parse(fileContent, {
      columns: true,
      skip_empty_lines: true,
      trim: true,
    });
    const normalized = parsed.map((service) => ({
      ...service,
      price: toNumber(service.price),
      duration: toNumber(service.duration),
    }));
    logWithTimestamp(`✅ ${normalized.length} xidmət CSV verilənlər bazasından uğurla yükləndi.`);
    return normalized;
  } catch (error) {
    logWithTimestamp('❌ Xidmətləri CSV-dən oxumaq mümkün olmadı:', error);
    return [];
  }
}

function loadServicesFromJson() {
  if (!fs.existsSync(SERVICES_JSON_PATH)) {
    return [];
  }
  try {
    const raw = fs.readFileSync(SERVICES_JSON_PATH, 'utf8').trim();
    if (!raw) {
      return [];
    }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) {
      logWithTimestamp('⚠️ services.json gözlənilən massiv formatında deyil.');
      return [];
    }
    const normalized = parsed.map((service) => ({
      ...service,
      price: toNumber(service.price ?? service.rate),
      duration: toNumber(service.duration ?? service.etaMinutes),
    }));
    logWithTimestamp(`✅ ${normalized.length} xidmət JSON verilənlər bazasından yükləndi.`);
    return normalized;
  } catch (error) {
    logWithTimestamp('❌ Xidmətləri JSON-dan oxumaq mümkün olmadı:', error);
    return [];
  }
}

function loadServices() {
  const csvServices = loadServicesFromCsv();
  if (csvServices.length > 0) {
    return csvServices;
  }
  const jsonServices = loadServicesFromJson();
  if (jsonServices.length > 0) {
    return jsonServices;
  }
  logWithTimestamp('⚠️ Aktiv xidmət verilənlər bazası tapılmadı. Boş massiv qaytarılır.');
  return [];
}

services = loadServices();

/**
 * Xidmətləri açar sözlərə görə axtarır.
 * @param {string} query - Axtarış üçün istifadəçi sorğusu və ya xidmət ID-si.
 * @returns {Array} - Tapılan xidmətlərin massivi.
 */
function searchServices(query) {
  if (!query || query.length < 3) return [];

  const lowerCaseQuery = query.toLowerCase().trim();

  // Dəqiq ID ilə axtarış
  const byId = services.find((s) => s.id && s.id.toLowerCase() === lowerCaseQuery);
  if (byId) return [byId];

  // Ad, təsvir və etiketlərdə (tags) axtarış
  const searchTerms = lowerCaseQuery.split(/\s+/).filter((term) => term.length > 2);
  if (searchTerms.length === 0) return [];

  return services.filter((service) => {
    const serviceName = (service.name || '').toLowerCase();
    const serviceDescription = (service.description || '').toLowerCase();
    const serviceCategory = (service.category || '').toLowerCase();
    const serviceTags = (service.tags || '').toLowerCase();

    // Bütün axtarış sözləri xidmət məlumatlarında mövcud olmalıdır
    return searchTerms.every(
      (term) =>
        serviceName.includes(term) ||
        serviceDescription.includes(term) ||
        serviceCategory.includes(term) ||
        serviceTags.includes(term)
    );
  });
}

function getServices() {
  return services.map((service) => ({ ...service }));
}

function refreshServices() {
  services = loadServices();
  return getServices();
}

module.exports = {
  searchServices,
  getServices,
  refreshServices,
  services,
};
