const Groq = require("groq-sdk");
const fs = require("fs-extra");
const { logWithTimestamp } = require("../../utils/logger");
const { recordGroqMetric } = require("../../utils/metrics/groqMetrics");

const DEFAULT_ACCOUNT_LABEL = "default";
const DEFAULT_QUARANTINE_MINUTES = Number(process.env.GROQ_KEY_QUARANTINE_MINUTES || 30);

function parseGroqKeyBuckets(raw = process.env.GROQ_API_KEYS || "") {
  const buckets = [];
  const entries = raw
    .split(",")
    .map((entry) => entry.trim())
    .filter(Boolean);

  for (const entry of entries) {
    let account = DEFAULT_ACCOUNT_LABEL;
    let key = entry;

    if (entry.includes(":")) {
      const [label, ...rest] = entry.split(":");
      const candidateKey = rest.join(":").trim();
      if (candidateKey) {
        account = label.trim().toLowerCase() || DEFAULT_ACCOUNT_LABEL;
        key = candidateKey;
      }
    }

    if (!key) continue;

    let bucket = buckets.find((item) => item.account === account);
    if (!bucket) {
      bucket = { account, keys: [] };
      buckets.push(bucket);
    }

    bucket.keys.push(key);
  }

  return buckets;
}

function flattenBucketKeys(buckets = []) {
  const keys = [];
  for (const bucket of buckets) {
    if (!bucket || !Array.isArray(bucket.keys)) continue;
    for (const key of bucket.keys) {
      if (key) keys.push(key);
    }
  }
  return keys;
}

function buildRotationRing(buckets) {
  if (!Array.isArray(buckets) || buckets.length === 0) return [];
  const maxKeys = Math.max(...buckets.map((bucket) => bucket.keys.length));
  const ring = [];

  for (let i = 0; i < maxKeys; i += 1) {
    for (const bucket of buckets) {
      if (bucket.keys[i]) {
        ring.push({ account: bucket.account, key: bucket.keys[i] });
      }
    }
  }

  return ring;
}

function formatKeyTail(key) {
  if (!key || key.length < 4) return key || "unknown";
  return key.slice(-4);
}

class GroqProvider {
  constructor() {
    const staticQuarantineBuckets = parseGroqKeyBuckets(process.env.GROQ_QUARANTINED_KEYS || "");
    this.staticQuarantinedKeys = new Set(flattenBucketKeys(staticQuarantineBuckets));

    const parsedBuckets = parseGroqKeyBuckets();

    this.accounts = parsedBuckets
      .map((bucket) => {
        const retained = bucket.keys.filter((key) => {
          if (this.staticQuarantinedKeys.has(key)) {
            logWithTimestamp(
              `🚧 Groq key skipped (static quarantine) [${bucket.account}] ...${formatKeyTail(key)}`,
            );
            recordGroqMetric('key-static-quarantine', {
              account: bucket.account,
              keyTail: formatKeyTail(key),
            });
            return false;
          }
          return true;
        });
        return { account: bucket.account, keys: retained };
      })
      .filter((bucket) => bucket.keys.length > 0);

    const totalKeys = this.accounts.reduce((sum, bucket) => sum + bucket.keys.length, 0);

    if (totalKeys === 0) {
      throw new Error("GROQ_API_KEYS is missing or empty. Provide at least one valid key.");
    }

    this.rotationRing = buildRotationRing(this.accounts);
    this.currentIndex = -1;
    this.lastErrorByKey = new Map();
    this.quarantinedKeys = new Map();
    this.quarantineTtlMs = Math.max(DEFAULT_QUARANTINE_MINUTES, 1) * 60 * 1000;

    this.#activateNextKey("bootstrap", { forceAdvance: true });
  }

  #isQuarantined(key) {
    if (!key) return false;
    const expiry = this.quarantinedKeys.get(key);
    if (!expiry) return false;
    if (Date.now() >= expiry) {
      this.quarantinedKeys.delete(key);
      return false;
    }
    return true;
  }

  #activateNextKey(reason, { forceAdvance = true } = {}) {
    const total = this.rotationRing.length;
    if (total === 0) {
      throw new Error("No Groq API keys are available for rotation.");
    }

    const startIndex = forceAdvance
      ? (this.currentIndex + 1) % total
      : this.currentIndex < 0
        ? 0
        : this.currentIndex;

    let index = startIndex;
    let attempts = 0;

    while (attempts < total) {
      const candidate = this.rotationRing[index];
      if (!this.#isQuarantined(candidate.key)) {
        const previousIndex = this.currentIndex;
        this.currentIndex = index;
        const shouldReinstantiate = !this.client || previousIndex !== index;
        if (shouldReinstantiate) {
          this.client = new Groq({ apiKey: candidate.key });
          logWithTimestamp(
            `🔄 Groq API key activated [${candidate.account}] ...${formatKeyTail(candidate.key)}${
              reason ? ` (${reason})` : ""
            }`,
          );
          recordGroqMetric('key-activated', {
            account: candidate.account,
            keyTail: formatKeyTail(candidate.key),
            reason,
          });
        }
        return candidate;
      }

      index = (index + 1) % total;
      attempts += 1;
      // after the first pass we must advance even if forceAdvance was false initially
      forceAdvance = true;
    }

    throw new Error("All Groq API keys are currently quarantined. Investigate invalid credentials.");
  }

  #ensureActiveKey() {
    const activeKey = this.getActiveKey();
    if (!activeKey || this.#isQuarantined(activeKey)) {
      this.#activateNextKey("ensure-active", { forceAdvance: true });
    }
  }

  #quarantineCurrentKey(reason) {
    const active = this.rotationRing[this.currentIndex];
    if (!active) return;
    const expiry = Date.now() + this.quarantineTtlMs;
    this.quarantinedKeys.set(active.key, expiry);
    logWithTimestamp(
      `🚫 Groq key quarantined [${active.account}] ...${formatKeyTail(active.key)} until ${
        new Date(expiry).toISOString()
      }${reason ? ` (${reason})` : ""}`,
    );
    recordGroqMetric('key-quarantined', {
      account: active.account,
      keyTail: formatKeyTail(active.key),
      reason,
      expiresAt: new Date(expiry).toISOString(),
    });
  }

  rotateKey(reason, { quarantineCurrent = false } = {}) {
    if (quarantineCurrent) {
      this.#quarantineCurrentKey(reason);
    }
    const next = this.#activateNextKey(reason || "rotation", { forceAdvance: true });
    recordGroqMetric('key-rotated', {
      reason: reason || 'rotation',
      account: next.account,
      keyTail: formatKeyTail(next.key),
      quarantined: Boolean(quarantineCurrent),
    });
    return next;
  }

  getActiveKey() {
    if (this.currentIndex < 0) return undefined;
    return this.rotationRing[this.currentIndex]?.key;
  }

  async chatCompletion(requestPayload, options = {}) {
    const maxAttempts = Math.max(this.rotationRing.length * 2, 1);
    let attempts = 0;

    while (attempts < maxAttempts) {
      this.#ensureActiveKey();
      try {
        const response = await this.client.chat.completions.create({
          ...requestPayload,
          temperature: options.temperature ?? requestPayload.temperature ?? 0.2,
          max_tokens: options.maxTokens ?? requestPayload.max_tokens,
        });
        recordGroqMetric('chat-success', {
          account: this.rotationRing[this.currentIndex]?.account,
          keyTail: formatKeyTail(this.getActiveKey()),
        });
        return response;
      } catch (error) {
        const status = error?.status || error?.response?.status;
        const retryAfter = Number(error?.response?.headers?.["retry-after"] || 0);
        const activeKey = this.getActiveKey();
        if (activeKey) {
          this.lastErrorByKey.set(activeKey, error);
        }
        logWithTimestamp(
          `❌ Groq chatCompletion error (status: ${status || "unknown"}): ${error?.message || error}`,
        );
        const activeAccount = this.rotationRing[this.currentIndex]?.account;
        const reasonLabel = status === 401
          ? 'unauthorized'
          : status === 403
            ? 'forbidden'
            : status === 429
              ? 'rate-limit'
              : status === 500
                ? 'server-error'
                : 'other';
        recordGroqMetric('chat-error', {
          status: status || 'unknown',
          reason: reasonLabel,
          keyTail: activeKey ? formatKeyTail(activeKey) : undefined,
          account: activeAccount,
        });

        if (status === 401) {
          this.rotateKey(`status ${status}`, { quarantineCurrent: true });
          attempts += 1;
          continue;
        }

        if ([403, 429].includes(status)) {
          if (retryAfter > 0 && retryAfter < 10) {
            await new Promise((resolve) => setTimeout(resolve, retryAfter * 1000));
          }
          this.rotateKey(`status ${status}`);
          attempts += 1;
          continue;
        }

        if (status === 500) {
          this.rotateKey("server error");
          attempts += 1;
          continue;
        }

        throw error;
      }
    }

    throw new Error("Groq chatCompletion failed after exhausting available API keys.");
  }

  async multimodalCompletion({ prompt, media }, options = {}) {
    const userContent = [];
    if (prompt) {
      userContent.push({ type: "text", text: prompt });
    }
    for (const item of media || []) {
      const mimeType = item.mimeType || item.type || "image/jpeg";
      const dataUrl = await this.#mediaToDataUrl(item.path, mimeType);
      userContent.push({ type: "image_url", image_url: { url: dataUrl } });
    }

    return this.chatCompletion(
      {
        model:
          options.model ||
          process.env.GROQ_VISION_MODEL ||
          "meta-llama/llama-4-scout-17b-16e-instruct",
        messages: [
          { role: "system", content: options.systemPrompt || "Şəkili analiz et və detallı təsvir ver." },
          { role: "user", content: userContent },
        ],
        max_tokens: options.maxTokens || 320,
        temperature: options.temperature ?? 0.2,
      },
      options,
    );
  }

  async transcribeAudio(filePath, options = {}) {
    const transcriptionOptions = {
      file: fs.createReadStream(filePath),
      model: options.model || process.env.GROQ_TRANSCRIPTION_MODEL || "whisper-large-v3-turbo",
      temperature: options.temperature ?? 0.2,
      language: options.language || "az",
    };

    const maxAttempts = Math.max(this.rotationRing.length * 2, 1);
    let attempts = 0;

    while (attempts < maxAttempts) {
      this.#ensureActiveKey();
      try {
        const result = await this.client.audio.transcriptions.create(transcriptionOptions);
        recordGroqMetric('transcription-success', {
          account: this.rotationRing[this.currentIndex]?.account,
          keyTail: formatKeyTail(this.getActiveKey()),
        });
        return result;
      } catch (error) {
        const status = error?.status || error?.response?.status;
        const activeKey = this.getActiveKey();
        if (activeKey) {
          this.lastErrorByKey.set(activeKey, error);
        }
        logWithTimestamp(
          `❌ Groq transcription error (status: ${status || "unknown"}): ${error?.message || error}`,
        );
        const activeAccount = this.rotationRing[this.currentIndex]?.account;
        const reasonLabel = status === 401
          ? 'unauthorized'
          : status === 403
            ? 'forbidden'
            : status === 429
              ? 'rate-limit'
              : status === 500
                ? 'server-error'
                : 'other';
        recordGroqMetric('transcription-error', {
          status: status || 'unknown',
          reason: reasonLabel,
          keyTail: activeKey ? formatKeyTail(activeKey) : undefined,
          account: activeAccount,
        });

        if (status === 401) {
          this.rotateKey(`audio status ${status}`, { quarantineCurrent: true });
          attempts += 1;
          continue;
        }

        if ([403, 429].includes(status)) {
          this.rotateKey(`audio status ${status}`);
          attempts += 1;
          continue;
        }

        throw error;
      }
    }

    throw new Error("Groq transcription failed after exhausting available API keys.");
  }

  async #mediaToDataUrl(filePath, mimeType) {
    try {
      const fileBuffer = await fs.readFile(filePath);
      const base64 = fileBuffer.toString("base64");
      return `data:${mimeType};base64,${base64}`;
    } catch (error) {
      logWithTimestamp(`❌ Media faylı oxunmadı: ${filePath}`, error.message);
      throw error;
    }
  }
}

let providerInstance;
function getGroqProvider() {
  if (!providerInstance) {
    providerInstance = new GroqProvider();
  }
  return providerInstance;
}

module.exports = { GroqProvider, getGroqProvider, parseGroqKeyBuckets };
