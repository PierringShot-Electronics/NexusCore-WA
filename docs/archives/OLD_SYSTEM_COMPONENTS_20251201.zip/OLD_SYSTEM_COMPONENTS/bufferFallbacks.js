const { logWithTimestamp } = require("../utils/logger");

const DEFAULT_FALLBACKS = {
    text: "⚠️ We hit a snag preparing your reply. Your request is queued and we'll follow up shortly.",
    media: "⚠️ We received your files but cannot process them right now. The team will retry and keep you posted."
};

function resolveFallbackMessage(type) {
    const envKey = type === "media" ? "MEDIA_BUFFER_FALLBACK" : "TEXT_BUFFER_FALLBACK";
    return process.env[envKey] || process.env.BUFFER_FALLBACK_MESSAGE || DEFAULT_FALLBACKS[type] || DEFAULT_FALLBACKS.text;
}

function getBufferFallbackMessage(type, error) {
    const fallback = resolveFallbackMessage(type);
    const snapshot = error && (error.code || error.status || error.name) ? ` (code: ${error.code || error.status || error.name})` : "";
    logWithTimestamp(`⚠️ ${type === "media" ? "Media" : "Text"} buffer fallback triggered${snapshot}.`);
    return fallback;
}

module.exports = { getBufferFallbackMessage };
