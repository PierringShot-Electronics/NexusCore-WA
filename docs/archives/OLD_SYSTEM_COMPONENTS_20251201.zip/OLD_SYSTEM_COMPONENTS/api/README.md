# WhatsCore Stack: WAHA + Groq

This folder contains the Docker assets that lift WAHA (WhatsApp HTTP API) alongside its Redis dependency. Express, Groq orchestration, and all business logic run on the host machine; WAHA simply exposes the WhatsApp transport surface.

## Components

- **WAHA (`devlikeapro/waha`)** – WhatsApp HTTP API server (REST + dashboard + Swagger).
- **Redis 7** – optional cache/storage layer used by WAHA.

## Quick Start

1. Copy `.env.example` from the repo root to `.env` and fill the WAHA credentials (API key, session name, HMAC secret). Ensure `WAHA_WEBHOOK_URL` points to the Express webhook, e.g., `http://host.docker.internal:9876/api/webhooks/waha`.
2. From this directory, run:
   ```bash
   docker compose up -d
   ```
3. Open WAHA Swagger at `http://localhost:${WHATSAPP_API_PORT:-3000}`.

## Pairing WAHA

```bash
curl -X POST "http://localhost:${WHATSAPP_API_PORT:-3000}/api/sessions" \
  -H "Content-Type: application/json" \
  -H "X-Api-Key: ${WAHA_API_KEY}" \
  -d '{
        "name":"default",
        "start":true,
        "config":{
          "webhooks":[
            {
              "url":"http://host.docker.internal:9876/api/webhooks/waha",
              "events":["message","session.status"]
            }
          ]
        }
      }'
```

Then fetch the QR code via `http://localhost:${WHATSAPP_API_PORT:-3000}/api/screenshot?session=default` and scan it from WhatsApp → Linked Devices.

## Security Notes

- Always set `WAHA_API_KEY` **or** `WAHA_API_KEY_HASH` together with `WAHA_HMAC_SECRET`.
- Protect the embedded dashboard/Swagger via `WAHA_DASHBOARD_USERNAME|PASSWORD` and `WHATSAPP_SWAGGER_USERNAME|PASSWORD`.
- If exposing the stack publicly, place it behind a TLS-terminating reverse proxy (Traefik/Nginx), enforce IP allowlists, and enable rate limiting.

## Backups

- Persist the mounted volumes: `data/redis` and `data/waha`. They hold WAHA session storage and Redis append-only files.

## Updating

```bash
docker compose pull && docker compose up -d
```

This pulls the latest WAHA image while retaining the local volumes.
