/**
 * WhatsCore.AI - Maverick Edition
 *
 * API Routes - v5.0.2 (FINAL & STABLE)
 * YENİLİK: Bütün marşrutlar (routes) ən son whatsappController ilə tam sinxronlaşdırıldı.
 * 'Undefined' callback xətası və köhnəlmiş endpointlər tamamilə aradan qaldırıldı.
 */
const express = require("express");
const router = express.Router();
const whatsappController = require("../controllers/whatsappController");
const wahaProxyController = require("../controllers/wahaProxyController");
const wahaSessionsController = require("../controllers/wahaSessionsController");
const wahaMessagesController = require("../controllers/wahaMessagesController");
const wahaChatsController = require("../controllers/wahaChatsController");
const wahaContactsController = require("../controllers/wahaContactsController");
const wahaPresenceController = require("../controllers/wahaPresenceController");
const wahaGroupsController = require("../controllers/wahaGroupsController");
const wahaStatusController = require("../controllers/wahaStatusController");
const wahaChannelsController = require("../controllers/wahaChannelsController");
const wahaMediaController = require("../controllers/wahaMediaController");
const wahaAppsController = require("../controllers/wahaAppsController");
const wahaAuthController = require("../controllers/wahaAuthController");
const wahaProfileController = require("../controllers/wahaProfileController");
const wahaLabelsController = require("../controllers/wahaLabelsController");
const wahaEventsController = require("../controllers/wahaEventsController");
const wahaWebhookController = require("../controllers/wahaWebhookController");
const orchestratorController = require("../controllers/orchestratorController");
const { logWithTimestamp } = require("../utils/logger");

// Middleware: Bütün API sorğularını loglayır
router.use((req, res, next) => {
  logWithTimestamp(`🌐 API Sorğusu Alındı: ${req.method} ${req.originalUrl}`);
  next();
});

// --- Status və Sessiya Marşrutları ---
router.get("/status", whatsappController.getClientStatus);
router.post("/logout", whatsappController.logoutClient);
router.post("/reset", whatsappController.resetClientSession);
router.get("/session/status", whatsappController.getWahaSessionStatus);
router.post("/session/start", whatsappController.startWahaSession);
router.get("/session/qr", whatsappController.getWahaSessionQr);
router.get("/session", wahaSessionsController.listSessions);
router.post("/session", wahaSessionsController.createSession);
router.get("/session/:session", wahaSessionsController.getSession);
router.post("/session/:session/restart", wahaSessionsController.restartSession);
router.post("/session/:session/stop", wahaSessionsController.stopSession);
router.post("/session/:session/logout", wahaSessionsController.logoutSession);
router.delete("/session/:session", wahaSessionsController.deleteSession);
router.get("/session/:session/profile", wahaProfileController.getProfile);
router.get("/session/:session/me", wahaSessionsController.getMe);
router.post("/session/:session/auth-code", wahaSessionsController.getAuthCode);
router.get("/session/:session/auth/qr", wahaAuthController.getQr);
router.post("/session/:session/auth/request-code", wahaAuthController.requestCode);
router.put("/session/:session/profile/name", wahaProfileController.setName);
router.put("/session/:session/profile/status", wahaProfileController.setStatus);
router.put("/session/:session/profile/picture", wahaProfileController.setPicture);
router.delete("/session/:session/profile/picture", wahaProfileController.deletePicture);

// --- Orchestrator Controls ---
router.get("/orchestrator/state", orchestratorController.getAutomationState);
router.post("/orchestrator/pause", orchestratorController.pauseAutomation);
router.post("/orchestrator/resume", orchestratorController.resumeAutomation);

// --- Mesaj Göndərmə Marşrutları ---
router.post("/send/text", whatsappController.sendText);
router.post("/send/media", whatsappController.sendMedia);
router.post("/send/location", whatsappController.sendLocation);
router.post("/send/contact", whatsappController.sendContact);
router.post("/messages/text", wahaMessagesController.sendText);
router.post("/messages/image", wahaMessagesController.sendImage);
router.post("/messages/video", wahaMessagesController.sendVideo);
router.post("/messages/audio", wahaMessagesController.sendAudio);
router.post("/messages/voice", wahaMessagesController.sendVoice);
router.post("/messages/file", wahaMessagesController.sendFile);
router.post("/messages/sticker", wahaMessagesController.sendSticker);
router.post("/messages/template", wahaMessagesController.sendTemplate);
router.post("/messages/list", wahaMessagesController.sendList);
router.post("/messages/buttons", wahaMessagesController.sendButtons);
router.post("/messages/buttons/reply", wahaMessagesController.sendButtonsReply);
router.post("/messages/poll", wahaMessagesController.sendPoll);
router.post("/messages/location", wahaMessagesController.sendLocation);
router.post("/messages/contact", wahaMessagesController.sendContact);
router.post("/messages/forward", wahaMessagesController.forwardMessage);
router.post("/messages/seen", wahaMessagesController.markSeen);
router.post("/messages/start-typing", wahaMessagesController.startTyping);
router.post("/messages/stop-typing", wahaMessagesController.stopTyping);
router.post("/messages/star", wahaMessagesController.starMessage);

// --- Məlumatların İdarəsi Marşrutları ---
router.get("/products", whatsappController.getProducts);
router.get("/services", whatsappController.getServices);
router.get("/orders", whatsappController.getAllOrders);
router.post("/orders", whatsappController.createOrder);

// --- Söhbət (Chat) İdarəetmə Marşrutları ---
router.get("/chats", whatsappController.getChats);
router.post("/chats/archive", whatsappController.archiveChat);
router.post("/chats/unarchive", whatsappController.unarchiveChat);
router.post("/chats/pin", whatsappController.pinMessage);
router.post("/chats/unpin", whatsappController.unpinMessage);
router.post("/chats/mark-read", whatsappController.markChatAsRead);
router.post("/chats/mark-unread", whatsappController.markChatAsUnread);
router.get("/chats/list", wahaChatsController.listChats);
router.get("/chats/:chatId", wahaChatsController.getChat);
router.get("/chats/:chatId/messages", wahaChatsController.getChatMessages);
router.delete("/chats/:chatId", wahaChatsController.deleteChat);
router.delete("/chats/:chatId/messages", wahaChatsController.clearChat);
router.delete("/chats/:chatId/messages/:messageId", wahaChatsController.deleteMessage);
router.put("/chats/:chatId/messages/:messageId", wahaChatsController.editMessage);
router.post("/chats/:chatId/mark-read", wahaChatsController.markRead);
router.post("/chats/:chatId/mark-unread", wahaChatsController.markUnread);
router.post("/chats/:chatId/archive", wahaChatsController.archiveChat);
router.post("/chats/:chatId/unarchive", wahaChatsController.unarchiveChat);
router.post("/chats/:chatId/messages/:messageId/pin", wahaChatsController.pinMessage);
router.post("/chats/:chatId/messages/:messageId/unpin", wahaChatsController.unpinMessage);

// --- Presence ---
router.get("/chats/:chatId/presence", wahaPresenceController.getPresence);
router.post("/chats/:chatId/presence/subscribe", wahaPresenceController.subscribePresence);
router.post("/chats/:chatId/presence/unsubscribe", wahaPresenceController.unsubscribePresence);
router.post("/chats/:chatId/presence", wahaPresenceController.setPresence);

// --- Kontakt (Contact) İdarəetmə Marşrutları ---
router.get("/contacts", whatsappController.getAllContacts);
router.get("/contacts/info", whatsappController.getContactInfo);
router.get("/contacts/profile-pic", whatsappController.getProfilePicUrl);
router.get("/contacts/list", wahaContactsController.listContacts);
router.get("/contacts/:contactId", wahaContactsController.getContact);
router.get("/contacts/:contactId/about", wahaContactsController.getAbout);
router.post("/contacts/:contactId/labels", wahaContactsController.setLabels);
router.post("/contacts/check", wahaContactsController.checkNumber);
router.post("/contacts/:contactId/block", wahaContactsController.blockContact);
router.post("/contacts/:contactId/unblock", wahaContactsController.unblockContact);
router.get("/contacts/:contactId/profile-picture", wahaContactsController.getProfilePicture);

// --- Groups ---
router.get("/groups", wahaGroupsController.listGroups);
router.post("/groups", wahaGroupsController.createGroup);
router.get("/groups/:groupId", wahaGroupsController.getGroup);
router.put("/groups/:groupId/subject", wahaGroupsController.updateSubject);
router.put("/groups/:groupId/description", wahaGroupsController.updateDescription);
router.post("/groups/:groupId/participants", wahaGroupsController.addParticipants);
router.delete("/groups/:groupId/participants", wahaGroupsController.removeParticipants);
router.post("/groups/:groupId/promote", wahaGroupsController.promoteParticipants);
router.post("/groups/:groupId/demote", wahaGroupsController.demoteParticipants);
router.get("/groups/:groupId/invite-code", wahaGroupsController.getInviteCode);
router.delete("/groups/:groupId/invite-code", wahaGroupsController.revokeInviteCode);
router.post("/groups/join", wahaGroupsController.joinGroup);

// --- Status ---
router.get("/status/posts", wahaStatusController.listStatus);
router.post("/status/text", wahaStatusController.postTextStatus);
router.post("/status/image", wahaStatusController.postImageStatus);
router.post("/status/video", wahaStatusController.postVideoStatus);
router.delete("/status/:statusId", wahaStatusController.deleteStatus);

// --- Channels ---
router.get("/channels", wahaChannelsController.listChannels);
router.get("/channels/:channelId", wahaChannelsController.getChannel);
router.post("/channels/:channelId/follow", wahaChannelsController.followChannel);
router.delete("/channels/:channelId/follow", wahaChannelsController.unfollowChannel);
router.post("/channels/:channelId/mute", wahaChannelsController.muteChannel);
router.delete("/channels/:channelId/mute", wahaChannelsController.unmuteChannel);
router.get("/channels/:channelId/posts", wahaChannelsController.getChannelPosts);

// --- Media ---
router.get("/media/messages/:messageId/download", wahaMediaController.downloadMessage);
router.post("/media/messages/:messageId/download/retry", wahaMediaController.retryDownload);

// --- Apps ---
router.get("/apps", wahaAppsController.listApps);
router.post("/apps", wahaAppsController.createApp);
router.get("/apps/:appId", wahaAppsController.getApp);
router.put("/apps/:appId", wahaAppsController.updateApp);
router.delete("/apps/:appId", wahaAppsController.deleteApp);
router.get("/apps/chatwoot/locales", wahaAppsController.listChatwootLocales);

// --- Labels ---
router.get("/labels", wahaLabelsController.listLabels);
router.post("/labels", wahaLabelsController.createLabel);
router.put("/labels/:labelId", wahaLabelsController.updateLabel);
router.delete("/labels/:labelId", wahaLabelsController.deleteLabel);
router.get("/labels/:labelId/chats", wahaLabelsController.listLabelChats);
router.get("/chats/:chatId/labels", wahaLabelsController.getChatLabels);
router.post("/chats/:chatId/labels", wahaLabelsController.setChatLabels);

// --- Events ---
router.post("/session/:session/events", wahaEventsController.sendEvent);

// --- Webhooks ---
router.post("/webhooks/waha", wahaWebhookController.handleWebhook);

// --- WAHA Proxy (Full Surface) ---
const wahaProxyRouter = express.Router();
wahaProxyRouter.all("*", wahaProxyController.forward);
router.use("/waha", wahaProxyRouter);

module.exports = router;
