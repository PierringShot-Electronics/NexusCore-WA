#!/usr/bin/env bash
set -euo pipefail

say() { printf '\n=== %s ===\n' "$1"; }

mask() {
  local value="$1"
  local length=${#value}
  if [ "$length" -le 8 ]; then
    printf '%s' "$value"
  else
    printf '%s…%s' "${value:0:4}" "${value: -4}"
  fi
}

get_env() {
  local file="$1"
  local key="$2"
  if [ ! -f "$file" ]; then
    return
  fi
  local line
  line=$(grep -E "^${key}=" "$file" | head -n1) || return 0
  printf '%s\n' "${line#*=}"
}

PROJECT_ROOT=$(cd -- "$(dirname "${BASH_SOURCE[0]}")" && pwd)
REPO_ROOT=$(cd -- "$PROJECT_ROOT/.." && pwd)
ROOT_ENV_FILE="$REPO_ROOT/.env"
STACK_ENV_FILE="$ROOT_ENV_FILE"

say "Compose config"
if (cd "$PROJECT_ROOT" && docker compose config >/dev/null 2>&1); then
  echo "docker compose config: OK"
else
  echo "docker compose config: FAIL" >&2
fi

say "Docker ps"
docker ps --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'

say "Health checks"
WAHA_USER=$(get_env "$STACK_ENV_FILE" "WHATSAPP_SWAGGER_USERNAME")
WAHA_PASS=$(get_env "$STACK_ENV_FILE" "WHATSAPP_SWAGGER_PASSWORD")
if [ -z "$WAHA_USER" ] || [ -z "$WAHA_PASS" ]; then
  WAHA_USER=$(get_env "$STACK_ENV_FILE" "WAHA_DASHBOARD_USERNAME")
  WAHA_PASS=$(get_env "$STACK_ENV_FILE" "WAHA_DASHBOARD_PASSWORD")
fi
if [ -n "$WAHA_USER" ] && [ -n "$WAHA_PASS" ]; then
  if curl -fsS -u "${WAHA_USER}:${WAHA_PASS}" http://localhost:3000/ping >/dev/null; then
    echo "WAHA /ping: OK"
  else
    echo "WAHA /ping: FAIL" >&2
  fi
else
  echo "WAHA /ping skipped (credentials missing)"
fi
say "Volumes"
for d in data/redis data/waha; do
  printf "%s : " "$d"
  if test -d "$PROJECT_ROOT/$d"; then
    echo "OK"
  else
    echo "MISSING"
  fi
done

say ".env sanity"
if [ -f "$STACK_ENV_FILE" ]; then
  awk -F= '/^PROJECT_ROOT=|^WAHA_WEBHOOK_URL=|^WAHA_API_BASE=|^WAHA_SESSION=|^WAHA_API_KEY_HASH=/' "$STACK_ENV_FILE"
else
  echo ".env missing (expected $STACK_ENV_FILE)" >&2
fi

project_root_env=$(get_env "$STACK_ENV_FILE" "PROJECT_ROOT")
if [ -n "$project_root_env" ] && [ "$project_root_env" != "$PROJECT_ROOT" ]; then
  echo "⚠️ PROJECT_ROOT mismatch: env=$project_root_env actual=$PROJECT_ROOT" >&2
fi

if [ -f "$ROOT_ENV_FILE" ] && [ -f "$STACK_ENV_FILE" ]; then
  say "WAHA env alignment"
  root_base=$(get_env "$ROOT_ENV_FILE" "WAHA_API_BASE")
  stack_base=$(get_env "$STACK_ENV_FILE" "WAHA_API_BASE")
  if [ -n "$root_base" ] || [ -n "$stack_base" ]; then
    if [ "$root_base" = "$stack_base" ]; then
      echo "WAHA_API_BASE: MATCH ($root_base)"
    else
      echo "⚠️ WAHA_API_BASE mismatch: root=$root_base stack=$stack_base" >&2
    fi
  fi

  root_session=$(get_env "$ROOT_ENV_FILE" "WAHA_SESSION")
  stack_session=$(get_env "$STACK_ENV_FILE" "WAHA_SESSION")
  if [ -n "$root_session" ] || [ -n "$stack_session" ]; then
    if [ "$root_session" = "$stack_session" ]; then
      echo "WAHA_SESSION: MATCH ($root_session)"
    else
      echo "⚠️ WAHA_SESSION mismatch: root=$root_session stack=$stack_session" >&2
    fi
  fi

  root_key=$(get_env "$ROOT_ENV_FILE" "WAHA_API_KEY")
  stack_key=$(get_env "$STACK_ENV_FILE" "WAHA_API_KEY")
  if [ -n "$root_key" ] && [ -n "$stack_key" ]; then
    if [ "$root_key" = "$stack_key" ]; then
      echo "WAHA_API_KEY: MATCH ($(mask "$root_key"))"
    else
      echo "⚠️ WAHA_API_KEY mismatch: root=$(mask "$root_key") stack=$(mask "$stack_key")" >&2
    fi
  fi

  root_hash=$(get_env "$ROOT_ENV_FILE" "WAHA_API_KEY_HASH")
  stack_hash=$(get_env "$STACK_ENV_FILE" "WAHA_API_KEY_HASH")
  if [ -n "$root_hash" ] || [ -n "$stack_hash" ]; then
    if [ "$root_hash" = "$stack_hash" ]; then
      echo "WAHA_API_KEY_HASH: MATCH ($(mask "$root_hash"))"
    else
      echo "⚠️ WAHA_API_KEY_HASH mismatch: root=$(mask "$root_hash") stack=$(mask "$stack_hash")" >&2
    fi
  fi

else
  echo "(Skipping WAHA env alignment – root or stack .env missing)"
fi

say "Webhook reminder"
echo "Ensure WAHA_WEBHOOK_URL points to the Express gateway (e.g., http://host.docker.internal:9876/api/webhooks/waha)."

say "Memory ledger"
ledger_url=$(get_env "$ROOT_ENV_FILE" "MEMORY_DATABASE_URL")
if [ -n "$ledger_url" ]; then
  echo "MEMORY_DATABASE_URL: $(mask "$ledger_url")"
  if node - <<'NODE'
const db = require('../services/memory/db');
db.init()
  .then((ready) => {
    if (ready === false) {
      console.log('Memory DB disabled (init returned false).');
    } else {
      console.log('Memory DB migrations reachable.');
    }
    process.exit(0);
  })
  .catch((error) => {
    console.error('Memory DB init failed:', error.message);
    process.exit(1);
  });
NODE
  then
    echo "Memory DB connectivity: OK"
  else
    echo "Memory DB connectivity: FAIL" >&2
  fi
else
  echo "MEMORY_DATABASE_URL not set — ledger falls back to JSON files."
fi

exit 0
