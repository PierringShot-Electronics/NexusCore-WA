const { Pool } = require("pg");
const { logWithTimestamp } = require("../../utils/logger");

let pool = null;
let initPromise = null;

function toInt(value, fallback) {
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function resolveSslOption() {
  const explicit = process.env.MEMORY_DB_SSL || process.env.PGSSLMODE;
  if (!explicit) return undefined;
  const normalized = explicit.toLowerCase();
  if (["disable", "off", "false", "0"].includes(normalized)) {
    return undefined;
  }
  const rejectUnauthorized =
    process.env.MEMORY_DB_SSL_REJECT_UNAUTHORIZED !== "false";
  return { rejectUnauthorized };
}

function resolveConnectionConfig() {
  const connectionString =
    process.env.MEMORY_DATABASE_URL ||
    process.env.MEMORY_DB_URL ||
    process.env.MEMORY_DB_CONNECTION_STRING;

  if (connectionString) {
    return {
      connectionString,
      ssl: resolveSslOption(),
    };
  }

  const host = process.env.MEMORY_DB_HOST;
  if (!host) {
    return null;
  }

  const port = toInt(process.env.MEMORY_DB_PORT || "5432", 5432);
  const user = process.env.MEMORY_DB_USER;
  const password = process.env.MEMORY_DB_PASSWORD;
  const database = process.env.MEMORY_DB_NAME || "whatcore_ops";

  if (!user || !password) {
    logWithTimestamp(
      "⚠️ MEMORY_DB_HOST təyin olunub, lakin istifadəçi və ya şifrə yoxdur; yaddaş DB deaktiv edilir.",
    );
    return null;
  }

  return {
    host,
    port,
    user,
    password,
    database,
    ssl: resolveSslOption(),
  };
}

function isEnabled() {
  return Boolean(resolveConnectionConfig());
}

function getPool() {
  if (!isEnabled()) {
    throw new Error("Memory database konfiqurasiya edilməyib.");
  }
  if (!pool) {
    pool = new Pool(resolveConnectionConfig());
    pool.on("error", (error) => {
      logWithTimestamp("❌ Memory DB əlaqə xətası:", error.message);
    });
  }
  return pool;
}

async function query(text, params = []) {
  const activePool = getPool();
  const client = await activePool.connect();
  try {
    return await client.query(text, params);
  } finally {
    client.release();
  }
}

async function runSchemaMigrations() {
  await query(`
    CREATE TABLE IF NOT EXISTS contacts (
      contact_id TEXT PRIMARY KEY,
      name TEXT,
      business_name TEXT,
      labels TEXT[],
      language TEXT,
      sentiment_avg NUMERIC,
      last_seen TIMESTAMPTZ,
      raw JSONB,
      updated_at TIMESTAMPTZ DEFAULT NOW()
    );
  `);

  await query(`
    CREATE TABLE IF NOT EXISTS leads (
      lead_id TEXT PRIMARY KEY,
      contact_id TEXT REFERENCES contacts(contact_id) ON DELETE CASCADE,
      status TEXT,
      value_estimate NUMERIC,
      source TEXT,
      notes TEXT,
      updated_at TIMESTAMPTZ DEFAULT NOW(),
      created_at TIMESTAMPTZ DEFAULT NOW()
    );
  `);

  await query(`
    CREATE INDEX IF NOT EXISTS leads_contact_id_idx ON leads(contact_id);
  `);

  await query(`
    CREATE TABLE IF NOT EXISTS chat_memories (
      contact_id TEXT PRIMARY KEY REFERENCES contacts(contact_id) ON DELETE CASCADE,
      summary TEXT,
      topics TEXT[],
      next_steps TEXT,
      updated_at TIMESTAMPTZ DEFAULT NOW()
    );
  `);

  await query(`
    CREATE TABLE IF NOT EXISTS tool_audit (
      audit_id BIGSERIAL PRIMARY KEY,
      call_name TEXT NOT NULL,
      payload JSONB,
      result_status INTEGER,
      result_ok BOOLEAN,
      latency_ms INTEGER,
      model TEXT,
      created_at TIMESTAMPTZ DEFAULT NOW()
    );
  `);
}

async function init() {
  if (!isEnabled()) return false;
  if (!initPromise) {
    initPromise = runSchemaMigrations()
      .then(() => {
        logWithTimestamp("✅ Memory DB sxemi hazırdır (contacts/leads/memories/tool_audit).");
        return true;
      })
      .catch((error) => {
        logWithTimestamp("❌ Memory DB sxemini yaratmaq mümkün olmadı:", error.message);
        throw error;
      });
  }
  return initPromise;
}

module.exports = {
  isEnabled,
  init,
  query,
  getPool,
};
