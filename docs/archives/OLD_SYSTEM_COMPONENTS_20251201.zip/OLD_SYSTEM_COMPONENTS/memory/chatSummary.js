const fs = require("fs-extra");
const path = require("path");
const { logWithTimestamp } = require("../../utils/logger");
const { getGroqProvider } = require("../models/groqProvider");
const memoryRepository = require("./repository");

const SUMMARY_FILE = path.join(__dirname, "..", "..", "data", "chat_summaries.json");
const MIN_HISTORY_FOR_SUMMARY = Number(process.env.SUMMARY_MIN_MESSAGES || 12);

async function loadSummaries() {
  try {
    if (!(await fs.pathExists(SUMMARY_FILE))) {
      await fs.ensureFile(SUMMARY_FILE);
      await fs.writeFile(SUMMARY_FILE, JSON.stringify({}, null, 2));
    }
    const raw = await fs.readFile(SUMMARY_FILE, "utf8");
    return raw.trim() ? JSON.parse(raw) : {};
  } catch (error) {
    logWithTimestamp("❌ Söhbət xülasələri faylı oxunmadı:", error.message);
    return {};
  }
}

async function saveSummaries(data) {
  try {
    await fs.writeFile(SUMMARY_FILE, JSON.stringify(data, null, 2), "utf8");
  } catch (error) {
    logWithTimestamp("❌ Söhbət xülasələri faylı yazılmadı:", error.message);
  }
}

async function getSummary(chatId) {
  if (memoryRepository.isEnabled()) {
    try {
      await memoryRepository.ensureReady();
      return await memoryRepository.getChatSummary(chatId);
    } catch (error) {
      logWithTimestamp(
        "⚠️ Memory DB söhbət xülasəsi oxunmadı, fayl ehtiyatına keçir:",
        error.message,
      );
    }
  }

  const summaries = await loadSummaries();
  return summaries[chatId] || null;
}

async function updateSummary(chatId, payload) {
  if (memoryRepository.isEnabled()) {
    try {
      await memoryRepository.ensureReady();
      return await memoryRepository.upsertChatSummary(chatId, payload);
    } catch (error) {
      logWithTimestamp(
        "⚠️ Memory DB söhbət xülasəsi yazılmadı, fayl ehtiyatına keçir:",
        error.message,
      );
    }
  }

  const summaries = await loadSummaries();
  const next = {
    ...(summaries[chatId] || {}),
    ...payload,
    updatedAt: new Date().toISOString(),
  };
  summaries[chatId] = next;
  await saveSummaries(summaries);
  return next;
}

function formatHistoryForSummary(history) {
  return history
    .slice(-20)
    .map((msg) => {
      const prefix = msg.sender === "assistant" ? "Agent" : "Müştəri";
      return `${prefix}: ${msg.content}`;
    })
    .join("\n");
}

async function ensureConversationSummary(chatId, history) {
  if (!Array.isArray(history) || history.length < MIN_HISTORY_FOR_SUMMARY) {
    return getSummary(chatId);
  }

  const chunks = formatHistoryForSummary(history);
  const provider = getGroqProvider();
  try {
    const response = await provider.chatCompletion({
      model:
        process.env.GROQ_SUMMARY_MODEL ||
        process.env.GROQ_CHAT_MODEL ||
        "llama-3.3-70b-versatile",
      messages: [
        {
          role: "system",
          content:
            "Sən WhatsCore.AI üçün müşahidəçi agentisən. Dialoqu 3-4 cümlə ilə yekunlaşdır və əsas istəyini, qarşıya qoyulan növbəti addımı qeyd et. Sənəd üçün başlıqlar daxil etmə.",
        },
        {
          role: "user",
          content: `Dialoq:\n${chunks}`,
        },
      ],
      max_tokens: 220,
      temperature: 0.15,
    });

    const summaryText =
      response.choices?.[0]?.message?.content?.trim() ||
      "";
    if (summaryText) {
      return updateSummary(chatId, { summary: summaryText });
    }
  } catch (error) {
    logWithTimestamp(
      `⚠️ Söhbət xülasəsi yaradıla bilmədi [${chatId}]:`,
      error.message,
    );
  }

  return getSummary(chatId);
}

module.exports = {
  getSummary,
  updateSummary,
  ensureConversationSummary,
};
