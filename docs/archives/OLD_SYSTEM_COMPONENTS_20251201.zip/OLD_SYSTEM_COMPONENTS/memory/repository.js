const { v4: uuidv4 } = require("uuid");
const { isEnabled, init, query } = require("./db");
const { normalizeChatId } = require("../waha/common");
const { logWithTimestamp } = require("../../utils/logger");

let schemaReady = false;

async function ensureReady() {
  if (!isEnabled()) return false;
  if (!schemaReady) {
    await init();
    schemaReady = true;
  }
  return true;
}

function normalizeContactKey(candidate) {
  if (!candidate) return null;
  return normalizeChatId(candidate.trim());
}

function mapContactRow(row) {
  if (!row) return null;
  return {
    contactId: row.contact_id,
    name: row.name,
    businessName: row.business_name,
    labels: row.labels || [],
    language: row.language || null,
    sentimentAvg: row.sentiment_avg !== null ? Number(row.sentiment_avg) : null,
    lastSeen: row.last_seen ? new Date(row.last_seen).toISOString() : null,
    updatedAt: row.updated_at ? new Date(row.updated_at).toISOString() : null,
    raw: row.raw || null,
  };
}

function mapLeadRow(row) {
  if (!row) return null;
  return {
    leadId: row.lead_id,
    contactId: row.contact_id,
    status: row.status,
    valueEstimate: row.value_estimate !== null ? Number(row.value_estimate) : null,
    source: row.source,
    notes: row.notes,
    updatedAt: row.updated_at ? new Date(row.updated_at).toISOString() : null,
    createdAt: row.created_at ? new Date(row.created_at).toISOString() : null,
  };
}

async function upsertContact(contactId, payload = {}) {
  if (!isEnabled()) return null;
  await ensureReady();

  const resolvedId = normalizeContactKey(contactId || payload.contactId);
  if (!resolvedId) {
    throw new Error("contactId tələb olunur.");
  }

  const labels = Array.isArray(payload.labels)
    ? payload.labels.filter(Boolean)
    : null;

  const sentiment = payload.sentimentAvg ?? payload.sentiment;
  const lastSeen = payload.lastSeen ? new Date(payload.lastSeen) : null;

  const result = await query(
    `INSERT INTO contacts (contact_id, name, business_name, labels, language, sentiment_avg, last_seen, raw, updated_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8::jsonb, NOW())
     ON CONFLICT (contact_id)
     DO UPDATE SET
        name = EXCLUDED.name,
        business_name = EXCLUDED.business_name,
        labels = EXCLUDED.labels,
        language = COALESCE(EXCLUDED.language, contacts.language),
        sentiment_avg = COALESCE(EXCLUDED.sentiment_avg, contacts.sentiment_avg),
        last_seen = COALESCE(EXCLUDED.last_seen, contacts.last_seen),
        raw = COALESCE(EXCLUDED.raw, contacts.raw),
        updated_at = NOW()
     RETURNING *;`,
    [
      resolvedId,
      payload.name || null,
      payload.businessName || payload.company || null,
      labels,
      payload.language || null,
      sentiment !== undefined ? Number(sentiment) : null,
      lastSeen,
      payload.raw ? JSON.stringify(payload.raw) : JSON.stringify(payload || {}),
    ],
  );

  return mapContactRow(result.rows[0]);
}

async function getContact(contactId) {
  if (!isEnabled()) return null;
  await ensureReady();

  const resolvedId = normalizeContactKey(contactId);
  if (!resolvedId) return null;

  const result = await query(
    `SELECT * FROM contacts WHERE contact_id = $1 LIMIT 1;`,
    [resolvedId],
  );
  return mapContactRow(result.rows[0]);
}

async function listContacts({ limit = 50 } = {}) {
  if (!isEnabled()) return [];
  await ensureReady();

  const safeLimit = Math.max(1, Math.min(Number(limit) || 50, 200));
  const result = await query(
    `SELECT * FROM contacts ORDER BY updated_at DESC LIMIT $1;`,
    [safeLimit],
  );
  return result.rows.map(mapContactRow);
}

async function upsertChatSummary(contactId, payload) {
  if (!isEnabled()) return null;
  await ensureReady();

  const resolvedId = normalizeContactKey(contactId);
  if (!resolvedId) return null;

  await query(
    `INSERT INTO chat_memories (contact_id, summary, topics, next_steps, updated_at)
     VALUES ($1, $2, $3, $4, NOW())
     ON CONFLICT (contact_id)
     DO UPDATE SET
       summary = EXCLUDED.summary,
       topics = EXCLUDED.topics,
       next_steps = EXCLUDED.next_steps,
       updated_at = NOW();`,
    [
      resolvedId,
      payload.summary || null,
      Array.isArray(payload.topics) ? payload.topics.filter(Boolean) : null,
      payload.nextSteps || payload.next_steps || null,
    ],
  );

  return getChatSummary(resolvedId);
}

async function getChatSummary(contactId) {
  if (!isEnabled()) return null;
  await ensureReady();

  const resolvedId = normalizeContactKey(contactId);
  if (!resolvedId) return null;

  const result = await query(
    `SELECT * FROM chat_memories WHERE contact_id = $1 LIMIT 1;`,
    [resolvedId],
  );
  const record = result.rows[0];
  if (!record) return null;
  return {
    contactId: resolvedId,
    summary: record.summary || null,
    topics: record.topics || [],
    nextSteps: record.next_steps || null,
    updatedAt: record.updated_at ? new Date(record.updated_at).toISOString() : null,
  };
}

async function upsertLead(contactId, payload = {}) {
  if (!isEnabled()) return null;
  await ensureReady();

  const resolvedId = normalizeContactKey(contactId || payload.contactId);
  if (!resolvedId) return null;

  const leadId = payload.leadId || payload.lead_id || uuidv4();
  const result = await query(
    `INSERT INTO leads (lead_id, contact_id, status, value_estimate, source, notes, updated_at)
     VALUES ($1, $2, $3, $4, $5, $6, NOW())
     ON CONFLICT (lead_id)
     DO UPDATE SET
       status = COALESCE(EXCLUDED.status, leads.status),
       value_estimate = COALESCE(EXCLUDED.value_estimate, leads.value_estimate),
       source = COALESCE(EXCLUDED.source, leads.source),
       notes = COALESCE(EXCLUDED.notes, leads.notes),
       updated_at = NOW()
     RETURNING *;`,
    [
      leadId,
      resolvedId,
      payload.status || "open",
      payload.valueEstimate !== undefined
        ? Number(payload.valueEstimate)
        : payload.value_estimate !== undefined
          ? Number(payload.value_estimate)
          : null,
      payload.source || null,
      payload.notes || null,
    ],
  );

  return mapLeadRow(result.rows[0]);
}

async function listLeadsByContact(contactId) {
  if (!isEnabled()) return [];
  await ensureReady();

  const resolvedId = normalizeContactKey(contactId);
  if (!resolvedId) return [];

  const result = await query(
    `SELECT * FROM leads WHERE contact_id = $1 ORDER BY updated_at DESC LIMIT 20;`,
    [resolvedId],
  );
  return result.rows.map(mapLeadRow);
}

async function recordToolAudit({ callName, payload, result, latencyMs, model }) {
  if (!isEnabled()) return false;
  await ensureReady();

  try {
    await query(
      `INSERT INTO tool_audit (call_name, payload, result_status, result_ok, latency_ms, model)
       VALUES ($1, $2::jsonb, $3, $4, $5, $6);`,
      [
        callName,
        payload ? JSON.stringify(payload) : JSON.stringify({}),
        result?.status || null,
        result?.ok ?? null,
        latencyMs !== undefined ? Math.round(latencyMs) : null,
        model || null,
      ],
    );
    return true;
  } catch (error) {
    logWithTimestamp("⚠️ Tool audit yazıla bilmədi:", error.message);
    return false;
  }
}

async function fetchContactBundle(contactId) {
  if (!isEnabled()) return null;
  await ensureReady();

  const contact = await getContact(contactId);
  if (!contact) {
    return {
      contact: null,
      memory: null,
      leads: [],
    };
  }

  const memory = await getChatSummary(contact.contactId);
  const leads = await listLeadsByContact(contact.contactId);
  return { contact, memory, leads };
}

module.exports = {
  ensureReady,
  isEnabled,
  upsertContact,
  getContact,
  listContacts,
  upsertChatSummary,
  getChatSummary,
  upsertLead,
  listLeadsByContact,
  recordToolAudit,
  fetchContactBundle,
};
