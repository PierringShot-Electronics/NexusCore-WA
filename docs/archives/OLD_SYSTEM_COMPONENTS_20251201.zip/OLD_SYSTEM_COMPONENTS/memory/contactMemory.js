const fs = require("fs-extra");
const path = require("path");
const { logWithTimestamp } = require("../../utils/logger");
const memoryRepository = require("./repository");

const MEMORY_FILE = path.join(__dirname, "..", "..", "data", "contacts.json");

async function loadMemoryFile() {
  try {
    if (!(await fs.pathExists(MEMORY_FILE))) {
      await fs.ensureFile(MEMORY_FILE);
      await fs.writeFile(MEMORY_FILE, JSON.stringify({}, null, 2));
    }
    const raw = await fs.readFile(MEMORY_FILE, "utf8");
    return raw.trim() ? JSON.parse(raw) : {};
  } catch (error) {
    logWithTimestamp("❌ Kontakt yaddaşını oxumaq mümkün olmadı:", error.message);
    return {};
  }
}

async function saveMemoryFile(memory) {
  try {
    await fs.writeFile(MEMORY_FILE, JSON.stringify(memory, null, 2), "utf8");
  } catch (error) {
    logWithTimestamp("❌ Kontakt yaddaşını yazmaq mümkün olmadı:", error.message);
  }
}

async function upsertContact(chatId, payload = {}) {
  if (memoryRepository.isEnabled()) {
    try {
      await memoryRepository.ensureReady();
      return await memoryRepository.upsertContact(chatId, payload);
    } catch (error) {
      logWithTimestamp(
        "⚠️ Memory DB kontakt yazılmadı, fayl ehtiyatına keçir:",
        error.message,
      );
    }
  }

  const memory = await loadMemoryFile();
  const existing = memory[chatId] || {};
  const updated = {
    ...existing,
    ...payload,
    chatId,
    updatedAt: new Date().toISOString(),
  };
  memory[chatId] = updated;
  await saveMemoryFile(memory);
  return updated;
}

async function getContact(chatId) {
  if (memoryRepository.isEnabled()) {
    try {
      await memoryRepository.ensureReady();
      return await memoryRepository.getContact(chatId);
    } catch (error) {
      logWithTimestamp(
        "⚠️ Memory DB kontakt oxunmadı, fayl ehtiyatına keçir:",
        error.message,
      );
    }
  }

  const memory = await loadMemoryFile();
  return memory[chatId] || null;
}

async function listContacts() {
  if (memoryRepository.isEnabled()) {
    try {
      await memoryRepository.ensureReady();
      return await memoryRepository.listContacts();
    } catch (error) {
      logWithTimestamp(
        "⚠️ Memory DB kontakt siyahısı oxunmadı, fayl ehtiyatına keçir:",
        error.message,
      );
    }
  }

  const memory = await loadMemoryFile();
  return Object.values(memory);
}

module.exports = {
  upsertContact,
  getContact,
  listContacts,
};
