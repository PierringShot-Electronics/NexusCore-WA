const { sessionCommand } = require("./common");

async function sendEvent({ session, event }) {
  if (!event || typeof event !== "object") {
    throw new Error("Event məlumatı tələb olunur.");
  }
  return sessionCommand({
    session,
    endpoint: "/api/:session/events",
    method: "POST",
    payload: event,
  });
}

module.exports = {
  sendEvent,
};
