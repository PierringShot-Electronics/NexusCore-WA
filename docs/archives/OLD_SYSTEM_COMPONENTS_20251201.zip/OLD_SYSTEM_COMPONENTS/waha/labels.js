const { sessionRequest, sessionCommand } = require("./common");

async function listLabels({ session } = {}) {
  return sessionRequest({
    session,
    path: "/api/:session/labels",
    method: "GET",
  });
}

async function createLabel({ session, label }) {
  if (!label || typeof label !== "object") {
    throw new Error("Label məlumatı tələb olunur.");
  }
  return sessionCommand({
    session,
    endpoint: "/api/:session/labels",
    method: "POST",
    payload: label,
  });
}

async function updateLabel({ session, labelId, label }) {
  if (!labelId) throw new Error("labelId tələb olunur.");
  if (!label || typeof label !== "object") {
    throw new Error("Label məlumatı tələb olunur.");
  }
  return sessionCommand({
    session,
    endpoint: `/api/:session/labels/${encodeURIComponent(labelId)}`,
    method: "PUT",
    payload: label,
  });
}

async function deleteLabel({ session, labelId }) {
  if (!labelId) throw new Error("labelId tələb olunur.");
  return sessionCommand({
    session,
    endpoint: `/api/:session/labels/${encodeURIComponent(labelId)}`,
    method: "DELETE",
  });
}

async function getChatLabels({ session, chatId }) {
  if (!chatId) throw new Error("chatId tələb olunur.");
  return sessionRequest({
    session,
    path: `/api/:session/labels/chats/${encodeURIComponent(chatId)}`,
    method: "GET",
  });
}

async function setChatLabels({ session, chatId, labels }) {
  if (!chatId) throw new Error("chatId tələb olunur.");
  if (!Array.isArray(labels)) throw new Error("labels massiv formatında olmalıdır.");
  return sessionCommand({
    session,
    endpoint: `/api/:session/labels/chats/${encodeURIComponent(chatId)}`,
    method: "PUT",
    payload: { labels },
  });
}

async function listLabelChats({ session, labelId }) {
  if (!labelId) throw new Error("labelId tələb olunur.");
  return sessionRequest({
    session,
    path: `/api/:session/labels/${encodeURIComponent(labelId)}/chats`,
    method: "GET",
  });
}

module.exports = {
  listLabels,
  createLabel,
  updateLabel,
  deleteLabel,
  getChatLabels,
  setChatLabels,
  listLabelChats,
};
