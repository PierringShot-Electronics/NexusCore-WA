const messages = require("./messages");
const sessions = require("./sessions");
const chats = require("./chats");
const contacts = require("./contacts");
const presence = require("./presence");
const groups = require("./groups");
const status = require("./status");
const channels = require("./channels");
const media = require("./media");
const apps = require("./apps");
const auth = require("./auth");
const profile = require("./profile");
const labels = require("./labels");
const events = require("./events");
const {
  sendToolCommand,
  request,
  getConfig,
} = require("../toolkit/wahaClient");
const {
  ensureSession,
  normalizeChatId,
} = require("./common");
const { logWithTimestamp } = require("../../utils/logger");

const STRIP_HEADERS = new Set([
  "host",
  "connection",
  "content-length",
  "accept-encoding",
  "origin",
]);

function sendMedia(options) {
  const mediaType = options?.mediaType;
  if (mediaType === "image") return messages.sendImage(options);
  if (mediaType === "video") return messages.sendVideo(options);
  if (mediaType === "audio") return messages.sendAudio(options);
  if (mediaType === "voice") return messages.sendVoice(options);
  if (mediaType === "document") return messages.sendFile(options);
  return messages.sendFile(options);
}

function markChat({ chatId, action, session }) {
  if (action === "read") {
    return chats.markChatRead({ session, chatId });
  }
  if (action === "unread") {
    return chats.markChatUnread({ session, chatId });
  }
  throw new Error(`Naməlum mark action: ${action}`);
}

async function getSessionStatus({ session, verbose = false } = {}) {
  return sessions.getSession({ session, verbose });
}

async function startSession({ session, config, restart = false } = {}) {
  if (restart) {
    return sessions.restartSession({ session });
  }
  return sessions.createSession({ session, config, start: true });
}

async function getSessionQRCode({ session, format = "data" } = {}) {
  const resolvedSession = ensureSession(session);
  return request({
    method: "GET",
    path: "/api/screenshot",
    query: { session: resolvedSession, format },
    headers: { Accept: format === "base64" ? "text/plain" : "image/png" },
  });
}

function fetchContacts(args) {
  return contacts.listContacts(args);
}

function logResult(prefix, result) {
  if (!result) return;
  if (result.ok) {
    logWithTimestamp(`${prefix} uğurludur (status ${result.status}).`);
  } else {
    logWithTimestamp(
      `${prefix} xətası: ${result.status} ${result.error || ""}`,
    );
  }
}

function sanitizeHeaders(headers = {}) {
  return Object.entries(headers).reduce((acc, [key, value]) => {
    const lower = key.toLowerCase();
    if (STRIP_HEADERS.has(lower)) {
      return acc;
    }
    acc[key] = value;
    return acc;
  }, {});
}

function pathWithLeadingSlash(path) {
  if (!path) {
    throw new Error("WAHA proxy path tələb olunur.");
  }
  return path.startsWith("/") ? path : `/${path}`;
}

function shouldInjectSession(pathname) {
  if (!pathname.startsWith("/api")) return false;
  if (pathname.startsWith("/api/sessions")) return false;
  if (pathname.startsWith("/api/auth")) return false;
  return true;
}

async function proxyRawRequest({
  method,
  path,
  query,
  body,
  headers,
  session,
  injectSession = true,
}) {
  const safePath = pathWithLeadingSlash(path);
  const safeHeaders = sanitizeHeaders(headers);
  const methodUpper = String(method || "GET").toUpperCase();
  let payload = body;

  if (methodUpper === "GET" || methodUpper === "HEAD") {
    payload = undefined;
    delete safeHeaders["content-type"];
    delete safeHeaders["Content-Type"];
  }

  const canInject =
    injectSession &&
    shouldInjectSession(safePath) &&
    payload &&
    typeof payload === "object" &&
    !Array.isArray(payload);

  if (canInject && payload.session === undefined) {
    payload = {
      ...payload,
      session: ensureSession(session),
    };
  }

  const finalQuery = { ...query };
  if (shouldInjectSession(safePath) && finalQuery.session === undefined) {
    try {
      finalQuery.session = ensureSession(session);
    } catch (error) {
      // session may be optional; ignore
    }
  }

  return request({
    method,
    path: safePath,
    query: finalQuery,
    body: payload,
    headers: safeHeaders,
  });
}

function isWahaConfigured() {
  const { baseUrl } = getConfig();
  return Boolean(baseUrl);
}

module.exports = {
  // Aggregated domain modules
  ...messages,
  ...sessions,
  ...chats,
  ...contacts,
  ...presence,
  ...groups,
  ...status,
  ...channels,
  ...media,
  ...apps,
  ...auth,
  ...profile,
  ...labels,
  ...events,
  // Compatibility aliases
  sendMedia,
  markChat,
  fetchContacts,
  getSessionStatus,
  startSession,
  getSessionQRCode,
  logResult,
  proxyRawRequest,
  isWahaConfigured,
  sendToolCommand,
  request,
  getConfig,
  normalizeChatId,
};
