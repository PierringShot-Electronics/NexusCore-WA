const {
  ensureSession,
  normalizeChatId,
  sanitizePhone,
  sessionCommand,
  sessionRequest,
  buildPath,
} = require("./common");
const { buildPaginationParams } = require("../toolkit/wahaClient");

function resolveContactId({ chatId, number }) {
  if (chatId) return normalizeChatId(chatId);
  if (number) return normalizeChatId(number);
  throw new Error("contact chatId və ya number tələb olunur.");
}

async function listContacts({ session, limit, cursor } = {}) {
  const query = buildPaginationParams({ limit, cursor });
  return sessionRequest({ session, path: "/api/:session/contacts", method: "GET", query });
}

async function getContact({ session, chatId, number }) {
  const contactId = encodeURIComponent(resolveContactId({ chatId, number }));
  const path = buildPath("/api/:session/contacts/:contactId", {
    session: ensureSession(session),
    contactId,
  });
  return sessionRequest({ session, path, method: "GET" });
}

async function getContactAbout({ session, chatId, number }) {
  const contactId = encodeURIComponent(resolveContactId({ chatId, number }));
  const path = buildPath("/api/:session/contacts/:contactId/about", {
    session: ensureSession(session),
    contactId,
  });
  return sessionRequest({ session, path, method: "GET" });
}

async function setContactLabel({ session, chatId, number, labels }) {
  if (!Array.isArray(labels)) throw new Error("labels massiv tələb olunur.");
  const contactId = encodeURIComponent(resolveContactId({ chatId, number }));
  const endpoint = buildPath("/api/:session/contacts/:contactId/labels", {
    session: ensureSession(session),
    contactId,
  });
  return sessionCommand({
    session,
    endpoint,
    method: "POST",
    payload: { labels },
  });
}

async function checkNumberStatus({ session, number }) {
  if (!number) throw new Error("number tələb olunur.");
  const normalized = sanitizePhone(number);
  return sessionRequest({
    session,
    path: "/api/:session/check-number-status",
    method: "POST",
    body: { phones: [normalized] },
  });
}

async function blockContact({ session, chatId, number }) {
  const contactId = encodeURIComponent(resolveContactId({ chatId, number }));
  const endpoint = buildPath("/api/:session/contacts/:contactId/block", {
    session: ensureSession(session),
    contactId,
  });
  return sessionCommand({ session, endpoint, method: "POST" });
}

async function unblockContact({ session, chatId, number }) {
  const contactId = encodeURIComponent(resolveContactId({ chatId, number }));
  const endpoint = buildPath("/api/:session/contacts/:contactId/unblock", {
    session: ensureSession(session),
    contactId,
  });
  return sessionCommand({ session, endpoint, method: "POST" });
}

async function getProfilePicture({ session, chatId, number, format = "json" }) {
  const contactId = encodeURIComponent(resolveContactId({ chatId, number }));
  const path = buildPath("/api/:session/contacts/:contactId/profile-picture", {
    session: ensureSession(session),
    contactId,
  });
  const query = format === "image" ? { format: "image" } : undefined;
  return sessionRequest({ session, path, method: "GET", query });
}

module.exports = {
  listContacts,
  getContact,
  getContactAbout,
  setContactLabel,
  checkNumberStatus,
  blockContact,
  unblockContact,
  getProfilePicture,
};
