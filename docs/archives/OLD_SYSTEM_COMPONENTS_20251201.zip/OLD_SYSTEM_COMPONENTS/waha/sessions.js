const { request } = require("../toolkit/wahaClient");
const { ensureSession, sessionRequest } = require("./common");

async function listSessions({ verbose = false } = {}) {
  return request({ method: "GET", path: "/api/sessions", query: verbose ? { verbose: "true" } : undefined });
}

async function getSession({ session, verbose = false }) {
  return sessionRequest({
    session,
    path: "/api/sessions/:session",
    method: "GET",
    query: verbose ? { verbose: "true" } : undefined,
  });
}

async function createSession({ session, config, start = true }) {
  const name = ensureSession(session);
  const payload = {
    name,
    start,
  };
  if (config && typeof config === "object") {
    payload.config = config;
  }
  return request({ method: "POST", path: "/api/sessions", body: payload });
}

async function restartSession({ session }) {
  return sessionRequest({
    session,
    path: "/api/sessions/:session/restart",
    method: "POST",
  });
}

async function stopSession({ session }) {
  return sessionRequest({
    session,
    path: "/api/sessions/:session/stop",
    method: "POST",
  });
}

async function logoutSession({ session }) {
  return sessionRequest({
    session,
    path: "/api/sessions/:session/logout",
    method: "POST",
  });
}

async function deleteSession({ session }) {
  return sessionRequest({
    session,
    path: "/api/sessions/:session",
    method: "DELETE",
  });
}

async function getSessionProfile({ session }) {
  return sessionRequest({
    session,
    path: "/api/:session/profile",
    method: "GET",
  });
}

async function getSessionMe({ session }) {
  return sessionRequest({
    session,
    path: "/api/sessions/:session/me",
    method: "GET",
  });
}

async function getAuthCode({ session }) {
  return sessionRequest({
    session,
    path: "/api/sessions/:session/register",
    method: "POST",
  });
}

module.exports = {
  listSessions,
  getSession,
  createSession,
  restartSession,
  stopSession,
  logoutSession,
  deleteSession,
  getSessionProfile,
  getSessionMe,
  getAuthCode,
};
