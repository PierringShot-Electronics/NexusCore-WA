const {
  ensureSession,
  sessionCommand,
  sessionRequest,
  buildPath,
} = require("./common");
const { buildMediaPayload } = require("../toolkit/wahaClient");

async function listStatus({ session }) {
  return sessionRequest({ session, path: "/api/:session/status", method: "GET" });
}

async function postTextStatus({ session, text, backgroundColor, font }) {
  if (!text) throw new Error("text tələb olunur.");
  return sessionCommand({
    session,
    endpoint: "/api/:session/status/text",
    method: "POST",
    payload: { text, backgroundColor, font },
  });
}

async function postImageStatus({ session, mediaUrl, mediaBase64, caption, mimeType, fileName }) {
  const payload = buildMediaPayload({
    session: ensureSession(session),
    mediaUrl,
    mediaBase64,
    caption,
    mimeType,
    fileName,
  });
  return sessionCommand({
    session,
    endpoint: "/api/:session/status/image",
    method: "POST",
    payload,
  });
}

async function postVideoStatus({ session, mediaUrl, mediaBase64, caption, mimeType, fileName }) {
  const payload = buildMediaPayload({
    session: ensureSession(session),
    mediaUrl,
    mediaBase64,
    caption,
    mimeType,
    fileName,
  });
  return sessionCommand({
    session,
    endpoint: "/api/:session/status/video",
    method: "POST",
    payload,
  });
}

async function deleteStatus({ session, statusId }) {
  if (!statusId) throw new Error("statusId tələb olunur.");
  const endpoint = buildPath("/api/:session/status/:statusId", {
    session: ensureSession(session),
    statusId,
  });
  return sessionCommand({ session, endpoint, method: "DELETE" });
}

module.exports = {
  listStatus,
  postTextStatus,
  postImageStatus,
  postVideoStatus,
  deleteStatus,
};
