const { sessionRequest, sessionCommand } = require("./common");

async function getQr({ session, format = "json" } = {}) {
  return sessionRequest({
    session,
    path: "/api/:session/auth/qr",
    method: "GET",
    query: { format },
  });
}

async function requestCode({ session, channel, phone }) {
  if (!channel) throw new Error("Auth request üçün channel tələb olunur.");
  return sessionCommand({
    session,
    endpoint: "/api/:session/auth/request-code",
    method: "POST",
    payload: { channel, phone },
  });
}

module.exports = {
  getQr,
  requestCode,
};
