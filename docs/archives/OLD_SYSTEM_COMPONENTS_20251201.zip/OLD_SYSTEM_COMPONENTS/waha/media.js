const {
  ensureSession,
  sessionRequest,
  buildPath,
} = require("./common");

function encodeMessageId(messageId) {
  if (!messageId) throw new Error("messageId tələb olunur.");
  return encodeURIComponent(messageId);
}

async function downloadMessageMedia({ session, messageId, format = "binary" }) {
  const path = buildPath("/api/:session/messages/:messageId/download", {
    session: ensureSession(session),
    messageId: encodeMessageId(messageId),
  });
  const query = format === "json" ? { format: "json" } : undefined;
  return sessionRequest({ session, path, method: "GET", query });
}

async function retryMediaDownload({ session, messageId }) {
  const path = buildPath("/api/:session/messages/:messageId/download/retry", {
    session: ensureSession(session),
    messageId: encodeMessageId(messageId),
  });
  return sessionRequest({ session, path, method: "POST" });
}

module.exports = {
  downloadMessageMedia,
  retryMediaDownload,
};
