const {
  ensureSession,
  sessionCommand,
  sessionRequest,
  buildPath,
} = require("./common");
const { buildPaginationParams } = require("../toolkit/wahaClient");

function encodeChannelId(channelId) {
  if (!channelId) throw new Error("channelId tələb olunur.");
  return encodeURIComponent(channelId);
}

async function listChannels({ session, limit, cursor } = {}) {
  const query = buildPaginationParams({ limit, cursor });
  return sessionRequest({ session, path: "/api/:session/channels", method: "GET", query });
}

async function getChannel({ session, channelId }) {
  const path = buildPath("/api/:session/channels/:channelId", {
    session: ensureSession(session),
    channelId: encodeChannelId(channelId),
  });
  return sessionRequest({ session, path, method: "GET" });
}

async function followChannel({ session, channelId }) {
  const endpoint = buildPath("/api/:session/channels/:channelId/follow", {
    session: ensureSession(session),
    channelId: encodeChannelId(channelId),
  });
  return sessionCommand({ session, endpoint, method: "POST" });
}

async function unfollowChannel({ session, channelId }) {
  const endpoint = buildPath("/api/:session/channels/:channelId/follow", {
    session: ensureSession(session),
    channelId: encodeChannelId(channelId),
  });
  return sessionCommand({ session, endpoint, method: "DELETE" });
}

async function muteChannel({ session, channelId, durationMs }) {
  const endpoint = buildPath("/api/:session/channels/:channelId/mute", {
    session: ensureSession(session),
    channelId: encodeChannelId(channelId),
  });
  const payload = durationMs ? { durationMs } : undefined;
  return sessionCommand({ session, endpoint, method: "POST", payload });
}

async function unmuteChannel({ session, channelId }) {
  const endpoint = buildPath("/api/:session/channels/:channelId/mute", {
    session: ensureSession(session),
    channelId: encodeChannelId(channelId),
  });
  return sessionCommand({ session, endpoint, method: "DELETE" });
}

async function getChannelPosts({ session, channelId, limit, cursor }) {
  const path = buildPath("/api/:session/channels/:channelId/posts", {
    session: ensureSession(session),
    channelId: encodeChannelId(channelId),
  });
  const query = buildPaginationParams({ limit, cursor });
  return sessionRequest({ session, path, method: "GET", query });
}

module.exports = {
  listChannels,
  getChannel,
  followChannel,
  unfollowChannel,
  muteChannel,
  unmuteChannel,
  getChannelPosts,
};
