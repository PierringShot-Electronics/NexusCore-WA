const { request, getConfig, sendToolCommand } = require("../toolkit/wahaClient");
const { logWithTimestamp } = require("../../utils/logger");

function ensureSession(sessionOverride) {
  const { session } = getConfig();
  const resolved = sessionOverride || session;
  if (!resolved) {
    throw new Error("WAHA_SESSION konfiqurasiya edilməyib.");
  }
  return resolved;
}

function normalizeChatId(candidate) {
  if (!candidate) return candidate;
  return candidate.includes("@") ? candidate : `${candidate}@c.us`;
}

function sanitizePhone(phone) {
  if (!phone) return phone;
  return phone.replace(/[^0-9]/g, "");
}

function buildPath(template, replacements = {}) {
  let resolved = template;
  Object.entries(replacements).forEach(([key, value]) => {
    const token = `:${key}`;
    const safeValue = encodeURIComponent(value);
    resolved = resolved.split(token).join(safeValue);
  });
  return resolved;
}

async function sessionRequest({
  session,
  path,
  method = "GET",
  query,
  body,
  headers,
}) {
  const resolvedSession = ensureSession(session);
  const finalPath = buildPath(path, { session: resolvedSession });
  const response = await request({
    method,
    path: finalPath,
    query,
    body,
    headers,
  });
  if (!response.ok) {
    logWithTimestamp(
      `⚠️ WAHA cavabı (${method} ${finalPath}) status ${response.status}: ${response.error || ""}`,
    );
  }
  return response;
}

async function sessionCommand({
  session,
  endpoint,
  method = "POST",
  payload,
  query,
  headers,
}) {
  const resolvedSession = ensureSession(session);
  const finalEndpoint = buildPath(endpoint, { session: resolvedSession });
  const response = await sendToolCommand({
    method,
    endpoint: finalEndpoint,
    payload,
    query,
    headers,
  });
  if (!response.ok) {
    logWithTimestamp(
      `⚠️ WAHA komanda cavabı (${method} ${finalEndpoint}) status ${response.status}: ${response.error || ""}`,
    );
  }
  return response;
}

module.exports = {
  ensureSession,
  normalizeChatId,
  sanitizePhone,
  buildPath,
  sessionRequest,
  sessionCommand,
};
