const { ensureSession, sessionRequest, sessionCommand } = require("./common");

async function listApps({ session } = {}) {
  const resolvedSession = ensureSession(session);
  return sessionRequest({
    session: resolvedSession,
    path: "/api/apps",
    method: "GET",
    query: { session: resolvedSession },
  });
}

async function createApp({ session, payload }) {
  const resolvedSession = ensureSession(session);
  if (!payload || typeof payload !== "object") {
    throw new Error("App məlumatı tələb olunur.");
  }
  return sessionCommand({
    session: resolvedSession,
    endpoint: "/api/apps",
    method: "POST",
    payload: { session: resolvedSession, ...payload },
  });
}

async function getApp({ session, id }) {
  if (!id) throw new Error("App ID tələb olunur.");
  const resolvedSession = ensureSession(session);
  return sessionRequest({
    session: resolvedSession,
    path: `/api/apps/${encodeURIComponent(id)}`,
    method: "GET",
    query: { session: resolvedSession },
  });
}

async function updateApp({ session, id, payload }) {
  if (!id) throw new Error("App ID tələb olunur.");
  if (!payload || typeof payload !== "object") {
    throw new Error("App məlumatı tələb olunur.");
  }
  const resolvedSession = ensureSession(session);
  return sessionCommand({
    session: resolvedSession,
    endpoint: `/api/apps/${encodeURIComponent(id)}`,
    method: "PUT",
    payload: { session: resolvedSession, ...payload },
  });
}

async function deleteApp({ session, id }) {
  if (!id) throw new Error("App ID tələb olunur.");
  const resolvedSession = ensureSession(session);
  return sessionCommand({
    session: resolvedSession,
    endpoint: `/api/apps/${encodeURIComponent(id)}`,
    method: "DELETE",
    payload: { session: resolvedSession },
  });
}

async function listChatwootLocales({ session } = {}) {
  const resolvedSession = ensureSession(session);
  return sessionRequest({
    session: resolvedSession,
    path: "/api/apps/chatwoot/locales",
    method: "GET",
    query: { session: resolvedSession },
  });
}

module.exports = {
  listApps,
  createApp,
  getApp,
  updateApp,
  deleteApp,
  listChatwootLocales,
};
