const { buildPaginationParams } = require("../toolkit/wahaClient");
const { ensureSession, normalizeChatId, sessionCommand, sessionRequest, buildPath } = require("./common");

function resolveChatId(chatId) {
  if (!chatId) throw new Error("chatId tələb olunur.");
  return normalizeChatId(chatId);
}

function resolveMessageId(messageId) {
  if (!messageId) throw new Error("messageId tələb olunur.");
  return messageId;
}

async function listChats({ session, limit, cursor, overview = false } = {}) {
  const path = overview
    ? "/api/:session/chats/overview"
    : "/api/:session/chats";
  const query = buildPaginationParams({ limit, cursor });
  return sessionRequest({ session, path, method: "GET", query });
}

async function getChat({ session, chatId }) {
  const path = buildPath("/api/:session/chats/:chatId", {
    session: ensureSession(session),
    chatId: resolveChatId(chatId),
  });
  return sessionRequest({ session, path, method: "GET" });
}

async function getChatMessages({ session, chatId, limit, cursor, withMedia = false }) {
  const path = buildPath("/api/:session/chats/:chatId/messages", {
    session: ensureSession(session),
    chatId: resolveChatId(chatId),
  });
  const query = buildPaginationParams({ limit, cursor });
  if (withMedia) query.withMedia = "true";
  return sessionRequest({ session, path, method: "GET", query });
}

async function deleteChat({ session, chatId }) {
  const path = buildPath("/api/:session/chats/:chatId", {
    session: ensureSession(session),
    chatId: resolveChatId(chatId),
  });
  return sessionRequest({ session, path, method: "DELETE" });
}

async function clearChat({ session, chatId }) {
  const path = buildPath("/api/:session/chats/:chatId/messages", {
    session: ensureSession(session),
    chatId: resolveChatId(chatId),
  });
  return sessionRequest({ session, path, method: "DELETE" });
}

async function deleteMessage({ session, chatId, messageId, forEveryone = true }) {
  const path = buildPath("/api/:session/chats/:chatId/messages/:messageId", {
    session: ensureSession(session),
    chatId: resolveChatId(chatId),
    messageId: resolveMessageId(messageId),
  });
  return sessionCommand({
    session,
    endpoint: path,
    method: "DELETE",
    payload: { forEveryone },
  });
}

async function editMessage({ session, chatId, messageId, text }) {
  if (!text) throw new Error("text tələb olunur.");
  const path = buildPath("/api/:session/chats/:chatId/messages/:messageId", {
    session: ensureSession(session),
    chatId: resolveChatId(chatId),
    messageId: resolveMessageId(messageId),
  });
  return sessionCommand({
    session,
    endpoint: path,
    method: "PUT",
    payload: { text },
  });
}

async function markChatRead({ session, chatId, messageId }) {
  const path = buildPath("/api/:session/chats/:chatId/messages/read", {
    session: ensureSession(session),
    chatId: resolveChatId(chatId),
  });
  const payload = messageId ? { messageId } : undefined;
  return sessionCommand({ session, endpoint: path, method: "POST", payload });
}

async function markChatUnread({ session, chatId }) {
  const path = buildPath("/api/:session/chats/:chatId/unread", {
    session: ensureSession(session),
    chatId: resolveChatId(chatId),
  });
  return sessionCommand({ session, endpoint: path, method: "POST" });
}

async function archiveChat({ session, chatId }) {
  const path = buildPath("/api/:session/chats/:chatId/archive", {
    session: ensureSession(session),
    chatId: resolveChatId(chatId),
  });
  return sessionCommand({ session, endpoint: path, method: "POST" });
}

async function unarchiveChat({ session, chatId }) {
  const path = buildPath("/api/:session/chats/:chatId/unarchive", {
    session: ensureSession(session),
    chatId: resolveChatId(chatId),
  });
  return sessionCommand({ session, endpoint: path, method: "POST" });
}

async function pinMessage({ session, chatId, messageId }) {
  const path = buildPath("/api/:session/chats/:chatId/messages/:messageId/pin", {
    session: ensureSession(session),
    chatId: resolveChatId(chatId),
    messageId: resolveMessageId(messageId),
  });
  return sessionCommand({ session, endpoint: path, method: "POST" });
}

async function unpinMessage({ session, chatId, messageId }) {
  const path = buildPath("/api/:session/chats/:chatId/messages/:messageId/unpin", {
    session: ensureSession(session),
    chatId: resolveChatId(chatId),
    messageId: resolveMessageId(messageId),
  });
  return sessionCommand({ session, endpoint: path, method: "POST" });
}

module.exports = {
  listChats,
  getChat,
  getChatMessages,
  deleteChat,
  clearChat,
  deleteMessage,
  editMessage,
  markChatRead,
  markChatUnread,
  archiveChat,
  unarchiveChat,
  pinMessage,
  unpinMessage,
};
