const {
  ensureSession,
  normalizeChatId,
  sessionCommand,
  sessionRequest,
  buildPath,
} = require("./common");
const { buildPaginationParams } = require("../toolkit/wahaClient");

function encodeGroupId(groupId) {
  if (!groupId) throw new Error("groupId tələb olunur.");
  return encodeURIComponent(normalizeChatId(groupId));
}

async function listGroups({ session, limit, cursor } = {}) {
  const query = buildPaginationParams({ limit, cursor });
  return sessionRequest({ session, path: "/api/:session/groups", method: "GET", query });
}

async function getGroup({ session, groupId }) {
  const path = buildPath("/api/:session/groups/:groupId", {
    session: ensureSession(session),
    groupId: encodeGroupId(groupId),
  });
  return sessionRequest({ session, path, method: "GET" });
}

async function createGroup({ session, subject, participants = [], description }) {
  if (!subject) throw new Error("subject tələb olunur.");
  const payload = {
    subject,
    participants: participants.map(normalizeChatId),
    description,
  };
  return sessionCommand({
    session,
    endpoint: "/api/:session/groups",
    method: "POST",
    payload,
  });
}

async function updateGroupSubject({ session, groupId, subject }) {
  if (!subject) throw new Error("subject tələb olunur.");
  const endpoint = buildPath("/api/:session/groups/:groupId/subject", {
    session: ensureSession(session),
    groupId: encodeGroupId(groupId),
  });
  return sessionCommand({ session, endpoint, method: "PUT", payload: { subject } });
}

async function updateGroupDescription({ session, groupId, description }) {
  const endpoint = buildPath("/api/:session/groups/:groupId/description", {
    session: ensureSession(session),
    groupId: encodeGroupId(groupId),
  });
  return sessionCommand({ session, endpoint, method: "PUT", payload: { description } });
}

async function addParticipants({ session, groupId, participants }) {
  if (!Array.isArray(participants) || participants.length === 0) {
    throw new Error("participants boş ola bilməz.");
  }
  const endpoint = buildPath("/api/:session/groups/:groupId/participants", {
    session: ensureSession(session),
    groupId: encodeGroupId(groupId),
  });
  return sessionCommand({
    session,
    endpoint,
    method: "POST",
    payload: { participants: participants.map(normalizeChatId) },
  });
}

async function removeParticipants({ session, groupId, participants }) {
  if (!Array.isArray(participants) || participants.length === 0) {
    throw new Error("participants boş ola bilməz.");
  }
  const endpoint = buildPath("/api/:session/groups/:groupId/participants", {
    session: ensureSession(session),
    groupId: encodeGroupId(groupId),
  });
  return sessionCommand({
    session,
    endpoint,
    method: "DELETE",
    payload: { participants: participants.map(normalizeChatId) },
  });
}

async function promoteParticipants({ session, groupId, participants }) {
  if (!Array.isArray(participants) || participants.length === 0) {
    throw new Error("participants boş ola bilməz.");
  }
  const endpoint = buildPath("/api/:session/groups/:groupId/promote", {
    session: ensureSession(session),
    groupId: encodeGroupId(groupId),
  });
  return sessionCommand({
    session,
    endpoint,
    method: "POST",
    payload: { participants: participants.map(normalizeChatId) },
  });
}

async function demoteParticipants({ session, groupId, participants }) {
  if (!Array.isArray(participants) || participants.length === 0) {
    throw new Error("participants boş ola bilməz.");
  }
  const endpoint = buildPath("/api/:session/groups/:groupId/demote", {
    session: ensureSession(session),
    groupId: encodeGroupId(groupId),
  });
  return sessionCommand({
    session,
    endpoint,
    method: "POST",
    payload: { participants: participants.map(normalizeChatId) },
  });
}

async function getInviteCode({ session, groupId }) {
  const endpoint = buildPath("/api/:session/groups/:groupId/invite-code", {
    session: ensureSession(session),
    groupId: encodeGroupId(groupId),
  });
  return sessionCommand({ session, endpoint, method: "GET" });
}

async function revokeInviteCode({ session, groupId }) {
  const endpoint = buildPath("/api/:session/groups/:groupId/invite-code", {
    session: ensureSession(session),
    groupId: encodeGroupId(groupId),
  });
  return sessionCommand({ session, endpoint, method: "DELETE" });
}

async function joinGroup({ session, inviteCode }) {
  if (!inviteCode) throw new Error("inviteCode tələb olunur.");
  return sessionCommand({
    session,
    endpoint: "/api/:session/groups/join",
    method: "POST",
    payload: { inviteCode },
  });
}

module.exports = {
  listGroups,
  getGroup,
  createGroup,
  updateGroupSubject,
  updateGroupDescription,
  addParticipants,
  removeParticipants,
  promoteParticipants,
  demoteParticipants,
  getInviteCode,
  revokeInviteCode,
  joinGroup,
};
