const {
  ensureSession,
  normalizeChatId,
  sessionCommand,
  sessionRequest,
  buildPath,
} = require("./common");

function encodeChatId(chatId) {
  if (!chatId) throw new Error("chatId tələb olunur.");
  return encodeURIComponent(normalizeChatId(chatId));
}

async function getPresence({ session, chatId }) {
  const path = buildPath("/api/:session/chats/:chatId/presence", {
    session: ensureSession(session),
    chatId: encodeChatId(chatId),
  });
  return sessionRequest({ session, path, method: "GET" });
}

async function subscribePresence({ session, chatId }) {
  const endpoint = buildPath("/api/:session/chats/:chatId/presence/subscribe", {
    session: ensureSession(session),
    chatId: encodeChatId(chatId),
  });
  return sessionCommand({ session, endpoint, method: "POST" });
}

async function unsubscribePresence({ session, chatId }) {
  const endpoint = buildPath("/api/:session/chats/:chatId/presence/unsubscribe", {
    session: ensureSession(session),
    chatId: encodeChatId(chatId),
  });
  return sessionCommand({ session, endpoint, method: "POST" });
}

async function setPresence({ session, chatId, state }) {
  if (!state) throw new Error("presence state tələb olunur.");
  const endpoint = buildPath("/api/:session/chats/:chatId/presence", {
    session: ensureSession(session),
    chatId: encodeChatId(chatId),
  });
  return sessionCommand({ session, endpoint, method: "POST", payload: { state } });
}

module.exports = {
  getPresence,
  subscribePresence,
  unsubscribePresence,
  setPresence,
};
