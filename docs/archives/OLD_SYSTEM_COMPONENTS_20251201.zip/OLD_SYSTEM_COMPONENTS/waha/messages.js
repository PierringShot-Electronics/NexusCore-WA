const {
  sendToolCommand,
  buildMediaPayload,
} = require("../toolkit/wahaClient");
const {
  ensureSession,
  normalizeChatId,
  sanitizePhone,
} = require("./common");

function resolveIdentifiers({ session, number, chatId }) {
  const resolvedSession = ensureSession(session);
  const resolvedChatId = chatId
    ? normalizeChatId(chatId)
    : number
      ? normalizeChatId(number)
      : undefined;
  const resolvedPhone = number ? sanitizePhone(number) : undefined;
  if (!resolvedChatId && !resolvedPhone) {
    throw new Error("chatId və ya number sahəsi tələb olunur.");
  }
  return { session: resolvedSession, chatId: resolvedChatId, phone: resolvedPhone };
}

async function sendText({ number, chatId, message, quotedMsgId, session, options = {} }) {
  if (!message) throw new Error("Mesaj mətni tələb olunur.");
  const identifiers = resolveIdentifiers({ session, number, chatId });
  const payload = {
    session: identifiers.session,
    chatId: identifiers.chatId,
    phone: identifiers.phone,
    text: message,
    message,
    ...options,
  };
  if (quotedMsgId) {
    payload.reply_to = quotedMsgId;
  }
  return sendToolCommand({
    method: "POST",
    endpoint: "/api/sendText",
    payload,
  });
}

function buildMediaOptions({
  number,
  chatId,
  session,
  caption,
  file,
  mediaUrl,
  mediaBase64,
  mimeType,
  fileName,
  message,
  replyTo,
  extra = {},
}) {
  const identifiers = resolveIdentifiers({ session, number, chatId });
  const payload = buildMediaPayload({
    session: identifiers.session,
    phone: identifiers.phone,
    chatId: identifiers.chatId,
    caption,
    message,
    mediaUrl,
    mediaBase64,
    mimeType,
    fileName,
    ...extra,
  });
  if (file) {
    payload.file = file;
  }
  if (replyTo) {
    payload.reply_to = replyTo;
  }
  return payload;
}

async function sendImage(options) {
  const payload = buildMediaOptions(options);
  return sendToolCommand({ method: "POST", endpoint: "/api/sendImage", payload });
}

async function sendFile(options) {
  const payload = buildMediaOptions(options);
  return sendToolCommand({ method: "POST", endpoint: "/api/sendFile", payload });
}

async function sendVideo(options) {
  const payload = buildMediaOptions(options);
  return sendToolCommand({ method: "POST", endpoint: "/api/sendVideo", payload });
}

async function sendVoice(options) {
  const payload = buildMediaOptions(options);
  return sendToolCommand({ method: "POST", endpoint: "/api/sendVoice", payload });
}

async function sendAudio(options) {
  const payload = buildMediaOptions(options);
  return sendToolCommand({ method: "POST", endpoint: "/api/sendAudio", payload });
}

async function sendLocation({ number, chatId, session, latitude, longitude, description, title }) {
  if (latitude === undefined || longitude === undefined) {
    throw new Error("Latitude və longitude tələb olunur.");
  }
  const identifiers = resolveIdentifiers({ session, number, chatId });
  const payload = {
    session: identifiers.session,
    chatId: identifiers.chatId,
    phone: identifiers.phone,
    latitude,
    longitude,
    description,
    title,
  };
  return sendToolCommand({
    method: "POST",
    endpoint: "/api/sendLocation",
    payload,
  });
}

async function sendContact({ number, chatId, session, contacts }) {
  if (!Array.isArray(contacts) || contacts.length === 0) {
    throw new Error("Ən azı bir kontakt məlumatı tələb olunur.");
  }
  const identifiers = resolveIdentifiers({ session, number, chatId });
  const payload = {
    session: identifiers.session,
    chatId: identifiers.chatId,
    phone: identifiers.phone,
    contacts,
  };
  return sendToolCommand({
    method: "POST",
    endpoint: "/api/sendContactVcard",
    payload,
  });
}

async function sendList({ number, chatId, session, header, body, footer, buttonText, sections, replyTo }) {
  if (!Array.isArray(sections) || sections.length === 0) {
    throw new Error("Sections boş ola bilməz.");
  }
  const identifiers = resolveIdentifiers({ session, number, chatId });
  const payload = {
    session: identifiers.session,
    chatId: identifiers.chatId,
    phone: identifiers.phone,
    header,
    body,
    footer,
    buttonText,
    sections,
  };
  if (replyTo) payload.reply_to = replyTo;
  return sendToolCommand({ method: "POST", endpoint: "/api/sendList", payload });
}

async function sendButtons({ number, chatId, session, header, body, footer, buttons, headerImage, replyTo }) {
  if (!Array.isArray(buttons) || buttons.length === 0) {
    throw new Error("Buttons boş ola bilməz.");
  }
  const identifiers = resolveIdentifiers({ session, number, chatId });
  const payload = {
    session: identifiers.session,
    chatId: identifiers.chatId,
    phone: identifiers.phone,
    header,
    body,
    footer,
    buttons,
  };
  if (headerImage) payload.headerImage = headerImage;
  if (replyTo) payload.reply_to = replyTo;
  return sendToolCommand({ method: "POST", endpoint: "/api/sendButtons", payload });
}

async function sendButtonsReply({ session, chatId, number, replyTo, selectedDisplayText, selectedButtonID }) {
  if (!replyTo) throw new Error("replyTo tələb olunur.");
  const identifiers = resolveIdentifiers({ session, chatId, number });
  const payload = {
    session: identifiers.session,
    chatId: identifiers.chatId,
    phone: identifiers.phone,
    replyTo,
    selectedDisplayText,
    selectedButtonID,
  };
  return sendToolCommand({ method: "POST", endpoint: "/api/send/buttons/reply", payload });
}

async function sendPoll({ number, chatId, session, poll, replyTo }) {
  if (!poll || typeof poll !== "object") {
    throw new Error("Poll məlumatı tələb olunur.");
  }
  const identifiers = resolveIdentifiers({ session, number, chatId });
  const payload = {
    session: identifiers.session,
    chatId: identifiers.chatId,
    phone: identifiers.phone,
    poll,
  };
  if (replyTo) payload.reply_to = replyTo;
  return sendToolCommand({ method: "POST", endpoint: "/api/sendPoll", payload });
}

async function sendLinkPreview({ number, chatId, session, text, preview, linkPreviewHighQuality }) {
  if (!text) throw new Error("Link mətni tələb olunur.");
  if (!preview || !preview.url) {
    throw new Error("preview.url tələb olunur.");
  }
  const identifiers = resolveIdentifiers({ session, number, chatId });
  const payload = {
    session: identifiers.session,
    chatId: identifiers.chatId,
    phone: identifiers.phone,
    text,
    preview,
    linkPreviewHighQuality,
  };
  return sendToolCommand({
    method: "POST",
    endpoint: "/api/send/link-custom-preview",
    payload,
  });
}

async function sendTemplate({ number, chatId, session, namespace, templateName, language, components }) {
  if (!namespace || !templateName) {
    throw new Error("namespace və templateName tələb olunur.");
  }
  const identifiers = resolveIdentifiers({ session, number, chatId });
  const payload = {
    session: identifiers.session,
    chatId: identifiers.chatId,
    phone: identifiers.phone,
    namespace,
    templateName,
    language,
    components,
  };
  return sendToolCommand({ method: "POST", endpoint: "/api/sendTemplate", payload });
}

async function sendSticker(options) {
  const payload = buildMediaOptions(options);
  return sendToolCommand({ method: "POST", endpoint: "/api/sendSticker", payload });
}

async function forwardMessage({ number, chatId, session, messageId }) {
  if (!messageId) throw new Error("messageId tələb olunur.");
  const identifiers = resolveIdentifiers({ session, number, chatId });
  const payload = {
    session: identifiers.session,
    chatId: identifiers.chatId,
    phone: identifiers.phone,
    messageId,
  };
  return sendToolCommand({ method: "POST", endpoint: "/api/forwardMessage", payload });
}

async function sendSeen({ number, chatId, session, messageIds, participant }) {
  const identifiers = resolveIdentifiers({ session, number, chatId });
  const payload = {
    session: identifiers.session,
    chatId: identifiers.chatId,
    phone: identifiers.phone,
  };
  if (Array.isArray(messageIds) && messageIds.length > 0) {
    payload.messageIds = messageIds;
  }
  if (participant) payload.participant = participant;
  return sendToolCommand({ method: "POST", endpoint: "/api/sendSeen", payload });
}

async function startTyping({ number, chatId, session }) {
  const identifiers = resolveIdentifiers({ session, number, chatId });
  const payload = {
    session: identifiers.session,
    chatId: identifiers.chatId,
    phone: identifiers.phone,
  };
  return sendToolCommand({ method: "POST", endpoint: "/api/startTyping", payload });
}

async function stopTyping({ number, chatId, session }) {
  const identifiers = resolveIdentifiers({ session, number, chatId });
  const payload = {
    session: identifiers.session,
    chatId: identifiers.chatId,
    phone: identifiers.phone,
  };
  return sendToolCommand({ method: "POST", endpoint: "/api/stopTyping", payload });
}

async function starMessage({ number, chatId, session, messageId, star = true }) {
  if (!messageId) throw new Error("messageId tələb olunur.");
  const identifiers = resolveIdentifiers({ session, number, chatId });
  const payload = {
    session: identifiers.session,
    chatId: identifiers.chatId,
    phone: identifiers.phone,
    messageId,
    star,
  };
  return sendToolCommand({ method: "PUT", endpoint: "/api/star", payload });
}

module.exports = {
  sendText,
  sendImage,
  sendFile,
  sendVideo,
  sendVoice,
  sendAudio,
  sendLocation,
  sendContact,
  sendList,
  sendButtons,
  sendButtonsReply,
  sendPoll,
  sendLinkPreview,
  sendTemplate,
  sendSticker,
  forwardMessage,
  sendSeen,
  startTyping,
  stopTyping,
  starMessage,
};
