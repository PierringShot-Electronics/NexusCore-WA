const { sessionRequest, sessionCommand, ensureSession } = require("./common");

async function getProfile({ session } = {}) {
  return sessionRequest({
    session,
    path: "/api/:session/profile",
    method: "GET",
  });
}

async function setName({ session, name }) {
  if (!name) throw new Error("Profil adı tələb olunur.");
  return sessionCommand({
    session,
    endpoint: "/api/:session/profile/name",
    method: "PUT",
    payload: { name },
  });
}

async function setStatus({ session, status }) {
  if (!status) throw new Error("Status mətni tələb olunur.");
  return sessionCommand({
    session,
    endpoint: "/api/:session/profile/status",
    method: "PUT",
    payload: { status },
  });
}

async function setPicture({ session, picture }) {
  if (!picture) throw new Error("Profil şəkli məlumatı tələb olunur.");
  const resolvedSession = ensureSession(session);
  const payload = { session: resolvedSession, ...picture };
  return sessionCommand({
    session: resolvedSession,
    endpoint: "/api/:session/profile/picture",
    method: "PUT",
    payload,
  });
}

async function deletePicture({ session } = {}) {
  return sessionCommand({
    session,
    endpoint: "/api/:session/profile/picture",
    method: "DELETE",
  });
}

module.exports = {
  getProfile,
  setName,
  setStatus,
  setPicture,
  deletePicture,
};
