#!/usr/bin/env node
const fs = require("fs-extra");
const path = require("path");

const TARGETS = [
  { dir: "logs", description: "log files" },
  { dir: "media", description: "media cache" },
  { dir: path.join("data", "chat_histories"), description: "chat histories" },
];

async function purgeDirectory(root, description) {
  const targetPath = path.join(process.cwd(), root);
  try {
    const exists = await fs.pathExists(targetPath);
    if (!exists) {
      await fs.ensureDir(targetPath);
      console.log(`ℹ️  ${description} directory absent; created ${targetPath}`);
      return;
    }

    const entries = await fs.readdir(targetPath);
    if (entries.length === 0) {
      console.log(`✅ ${description} already clean (${targetPath}).`);
      return;
    }

    for (const entry of entries) {
      const entryPath = path.join(targetPath, entry);
      await fs.remove(entryPath);
    }

    console.log(`🧹 Cleared ${description} at ${targetPath}.`);
  } catch (error) {
    console.error(`❌ Unable to clean ${description} at ${targetPath}:`, error.message);
    process.exitCode = 1;
  }
}

(async () => {
  for (const target of TARGETS) {
    await purgeDirectory(target.dir, target.description);
  }
})();
