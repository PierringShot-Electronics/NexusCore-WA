#!/usr/bin/env node
const path = require('path');
const fs = require('fs-extra');
const { logWithTimestamp } = require('../../utils/logger');

const tempDir = process.env.MEDIA_TEMP_DIR || path.join(__dirname, '..', '..', 'media', 'temp');
const maxAgeMinutes = Number(process.env.MEDIA_MAX_AGE_MINUTES || process.argv[2] || 120);
const cutoff = Date.now() - maxAgeMinutes * 60 * 1000;

async function cleanup() {
  if (!(await fs.pathExists(tempDir))) {
    console.log(`Media temp directory not found: ${tempDir}`);
    return;
  }

  const entries = await fs.readdir(tempDir);
  let removed = 0;
  for (const entry of entries) {
    const filePath = path.join(tempDir, entry);
    const stats = await fs.stat(filePath).catch(() => null);
    if (!stats || !stats.isFile()) continue;
    if (stats.mtimeMs < cutoff) {
      await fs.unlink(filePath).catch((error) => {
        logWithTimestamp(`❌ Müvəqqəti media faylı silinmədi: ${filePath}`, error.message);
      });
      removed += 1;
    }
  }

  console.log(`Media cleanup complete. Removed ${removed} file(s) older than ${maxAgeMinutes} minute(s).`);
}

cleanup().catch((error) => {
  console.error('Media cleanup failed:', error.message);
  process.exitCode = 1;
});
