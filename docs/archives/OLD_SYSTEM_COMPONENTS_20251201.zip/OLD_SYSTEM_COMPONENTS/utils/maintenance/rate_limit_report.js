#!/usr/bin/env node
const { readGroqMetrics } = require('../metrics/groqMetrics');

const metrics = readGroqMetrics();
const rateEvents = metrics.filter((entry) => {
  if (!entry || typeof entry !== 'object') return false;
  if (entry.reason === 'rate-limit') return true;
  const status = Number(entry.status || entry.code);
  return status === 429;
});

if (rateEvents.length === 0) {
  console.log('No Groq rate-limit events recorded.');
  process.exit(0);
}

const countsByKey = rateEvents.reduce((acc, entry) => {
  const key = entry.keyTail || 'unknown';
  acc[key] = (acc[key] || 0) + 1;
  return acc;
}, {});

const countsByHour = rateEvents.reduce((acc, entry) => {
  const hour = entry.timestamp ? entry.timestamp.slice(0, 13) : 'unknown';
  acc[hour] = (acc[hour] || 0) + 1;
  return acc;
}, {});

console.log(`Total rate-limit signals: ${rateEvents.length}`);
console.log('Top offending keys:');
for (const [key, count] of Object.entries(countsByKey).sort((a, b) => b[1] - a[1])) {
  console.log(`  ...${key}: ${count}`);
}

console.log('Hourly distribution:');
for (const [hour, count] of Object.entries(countsByHour).sort()) {
  console.log(`  ${hour}: ${count}`);
}

process.exit(0);
