#!/usr/bin/env node
const path = require("path");
const fetch = require("node-fetch");
const { parseGroqKeyBuckets } = require("../services/models/groqProvider");

const dotenvPath = path.join(__dirname, "..", ".env");
try {
  require("dotenv").config({ path: dotenvPath });
} catch (error) {
  console.warn("⚠️ Could not load .env file:", error.message);
}

function flattenBucketKeys(buckets = []) {
  const keys = [];
  for (const bucket of buckets) {
    if (!bucket || !Array.isArray(bucket.keys)) continue;
    for (const key of bucket.keys) {
      if (key) keys.push(key);
    }
  }
  return keys;
}

async function probeKey(key) {
  try {
    const response = await fetch("https://api.groq.com/openai/v1/models", {
      method: "GET",
      headers: {
        Authorization: `Bearer ${key}`,
      },
    });

    if (response.ok) {
      return { ok: true, status: response.status };
    }

    const body = await response.json().catch(() => ({}));
    return {
      ok: false,
      status: response.status,
      message: body?.error?.message || response.statusText,
    };
  } catch (error) {
    return { ok: false, status: "network", message: error.message };
  }
}

(async () => {
  const activeBuckets = parseGroqKeyBuckets(process.env.GROQ_API_KEYS || "");
  if (!activeBuckets.length) {
    console.error("❌ GROQ_API_KEYS is empty. Populate .env before running this script.");
    process.exit(1);
  }

  let healthy = 0;
  let unhealthy = 0;

  console.log("Active Groq accounts:");
  for (const bucket of activeBuckets) {
    console.log(`\nAccount: ${bucket.account} (${bucket.keys.length} key${bucket.keys.length === 1 ? "" : "s"})`);
    for (const key of bucket.keys) {
      const tail = key.slice(-4);
      const result = await probeKey(key);
      if (result.ok) {
        healthy += 1;
        console.log(`  ✅ ...${tail} OK (status ${result.status})`);
      } else {
        unhealthy += 1;
        const note = result.status === 401
          ? "Unauthorized — quarantine and rotate this key."
          : result.status === 429
            ? "Rate limited — slow down or regroup accounts."
            : result.message || "Unknown error.";
        console.log(`  ❌ ...${tail} FAILED (status ${result.status}): ${note}`);
      }
    }
  }

  const quarantinedBuckets = parseGroqKeyBuckets(process.env.GROQ_QUARANTINED_KEYS || "");
  const quarantinedKeys = flattenBucketKeys(quarantinedBuckets);
  let quarantineRecovered = 0;
  let quarantineStillBlocked = 0;

  if (quarantinedKeys.length) {
    console.log("\nQuarantined Groq accounts:");
    for (const bucket of quarantinedBuckets) {
      console.log(`\nAccount: ${bucket.account} (${bucket.keys.length} key${bucket.keys.length === 1 ? "" : "s"})`);
      for (const key of bucket.keys) {
        const tail = key.slice(-4);
        const result = await probeKey(key);
        if (result.ok) {
          quarantineRecovered += 1;
          console.log(`  ⚠️ ...${tail} responded OK (status ${result.status}) — consider reintroducing after review.`);
        } else {
          quarantineStillBlocked += 1;
          const note = result.status === 401
            ? "Unauthorized — static quarantine confirmed."
            : result.status === 429
              ? "Rate limited — still throttled."
              : result.message || "Unknown error.";
          console.log(`  ❌ ...${tail} FAILED (status ${result.status}): ${note}`);
        }
      }
    }
  }

  console.log("\nSummary (active keys):");
  console.log(`  Healthy keys: ${healthy}`);
  console.log(`  Problem keys: ${unhealthy}`);

  if (quarantinedKeys.length) {
    console.log("Summary (quarantined keys):");
    console.log(`  Still failing as expected: ${quarantineStillBlocked}`);
    console.log(`  Recovered (needs review): ${quarantineRecovered}`);
  }

  if (unhealthy > 0) {
    process.exit(2);
  }

  process.exit(0);
})();
