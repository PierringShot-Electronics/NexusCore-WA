const fs = require("fs");
const { spawnSync } = require("child_process");

function isExecutable(filePath) {
  if (!filePath) {
    return false;
  }

  try {
    fs.accessSync(filePath, fs.constants.X_OK);
    return true;
  } catch (error) {
    return false;
  }
}

function locateBinary(binaryName) {
  const locator = process.platform === "win32" ? "where" : "which";
  const result = spawnSync(locator, [binaryName], { encoding: "utf8" });

  if (result.status !== 0) {
    return null;
  }

  const candidate = result.stdout
    .split(/\r?\n/)
    .map((line) => line.trim())
    .find(Boolean);

  return isExecutable(candidate) ? candidate : null;
}

function resolvePuppeteerExecutable() {
  const envCandidates = [
    process.env.PUPPETEER_EXECUTABLE_PATH,
    process.env.GOOGLE_CHROME_BIN,
    process.env.CHROME_PATH,
    process.env.CHROMIUM_PATH,
    process.env.CHROMIUM_BIN,
  ];

  const hardcodedCandidates = [
    "/usr/bin/chromium",
    "/usr/bin/chromium-browser",
    "/snap/bin/chromium",
    "/usr/bin/google-chrome-stable",
    "/usr/bin/google-chrome",
    "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
    "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
  ];

  for (const candidate of [...envCandidates, ...hardcodedCandidates]) {
    if (isExecutable(candidate)) {
      return candidate;
    }
  }

  const binaryHints =
    process.platform === "win32"
      ? ["chrome", "msedge", "chromium"]
      : ["chromium", "chromium-browser", "google-chrome", "google-chrome-stable"];

  for (const binary of binaryHints) {
    const detected = locateBinary(binary);
    if (detected) {
      return detected;
    }
  }

  throw new Error(
    "Puppeteer executable path not found. Set PUPPETEER_EXECUTABLE_PATH to a valid Chromium/Chrome binary, e.g. /usr/bin/chromium.",
  );
}

module.exports = { resolvePuppeteerExecutable };
