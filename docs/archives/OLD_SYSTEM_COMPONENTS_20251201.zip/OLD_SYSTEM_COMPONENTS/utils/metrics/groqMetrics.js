const path = require("path");
const fs = require("fs-extra");

const METRICS_DIR = path.join(__dirname, "..", "..", "logs", "metrics");
const METRICS_FILE = path.join(METRICS_DIR, "groq-metrics.jsonl");

fs.ensureDirSync(METRICS_DIR);

function recordGroqMetric(event, details = {}) {
  const payload = {
    timestamp: new Date().toISOString(),
    event,
    ...details,
  };
  fs.appendFileSync(METRICS_FILE, `${JSON.stringify(payload)}\n`);
}

function summarizeGroqMetrics() {
  if (!fs.existsSync(METRICS_FILE)) {
    return {};
  }
  const lines = fs.readFileSync(METRICS_FILE, "utf8").trim().split(/\n+/).filter(Boolean);
  return lines.reduce((acc, line) => {
    try {
      const parsed = JSON.parse(line);
      const key = parsed.event || "unknown";
      acc[key] = (acc[key] || 0) + 1;
    } catch (error) {
      acc._parse_error = (acc._parse_error || 0) + 1;
    }
    return acc;
  }, {});
}

function readGroqMetrics() {
  if (!fs.existsSync(METRICS_FILE)) {
    return [];
  }
  return fs
    .readFileSync(METRICS_FILE, "utf8")
    .trim()
    .split(/\n+/)
    .filter(Boolean)
    .map((line) => {
      try {
        return JSON.parse(line);
      } catch (error) {
        return { event: 'parse_error', raw: line };
      }
    });
}

module.exports = { recordGroqMetric, summarizeGroqMetrics, readGroqMetrics, METRICS_FILE };
