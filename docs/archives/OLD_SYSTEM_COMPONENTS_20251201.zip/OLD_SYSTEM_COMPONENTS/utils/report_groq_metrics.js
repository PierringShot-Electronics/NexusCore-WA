#!/usr/bin/env node
const { summarizeGroqMetrics, METRICS_FILE } = require("./metrics/groqMetrics");

const summary = summarizeGroqMetrics();
if (Object.keys(summary).length === 0) {
  console.log("No Groq metrics recorded yet. Expected file:", METRICS_FILE);
  process.exit(0);
}

console.log("Groq Metrics Summary:");
for (const [event, count] of Object.entries(summary)) {
  console.log(`  ${event}: ${count}`);
}

process.exit(0);
