/**
 * WhatsCore.AI - Maverick Edition
 *
 * Sifariş Meneceri (Order Manager) - v4.6.0
 * JSON verilənlər bazası üzərindən sifarişlərin yaradılması və siyahılanması.
 */
const fs = require('fs-extra');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const { logWithTimestamp } = require('../utils/logger');

const ORDERS_DB_PATH = path.join(__dirname, '..', 'data', 'orders.json');

fs.ensureFileSync(ORDERS_DB_PATH);
if (fs.readFileSync(ORDERS_DB_PATH, 'utf-8').trim() === '') {
  fs.writeJsonSync(ORDERS_DB_PATH, [], { spaces: 2 });
}

let orders = [];

function loadOrdersFromDisk() {
  try {
    const data = fs.readJsonSync(ORDERS_DB_PATH, { throws: false }) || [];
    if (Array.isArray(data)) {
      orders = data;
      logWithTimestamp(`✅ ${orders.length} sifariş JSON verilənlər bazasından yükləndi.`);
    } else {
      orders = [];
      logWithTimestamp('⚠️ orders.json gözlənilən massiv formatında deyil. Boş massiv istifadə edilir.');
    }
  } catch (error) {
    orders = [];
    logWithTimestamp('❌ Sifarişləri oxumaq mümkün olmadı:', error);
  }
}

loadOrdersFromDisk();

function normalizeCustomer(orderDetails) {
  const customer = { ...(orderDetails.customer || {}) };
  const customerPhone =
    orderDetails.customer_phone ||
    customer.phone ||
    customer.phoneNumber ||
    orderDetails.phone ||
    orderDetails.phoneNumber ||
    null;

  if (customerPhone) {
    customer.phone = customerPhone;
  }

  return { customer, customerPhone };
}

function normalizeProduct(orderDetails) {
  if (orderDetails.productDetails) {
    return orderDetails.productDetails;
  }
  if (orderDetails.product) {
    return orderDetails.product;
  }
  return {};
}

/**
 * Bütün sifarişləri qaytarır.
 * @returns {Array}
 */
function getAllOrders() {
  return orders.map((order) => ({ ...order }));
}

/**
 * JSON verilənlər bazasını yenidən oxuyur.
 * @returns {Promise<Array>}
 */
async function refreshOrders() {
  loadOrdersFromDisk();
  return getAllOrders();
}

/**
 * Yeni sifariş yaradır və verilənlər bazasına əlavə edir.
 * @param {object} orderDetails - AI tərəfindən göndərilən sifariş detalları.
 * @returns {Promise<object>} - Yaradılan yeni sifariş.
 */
async function createOrder(orderDetails) {
  try {
    const { customer, customerPhone } = normalizeCustomer(orderDetails || {});
    const productDetails = normalizeProduct(orderDetails || {});
    const orderId = uuidv4();
    const createdAt = new Date().toISOString();

    const newOrder = {
      ...(orderDetails || {}),
      id: orderId,
      orderId,
      status: (orderDetails && orderDetails.status) || 'Qəbul edildi',
      createdAt,
      customerDetails: customer,
      productDetails,
      customer_phone: customerPhone,
    };

    orders.push(newOrder);
    await fs.writeJson(ORDERS_DB_PATH, orders, { spaces: 4 });

    logWithTimestamp(`✅ Yeni sifariş yaradıldı: ${orderId}`);
    return { ...newOrder };
  } catch (error) {
    logWithTimestamp('❌ Sifariş yaratmaq mümkün olmadı:', error);
    throw new Error('Sifariş yaradılarkən daxili xəta baş verdi.');
  }
}

module.exports = {
  createOrder,
  getAllOrders,
  refreshOrders,
};
