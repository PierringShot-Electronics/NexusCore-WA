const fs = require("fs-extra");
const mediaProcessor = require("./mediaProcessor");
const { getBufferFallbackMessage } = require("./bufferFallbacks");
const { logWithTimestamp } = require("../utils/logger");
const { recordGroqMetric } = require("../utils/metrics/groqMetrics");

const TEXT_BUFFER_TIMEOUT = (Number(process.env.BUFFER_TIMEOUT_SECONDS) || 8) * 1000;
const MEDIA_BUFFER_TIMEOUT = 3000;

function createBufferEngine({ getAIResponse, replyToMessage }) {
  if (typeof getAIResponse !== "function" || typeof replyToMessage !== "function") {
    throw new Error("createBufferEngine requires getAIResponse and replyToMessage functions.");
  }

  const textBuffer = new Map();
  const mediaBuffer = new Map();

  function cancelTimer(entry) {
    if (entry?.timer) {
      clearTimeout(entry.timer);
      entry.timer = undefined;
    }
  }

  function cancelTextTimer(chatId) {
    const entry = textBuffer.get(chatId);
    cancelTimer(entry);
  }

  function cancelMediaTimer(chatId) {
    const entry = mediaBuffer.get(chatId);
    cancelTimer(entry);
  }

  async function flushTextBuffer(client, chatId) {
    const entry = textBuffer.get(chatId);
    if (!entry || entry.messages.length === 0) return { status: "idle" };

    textBuffer.delete(chatId);
    cancelTimer(entry);

    const lastMessage = entry.originalMessages[entry.originalMessages.length - 1];
    const combinedText = entry.messages.join("\n");
    logWithTimestamp(`⏳ Mətn Buferi boşaldılır [${chatId}]: "${combinedText}"`);

    try {
      const minThinkingTime = 1500;
      const aiPromise = getAIResponse(chatId, { text: combinedText, media: [] });
      const [aiResponse] = await Promise.all([
        aiPromise,
        new Promise((resolve) => setTimeout(resolve, minThinkingTime)),
      ]);
      await replyToMessage(client, chatId, aiResponse, lastMessage);
      recordGroqMetric("buffer-flush-success", { type: "text", messages: entry.messages.length });
      return { status: "sent", messages: entry.messages.length };
    } catch (error) {
      logWithTimestamp("❌ Mətn buferindən AI cavabı alma xətası:", error);
      const fallbackResponse = getBufferFallbackMessage("text", error);
      await replyToMessage(client, chatId, fallbackResponse, lastMessage);
      const statusCode = error?.status || error?.response?.status || error?.code;
      recordGroqMetric("buffer-fallback", {
        type: "text",
        status: statusCode || "unknown",
        error: error?.message || statusCode || "unknown",
      });
      return { status: "fallback", error };
    }
  }

  async function flushMediaBuffer(client, chatId) {
    const entry = mediaBuffer.get(chatId);
    if (!entry || entry.messages.length === 0) return { status: "idle" };

    mediaBuffer.delete(chatId);
    cancelTimer(entry);

    const messages = entry.messages;
    const lastMessage = messages[messages.length - 1];
    logWithTimestamp(`⏳ Media Buferi boşaldılır [${chatId}]: ${messages.length} media faylı tapıldı.`);

    const temporaryFiles = [];
    const chat = await lastMessage.getChat();

    try {
      chat.sendStateTyping();
      const combinedCaption = messages
        .map((msg) => msg.body || "")
        .filter((line) => line.trim() !== "")
        .join("\n");
      const mediaInputs = [];

      for (const msg of messages) {
        const mediaPath = await mediaProcessor.saveMedia(msg);
        temporaryFiles.push(mediaPath);
        mediaInputs.push({ path: mediaPath, mimeType: msg.mimetype });
      }

      const CHUNK_SIZE = 5;
      for (let i = 0; i < mediaInputs.length; i += CHUNK_SIZE) {
        const chunk = mediaInputs.slice(i, i + CHUNK_SIZE);
        const userInput = {
          text: i === 0 ? combinedCaption : `(Davamı) Paket ${Math.floor(i / CHUNK_SIZE) + 1}`,
          media: chunk,
        };
        logWithTimestamp(`🧠 AI-yə ${chunk.length} media ilə sorğu göndərilir...`);
        const minThinkingTime = 2000;
        const aiPromise = getAIResponse(chatId, userInput);
        const [aiResponse] = await Promise.all([
          aiPromise,
          new Promise((resolve) => setTimeout(resolve, minThinkingTime)),
        ]);
        await replyToMessage(client, chatId, aiResponse, lastMessage);
      }

      recordGroqMetric("buffer-flush-success", { type: "media", messages: messages.length });
      return { status: "sent", messages: messages.length };
    } catch (error) {
      logWithTimestamp("❌ Media buferini emal edərkən xəta:", error);
      const fallbackResponse = getBufferFallbackMessage("media", error);
      await replyToMessage(client, chatId, fallbackResponse, lastMessage);
      const statusCode = error?.status || error?.response?.status || error?.code;
      recordGroqMetric("buffer-fallback", {
        type: "media",
        status: statusCode || "unknown",
        error: error?.message || statusCode || "unknown",
      });
      return { status: "fallback", error };
    } finally {
      chat.clearState();
      await Promise.all(
        temporaryFiles.map((fp) =>
          fs.unlink(fp).catch((err) =>
            logWithTimestamp(`❌ Müvəqqəti media faylı silinmədi: ${fp}`, err.message),
          ),
        ),
      );
    }
  }

  function enqueueTextMessage({ client, chat, chatId, message }) {
    let entry = textBuffer.get(chatId);
    if (!entry) {
      entry = { messages: [], originalMessages: [] };
    }
    cancelTimer(entry);
    entry.messages.push(message.body);
    entry.originalMessages.push(message);
    entry.timer = setTimeout(
      () => flushTextBuffer(client, chatId).finally(() => chat.clearState()),
      TEXT_BUFFER_TIMEOUT,
    );
    textBuffer.set(chatId, entry);
    return entry;
  }

  function enqueueMediaMessage({ client, chatId, message }) {
    let entry = mediaBuffer.get(chatId);
    if (!entry) {
      entry = { messages: [] };
    }
    cancelTimer(entry);
    entry.messages.push(message);
    entry.timer = setTimeout(() => flushMediaBuffer(client, chatId), MEDIA_BUFFER_TIMEOUT);
    mediaBuffer.set(chatId, entry);
    return entry;
  }

  function hasTextBuffer(chatId) {
    const entry = textBuffer.get(chatId);
    return Boolean(entry && entry.messages.length > 0);
  }

  function hasMediaBuffer(chatId) {
    const entry = mediaBuffer.get(chatId);
    return Boolean(entry && entry.messages.length > 0);
  }

  return {
    enqueueTextMessage,
    enqueueMediaMessage,
    flushTextBuffer,
    flushMediaBuffer,
    cancelTextTimer,
    cancelMediaTimer,
    hasTextBuffer,
    hasMediaBuffer,
    TEXT_BUFFER_TIMEOUT,
    MEDIA_BUFFER_TIMEOUT,
  };
}

module.exports = { createBufferEngine };
