const {
  MessageMedia,
  Location,
  Buttons,
  List,
} = require("whatsapp-web.js");
const { logWithTimestamp } = require("../utils/logger");

let whatsappClient;

function setClient(client) {
  whatsappClient = client;
}

function isReady() {
  return Boolean(whatsappClient && whatsappClient.info && whatsappClient.info.wid);
}

function ensureClient() {
  if (!isReady()) {
    throw new Error("whatsapp-web.js fallback hazır deyil.");
  }
  return whatsappClient;
}

function normalizeNumber(input) {
  if (!input) return null;
  if (input.includes("@")) return input;
  const digits = String(input).replace(/\D/g, "");
  if (!digits) return null;
  return `${digits}@c.us`;
}

async function resolveTarget({ number, chatId }) {
  const client = ensureClient();
  const trimmedChatId = chatId && chatId.trim().length > 0 ? chatId.trim() : null;
  const sanitizedNumber = number ? String(number).replace(/\D/g, "") : null;

  const fallbackId = trimmedChatId || normalizeNumber(sanitizedNumber);
  if (!fallbackId) {
    throw new Error("chatId və ya number təqdim edilməlidir.");
  }

  if (trimmedChatId) {
    try {
      const chat = await client.getChatById(trimmedChatId);
      return chat.id._serialized;
    } catch (error) {
      logWithTimestamp(
        `⚠️ whatsapp-web.js fallback: ${trimmedChatId} üçün getChatById alınmadı (${error.message}).`,
      );
    }
  }

  if (sanitizedNumber) {
    try {
      const numberId = await client.getNumberId(sanitizedNumber);
      if (numberId && numberId._serialized) {
        return numberId._serialized;
      }
    } catch (error) {
      logWithTimestamp(
        `⚠️ whatsapp-web.js fallback: getNumberId(${sanitizedNumber}) xətası (${error.message}).`,
      );
    }
  }

  return fallbackId;
}

async function sendText(options) {
  try {
    const client = ensureClient();
    const { message, quotedMsgId, replyTo, sendOptions = {} } = options;
    if (!message) throw new Error("Mesaj mətni tələb olunur.");
    const target = await resolveTarget(options);
    const payload = { ...sendOptions };
    const quoted = quotedMsgId || replyTo;
    if (quoted) {
      payload.quotedMessageId = quoted;
    }
    await client.sendMessage(target, message, payload);
    return {
      ok: true,
      status: 200,
      message: "Mesaj whatsapp-web.js vasitəsilə göndərildi.",
    };
  } catch (error) {
    return { ok: false, status: 500, error: error.message };
  }
}

async function sendMedia(options) {
  try {
    const client = ensureClient();
    const {
      mediaUrl,
      mediaBase64,
      mimeType,
      fileName,
      caption,
      message,
      extra,
      quotedMsgId,
      replyTo,
    } = options;
    const target = await resolveTarget(options);

    let media;
    if (mediaBase64) {
      if (!mimeType) {
        throw new Error("Base64 istifadə üçün mimeType tələb olunur.");
      }
      media = new MessageMedia(mimeType, mediaBase64, fileName);
    } else if (mediaUrl) {
      media = await MessageMedia.fromUrl(mediaUrl, { unsafeMime: true });
    } else if (message) {
      // Məsələn, Sticker-lər üçün (WAHA kimi) raw message base64 ola bilər.
      media = new MessageMedia(mimeType || "application/octet-stream", message, fileName);
    } else {
      throw new Error("Media göndərişi üçün mediaUrl və ya mediaBase64 təqdim edilməlidir.");
    }

    const sendOptions = {};
    if (caption) sendOptions.caption = caption;
    if (extra && typeof extra === "object") {
      Object.assign(sendOptions, extra);
    }
    const quoted = quotedMsgId || replyTo;
    if (quoted) {
      sendOptions.quotedMessageId = quoted;
    }

    await client.sendMessage(target, media, sendOptions);
    return {
      ok: true,
      status: 200,
      message: "Media whatsapp-web.js vasitəsilə göndərildi.",
    };
  } catch (error) {
    return { ok: false, status: 500, error: error.message };
  }
}

async function sendLocation(options) {
  try {
    const client = ensureClient();
    const { latitude, longitude, description, title, quotedMsgId, replyTo } = options;
    if (
      typeof latitude === "undefined" ||
      typeof longitude === "undefined"
    ) {
      throw new Error("Latitude və longitude tələb olunur.");
    }
    const target = await resolveTarget(options);
    const location = new Location(latitude, longitude, title || description);
    const sendOptions = {};
    if (description || title) {
      sendOptions.caption = description || title;
    }
    const quoted = quotedMsgId || replyTo;
    if (quoted) {
      sendOptions.quotedMessageId = quoted;
    }

    await client.sendMessage(target, location, sendOptions);
    return {
      ok: true,
      status: 200,
      message: "Lokasiya whatsapp-web.js vasitəsilə göndərildi.",
    };
  } catch (error) {
    return { ok: false, status: 500, error: error.message };
  }
}

async function sendButtons(options) {
  try {
    const client = ensureClient();
    const {
      header,
      body,
      footer,
      buttons,
      headerImage,
      quotedMsgId,
      replyTo,
    } = options;

    if (!body || !Array.isArray(buttons) || buttons.length === 0) {
      throw new Error("Body və buttons massiv formatında olmalıdır.");
    }

    const target = await resolveTarget(options);
    const payload = new Buttons(body, buttons, header, footer);

    const sendOptions = {};
    if (headerImage) {
      try {
        const media = await MessageMedia.fromUrl(headerImage, {
          unsafeMime: true,
        });
        sendOptions.media = media;
      } catch (error) {
        logWithTimestamp(
          `⚠️ Buttons header şəkli yüklənmədi: ${error.message}`,
        );
      }
    }

    const quoted = quotedMsgId || replyTo;
    if (quoted) {
      sendOptions.quotedMessageId = quoted;
    }

    await client.sendMessage(target, payload, sendOptions);
    return {
      ok: true,
      status: 200,
      message: "Buttons whatsapp-web.js vasitəsilə göndərildi.",
    };
  } catch (error) {
    return { ok: false, status: 500, error: error.message };
  }
}

async function sendList(options) {
  try {
    const client = ensureClient();
    const {
      body,
      buttonText,
      sections,
      title,
      footer,
      description,
      quotedMsgId,
      replyTo,
    } = options;

    if (!body || !buttonText || !Array.isArray(sections) || sections.length === 0) {
      throw new Error("List üçün body, buttonText və ən azı bir section tələb olunur.");
    }

    const target = await resolveTarget(options);
    const payload = new List(
      body,
      buttonText,
      sections,
      title,
      description || footer,
    );

    const sendOptions = {};
    const quoted = quotedMsgId || replyTo;
    if (quoted) {
      sendOptions.quotedMessageId = quoted;
    }

    await client.sendMessage(target, payload, sendOptions);
    return {
      ok: true,
      status: 200,
      message: "List whatsapp-web.js vasitəsilə göndərildi.",
    };
  } catch (error) {
    return { ok: false, status: 500, error: error.message };
  }
}

async function sendPoll() {
  return {
    ok: false,
    status: 501,
    error: "Poll mesajları whatsapp-web.js fallback ilə hələ dəstəklənmir.",
  };
}

module.exports = {
  setClient,
  isReady,
  sendText,
  sendMedia,
  sendLocation,
  sendButtons,
  sendList,
  sendPoll,
};
